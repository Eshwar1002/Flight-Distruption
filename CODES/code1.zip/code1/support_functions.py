# support_functions.py - MULTI-PASSENGER PNR SUPPORT
import sqlite3
import random
from datetime import datetime, timedelta
from config import DB_PATH, RAI_PROFILE
from contextlib import contextmanager
from db_pool import get_connection, DatabasePool

        

# ----------------------------------------------------------------------
# General Utilities
# ----------------------------------------------------------------------
def _conn() -> sqlite3.Connection:
    """
    DEPRECATED: Get database connection (backward compatibility).
    
    WARNING: This function creates DIRECT connections, not pooled connections,
    for backward compatibility with existing code that doesn't release connections.
    These connections will be automatically closed by Python's garbage collector.
    
    For new code, use the connection pool with context manager:
        with get_connection() as conn:
            # your code here
    """
    return sqlite3.connect(DB_PATH)

def _parse_dt(value):
    if isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        raise TypeError(f"Expected datetime or str, got {type(value)}")
    s = value.strip().replace("Z", "")
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    raise ValueError(f"Unrecognized datetime format: {value}")

# ----------------------------------------------------------------------
# Flight cost calculation
# ----------------------------------------------------------------------
def calculate_flight_cost(flight: dict) -> float:
    """
    Estimate cost of a flight based on aircraft type and distance.
    Very basic model: base cost + distance factor + aircraft type factor.
    """
    base_cost = 100.0
    
    # Get distance with fallback
    distance = flight.get("distance", 0)
    if distance is None or distance == 0:
        # Try to estimate distance from origin/destination if available
        # For now, use a default of 1000 km
        distance = 1000
        print(f"Warning: No distance for flight, using default {distance} km")
    
    distance = float(distance)
    
    # Get aircraft type with fallback
    ac_type = flight.get("aircraft_type", "")
    if not ac_type:
        ac_type = "A320"  # Default aircraft type
        print(f"Warning: No aircraft type for flight, using default {ac_type}")
    
    ac_type = ac_type.upper()

    # Simple multipliers by aircraft type
    ac_factor = 1.0
    if "A320" in ac_type or "B737" in ac_type:
        ac_factor = 1.1
    elif "B787" in ac_type:
        ac_factor = 1.3
    elif "B777" in ac_type:
        ac_factor = 1.5

    calculated_cost = base_cost + (distance * 0.1 * ac_factor)
    return round(calculated_cost, 2)

# ----------------------------------------------------------------------
# PNR + Passenger Queries - UPDATED FOR MULTI-PASSENGER
# ----------------------------------------------------------------------
def get_disrupted_passengers():
    """Return disrupted PNRs (not individual passengers) with passenger counts.
    Only returns PNRs that are still on cancelled/delayed flights (not yet rebooked).
    """
    try:
        conn = _conn()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT pr.pnr, pr.lead_passenger_name, pr.passenger_count, 
                   pr.flight_number, f.status
            FROM pnrs pr
            JOIN flights f ON pr.flight_number = f.flight_number
            WHERE f.status IN ('Cancelled','Delayed')
              AND pr.status != 'Rebooked'
            ORDER BY f.status DESC, pr.pnr ASC
        """)
        rows = cursor.fetchall()
    except sqlite3.Error as e:
        print(f"RecoverAI Agent: Error fetching disrupted passengers: {e}")
        return []
    finally:
        conn.close()

    disrupted = []
    for r in rows:
        pax_label = "passenger" if r[2] == 1 else "passengers"
        disrupted.append({
            "pnr": r[0],
            "name": r[1],
            "passenger_count": r[2],
            "flight_number": r[3],
            "status": r[4],
            "display": f"{r[1]} (+{r[2]-1} more)" if r[2] > 1 else r[1]
        })
    return disrupted


def get_pnr_details(pnr: str):
    """Get complete PNR booking details including all passengers."""
    conn = _conn()
    cursor = conn.cursor()
    
    # Get PNR booking info
    cursor.execute("""
        SELECT pr.pnr, pr.flight_number, pr.booking_date, pr.lead_passenger_name,
               pr.passenger_count, pr.status, f.status as flight_status
        FROM pnrs pr
        JOIN flights f ON pr.flight_number = f.flight_number
        WHERE pr.pnr = ?
    """, (pnr,))
    
    pnr_row = cursor.fetchone()
    if not pnr_row:
        conn.close()
        return None
    
    # Get all passengers for this PNR
    cursor.execute("""
        SELECT passenger_id, name, seat, class_of_service, passenger_type, age_group
        FROM passengers
        WHERE pnr = ?
        ORDER BY CASE passenger_type 
            WHEN 'lead' THEN 1 
            WHEN 'adult' THEN 2 
            WHEN 'child' THEN 3 
            WHEN 'infant' THEN 4 
        END, passenger_id
    """, (pnr,))
    
    passengers = cursor.fetchall()
    conn.close()
    
    return {
        "pnr": pnr_row[0],
        "flight_number": pnr_row[1],
        "booking_date": pnr_row[2],
        "lead_passenger_name": pnr_row[3],
        "passenger_count": pnr_row[4],
        "booking_status": pnr_row[5],
        "flight_status": pnr_row[6],
        "passengers": [
            {
                "passenger_id": p[0],
                "name": p[1],
                "seat": p[2],
                "class_of_service": p[3],
                "passenger_type": p[4],
                "age_group": p[5],
            }
            for p in passengers
        ]
    }


def get_passenger_by_pnr(pnr: str):
    """
    UPDATED: Return PNR details with all passengers.
    This replaces the old single-passenger function.
    """
    return get_pnr_details(pnr)


def get_aircraft_type(aircraft_id: str) -> str:
    conn = _conn()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT aircraft_type FROM aircraft WHERE aircraft_id=?", (aircraft_id,))
        row = cursor.fetchone()
        return row[0] if row else "Unknown"
    except sqlite3.Error as e:
        print(f"RecoverAI Agent: Error fetching aircraft type: {e}")
        return "Unknown"
    finally:
        conn.close()


def update_flight_status(flight_number: str, status: str):
    conn = _conn()
    cursor = conn.cursor()
    cursor.execute("UPDATE flights SET status=? WHERE flight_number=?", (status, flight_number))
    conn.commit()
    conn.close()


def update_pnr_flight(pnr: str, new_flight_number: str):
    """Update the flight for all passengers in a PNR and mark as rebooked."""
    conn = _conn()
    cursor = conn.cursor()
    
    try:
        # Update PNR record with new flight and mark as Rebooked
        cursor.execute(
            "UPDATE pnrs SET flight_number = ?, status = 'Rebooked' WHERE pnr = ?",
            (new_flight_number, pnr)
        )
        
        # Update all seat assignments for passengers in this PNR
        cursor.execute("""
            UPDATE seat_assignments 
            SET flight_number = ? 
            WHERE passenger_id IN (
                SELECT passenger_id FROM passengers WHERE pnr = ?
            )
        """, (new_flight_number, pnr))
        
        conn.commit()
        print(f"[OK] PNR {pnr} successfully rebooked to flight {new_flight_number}")
        return True
    except sqlite3.Error as e:
        print(f"RecoverAI Agent: Error updating PNR flight: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()


def get_pnr_passenger_count(pnr: str) -> int:
    """Get the number of passengers in a PNR."""
    conn = _conn()
    cursor = conn.cursor()
    cursor.execute("SELECT passenger_count FROM pnrs WHERE pnr = ?", (pnr,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else 0


def check_flight_capacity(flight_number: str, required_seats: int, exclude_pnr: str = None) -> bool:
    """
    Check if a flight has enough available seats for a group.
    
    Parameters:
    - flight_number: The flight to check
    - required_seats: Number of seats needed
    - exclude_pnr: PNR to exclude from booked count (useful when rebooking)
    """
    conn = _conn()
    cursor = conn.cursor()
    
    # Get aircraft capacity
    cursor.execute("""
        SELECT a.capacity
        FROM aircraft a
        JOIN flights f ON f.aircraft_id = a.aircraft_id
        WHERE f.flight_number = ?
    """, (flight_number,))
    
    row = cursor.fetchone()
    capacity = int(row[0]) if row else 0
    
    # Count currently booked passengers (excluding specific PNR if provided)
    if exclude_pnr:
        cursor.execute("""
            SELECT COALESCE(SUM(pr.passenger_count), 0)
            FROM pnrs pr
            WHERE pr.flight_number = ? AND pr.pnr != ?
        """, (flight_number, exclude_pnr))
    else:
        cursor.execute("""
            SELECT COALESCE(SUM(pr.passenger_count), 0)
            FROM pnrs pr
            WHERE pr.flight_number = ?
        """, (flight_number,))
    
    booked = cursor.fetchone()[0]
    conn.close()
    
    available = capacity - booked
    return available >= required_seats


def update_pnr_status(pnr: str, status: str, new_flight_number: str = None) -> bool:
    """
    Update PNR status based on passenger decision.
    
    Status values:
    - 'Rebooked' - Passenger accepted alternative flight
    - 'Waiting' - Passenger chose to wait for updates
    - 'Cancelled' - Passenger cancelled booking
    - 'Confirmed' - Original booking (default)
    
    Args:
        pnr: PNR code
        status: New status value
        new_flight_number: New flight number (for rebooked status)
    
    Returns:
        True if update successful, False otherwise
    """
    conn = _conn()
    cursor = conn.cursor()
    
    try:
        if new_flight_number:
            # Update PNR with new flight and status
            cursor.execute(
                "UPDATE pnrs SET status = ?, flight_number = ? WHERE pnr = ?",
                (status, new_flight_number, pnr)
            )
        else:
            # Update PNR status only
            cursor.execute(
                "UPDATE pnrs SET status = ? WHERE pnr = ?",
                (status, pnr)
            )
        
        conn.commit()
        print(f"[OK] PNR {pnr} status updated to: {status}")
        return True
        
    except sqlite3.Error as e:
        print(f"[ERROR] Failed to update PNR status: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()


def get_disrupted_pnrs_active() -> list:
    """
    Get list of PNRs with disrupted flights that still need assistance.
    Excludes PNRs that have been: Rebooked, Cancelled, or are Waiting.
    
    Returns:
        List of dicts with PNR details for affected passengers still needing action
    """
    conn = _conn()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT 
            p.pnr,
            p.lead_passenger_name,
            p.flight_number,
            p.passenger_count,
            p.status as pnr_status,
            f.status as flight_status
        FROM pnrs p
        JOIN flights f ON p.flight_number = f.flight_number
        WHERE f.status IN ('Cancelled', 'Delayed')
        AND p.status NOT IN ('Rebooked', 'Cancelled', 'Waiting')
        ORDER BY f.status DESC, p.lead_passenger_name
    """)
    
    results = []
    for row in cursor.fetchall():
        results.append({
            "pnr": row[0],
            "lead_passenger_name": row[1],
            "flight_number": row[2],
            "passenger_count": row[3],
            "pnr_status": row[4],
            "flight_status": row[5]
        })
    
    conn.close()
    return results


def get_pnr_action_history(pnr: str) -> dict:
    """
    Get the action history for a PNR.
    
    Returns:
        Dict with PNR status information
    """
    conn = _conn()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT 
            p.pnr,
            p.status,
            p.flight_number,
            f.status as flight_status,
            p.lead_passenger_name,
            p.passenger_count
        FROM pnrs p
        JOIN flights f ON p.flight_number = f.flight_number
        WHERE p.pnr = ?
    """, (pnr,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return {
            "pnr": row[0],
            "pnr_status": row[1],
            "current_flight": row[2],
            "flight_status": row[3],
            "lead_passenger": row[4],
            "passenger_count": row[5]
        }
    return None
