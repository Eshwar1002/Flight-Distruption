# db_setup.py - MULTI-PASSENGER PNR SUPPORT
import sqlite3
import os
import random
from datetime import datetime, timedelta
from config import DB_PATH

if os.path.exists(DB_PATH):
    os.remove(DB_PATH)
    print("RecoverAI Agent: Old database deleted.")

# Use direct connection for database setup (before pool is initialized)
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()

# ------------------------------
# Create Tables - UPDATED SCHEMA
# ------------------------------
c.execute("""
CREATE TABLE flights (
    flight_number TEXT PRIMARY KEY,
    origin TEXT,
    destination TEXT,
    departure_time TEXT,
    arrival_time TEXT,
    aircraft_id TEXT,
    aircraft_type TEXT,
    status TEXT,
    cost REAL,
    distance REAL
)""")

# NEW: PNR table to track bookings (one PNR can have multiple passengers)
c.execute("""
CREATE TABLE pnrs (
    pnr TEXT PRIMARY KEY,
    flight_number TEXT,
    booking_date TEXT,
    lead_passenger_name TEXT,
    passenger_count INTEGER,
    status TEXT,
    FOREIGN KEY(flight_number) REFERENCES flights(flight_number)
)""")

# UPDATED: Passengers now reference PNR (many passengers to one PNR)
c.execute("""
CREATE TABLE passengers (
    passenger_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pnr TEXT,
    name TEXT,
    seat TEXT,
    class_of_service TEXT,
    passenger_type TEXT,
    age_group TEXT,
    FOREIGN KEY(pnr) REFERENCES pnrs(pnr)
)""")

c.execute("""
CREATE TABLE seat_assignments (
    seat_id INTEGER PRIMARY KEY AUTOINCREMENT,
    passenger_id INTEGER,
    flight_number TEXT,
    seat_number TEXT,
    FOREIGN KEY(passenger_id) REFERENCES passengers(passenger_id)
)""")

c.execute("""
CREATE TABLE crew (
    crew_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    role TEXT,
    location TEXT,
    duty_hours INTEGER,
    is_reserve BOOLEAN,
    available_at TEXT
)""")

c.execute("""
CREATE TABLE aircraft (
    aircraft_id TEXT PRIMARY KEY,
    location TEXT,
    status TEXT,
    aircraft_type TEXT,
    is_reserve BOOLEAN,
    capacity INTEGER
)""")

c.execute("""
CREATE TABLE oag_flights (
    flight_number TEXT PRIMARY KEY,
    origin TEXT,
    destination TEXT,
    departure_time TEXT,
    arrival_time TEXT,
    aircraft_type TEXT,
    status TEXT,
    cost REAL,
    distance REAL
)""")

# ------------------------------
# Helper Functions
# ------------------------------
def generate_passenger_name():
    first_names = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", 
                  "William", "Elizabeth", "David", "Susan", "Richard", "Jessica", "Joseph", "Sarah",
                  "Thomas", "Karen", "Charles", "Nancy", "Christopher", "Lisa", "Daniel", "Betty",
                  "Matthew", "Dorothy", "Anthony", "Sandra", "Mark", "Ashley", "Emma", "Olivia",
                  "Sophia", "Liam", "Noah", "Ava", "Isabella", "Ethan", "Mason", "Mia"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
                 "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
                 "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
                 "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def generate_family_names(last_name, count):
    """Generate family members with same last name"""
    first_names = {
        "adult": ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda"],
        "child": ["Emma", "Olivia", "Sophia", "Liam", "Noah", "Ava", "Isabella", "Ethan"],
        "infant": ["Baby"]
    }
    
    names = []
    for i in range(count):
        if i == 0:
            age_group = "adult"
            passenger_type = "lead"
        elif i < 2:
            age_group = "adult"
            passenger_type = "adult"
        elif i < count - 1:
            age_group = "child"
            passenger_type = "child"
        else:
            age_group = random.choice(["child", "infant"])
            passenger_type = age_group
        
        first = random.choice(first_names[age_group])
        names.append((f"{first} {last_name}", passenger_type, age_group))
    
    return names

def generate_pnr():
    """Generate realistic PNR (6 alphanumeric characters)"""
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # Exclude confusing chars
    return ''.join(random.choice(chars) for _ in range(6))

def generate_seat(class_of_service, used_seats):
    """Generate seat avoiding duplicates"""
    max_attempts = 100
    for _ in range(max_attempts):
        if class_of_service == "Business":
            seat = f"{random.randint(1, 8)}{chr(random.randint(65, 68))}"  # A-D
        else:
            seat = f"{random.randint(10, 30)}{chr(random.randint(65, 70))}"  # A-F
        
        if seat not in used_seats:
            used_seats.add(seat)
            return seat
    
    return f"{random.randint(1, 30)}{chr(random.randint(65, 70))}"

# ------------------------------
# Aircraft Data - CREATE FIRST (needed for flight references)
# ------------------------------
print("Creating aircraft fleet...")
aircraft_types = {
    "A320": {"capacity": 158, "count": 15},
    "B737": {"capacity": 172, "count": 12},
    "B787": {"capacity": 297, "count": 8},
    "B777": {"capacity": 390, "count": 6},
    "A330": {"capacity": 158, "count": 5}
}

aircraft = []
locations = ["JFK", "LAX", "ORD", "DFW", "MIA", "SFO"]
aircraft_id_counter = 1

for ac_type, specs in aircraft_types.items():
    for i in range(specs["count"]):
        aircraft_id = f"AC{aircraft_id_counter:03d}"
        location = random.choice(locations)
        is_reserve = random.choices([0, 1], weights=[0.85, 0.15])[0]
        status = "Available" if is_reserve == 0 else "Reserve"
        
        aircraft.append((
            aircraft_id, location, status, ac_type, is_reserve, specs["capacity"]
        ))
        aircraft_id_counter += 1

c.executemany("INSERT INTO aircraft VALUES (?,?,?,?,?,?)", aircraft)

# ------------------------------
# Insert Flights (with valid aircraft IDs)
# ------------------------------
now = datetime.now()
fmt = "%Y-%m-%d %H:%M:%S"

routes = [
    ("JFK", "LAX", 4000, 6.0),
    ("JFK", "SFO", 4200, 6.5),
    ("JFK", "MIA", 1800, 3.0),
    ("JFK", "ORD", 1200, 2.5),
    ("LAX", "JFK", 4000, 5.5),
    ("LAX", "ORD", 2800, 4.0),
    ("LAX", "DFW", 2000, 3.0),
    ("ORD", "JFK", 1200, 2.0),
    ("ORD", "LAX", 2800, 4.5),
    ("DFW", "LAX", 2000, 3.0),
    ("MIA", "JFK", 1800, 3.0),
    ("SFO", "JFK", 4200, 5.0),
]

# Disrupted flights - MORE VARIETY (use actual aircraft IDs)
disrupted_flights = []
aircraft_for_disrupted = [ac for ac in aircraft if ac[3] in ["A320", "B777", "B787", "B737"]][:6]

disrupted_config = [
    ("SA101", "JFK", "LAX", 2, 8, "Cancelled", 450, 4000),
    ("SA104", "JFK", "LAX", 10, 16, "Delayed", 580, 4000),
    ("SA201", "JFK", "SFO", 3, 9.5, "Delayed", 620, 4200),
    ("SA301", "JFK", "MIA", 1, 4, "Cancelled", 320, 1800),
    ("SA305", "LAX", "JFK", 4, 9.5, "Cancelled", 500, 4000),
    ("SA401", "ORD", "LAX", 5, 9.5, "Delayed", 420, 2800),
]

for i, config in enumerate(disrupted_config):
    flight_num, origin, dest, dep_hours, arr_hours, status, cost, distance = config
    aircraft_id = aircraft_for_disrupted[i][0]
    aircraft_type = aircraft_for_disrupted[i][3]
    
    disrupted_flights.append((
        flight_num, origin, dest,
        now + timedelta(hours=dep_hours),
        now + timedelta(hours=arr_hours),
        aircraft_id, aircraft_type, status, cost, distance
    ))

# Scheduled flights - MORE FLIGHTS FOR REALISTIC CAPACITY (use actual aircraft IDs)
scheduled_flights = []
flight_counter = 500
available_aircraft = [ac for ac in aircraft if ac[2] == "Available"]

# Generate more frequent flights on popular routes
for hour_offset in range(0, 24, 1):  # Every hour instead of every 2 hours
    for route in random.sample(routes, min(6, len(routes))):  # More routes per hour
        origin, dest, distance, duration = route
        departure = now + timedelta(hours=hour_offset + random.uniform(-0.3, 0.3))
        arrival = departure + timedelta(hours=duration)
        
        # Pick a random available aircraft
        selected_aircraft = random.choice(available_aircraft)
        aircraft_id = selected_aircraft[0]
        aircraft_type = selected_aircraft[3]
        
        base_cost = 200 + (distance * 0.08)
        
        scheduled_flights.append((
            f"SA{flight_counter}", origin, dest, 
            departure, arrival, 
            aircraft_id, aircraft_type, "Scheduled", 
            round(base_cost * random.uniform(0.9, 1.2), 2), distance
        ))
        flight_counter += 1

# Reserve flights - MORE RESERVE CAPACITY (use reserve aircraft)
reserve_aircraft = [ac for ac in aircraft if ac[2] == "Reserve" or ac[4] == 1][:5]
reserve_flights = []

reserve_config = [
    ("SA901", "JFK", "LAX", 6, 12, "Reserve", 550, 4000),
    ("SA902", "JFK", "SFO", 8, 14.5, "Reserve", 650, 4200),
    ("SA903", "JFK", "MIA", 5, 8, "Reserve", 350, 1800),
    ("SA904", "JFK", "LAX", 9, 15, "Reserve", 520, 4000),
    ("SA905", "LAX", "JFK", 7, 12.5, "Reserve", 600, 4000),
]

for i, config in enumerate(reserve_config):
    if i < len(reserve_aircraft):
        flight_num, origin, dest, dep_hours, arr_hours, status, cost, distance = config
        aircraft_id = reserve_aircraft[i][0]
        aircraft_type = reserve_aircraft[i][3]
        
        reserve_flights.append((
            flight_num, origin, dest,
            now + timedelta(hours=dep_hours),
            now + timedelta(hours=arr_hours),
            aircraft_id, aircraft_type, status, cost, distance
        ))

all_flights = disrupted_flights + scheduled_flights + reserve_flights

print(f"📊 Inserting {len(all_flights)} flights...")
c.executemany("INSERT INTO flights VALUES (?,?,?,?,?,?,?,?,?,?)", [
    (f[0], f[1], f[2], f[3].strftime(fmt), f[4].strftime(fmt), f[5], f[6], f[7], f[8], f[9])
    for f in all_flights
])

# ------------------------------
# OAG Flights - INCREASE PARTNER AIRLINES
# ------------------------------
oag_airlines = ["UA", "AA", "DL", "B6", "AS", "WN", "NK", "F9"]  # Added more airlines
oag_flights = []
oag_counter = 1000

# Generate more frequent OAG flights
for hour_offset in range(2, 24, 2):  # More frequent
    for route in random.sample(routes, min(5, len(routes))):  # More routes
        origin, dest, distance, duration = route
        departure = now + timedelta(hours=hour_offset + random.uniform(-0.8, 0.8))
        arrival = departure + timedelta(hours=duration)
        
        airline = random.choice(oag_airlines)
        aircraft_type = random.choice(["A320", "B737", "B787", "B777", "A330"])
        base_cost = 250 + (distance * 0.1)
        
        oag_flights.append((
            f"{airline}{oag_counter}", origin, dest,
            departure.strftime(fmt), arrival.strftime(fmt),
            aircraft_type, "Scheduled", 
            round(base_cost * random.uniform(0.9, 1.3), 2), distance
        ))
        oag_counter += 1

print(f"📊 Inserting {len(oag_flights)} OAG flights...")
c.executemany("INSERT INTO oag_flights VALUES (?,?,?,?,?,?,?,?,?)", oag_flights)

# ------------------------------
# Seed PNRs and Passengers - REALISTIC MULTI-PASSENGER
# ------------------------------
print("Generating PNRs and passengers...")
pnrs_data = []
passengers_data = []
passenger_id_counter = 1

# Helper to create PNR with passengers
def create_booking(flight_number, passenger_count, class_distribution):
    """Create a PNR with multiple passengers"""
    pnr = generate_pnr()
    last_name = random.choice(["Smith", "Johnson", "Garcia", "Martinez", "Wilson", "Brown", "Davis", "Lopez"])
    
    # Generate family members
    family_members = generate_family_names(last_name, passenger_count)
    lead_name = family_members[0][0]
    
    # Create PNR record
    booking_date = (now - timedelta(days=random.randint(1, 90))).strftime(fmt)
    pnrs_data.append((pnr, flight_number, booking_date, lead_name, passenger_count, "Confirmed"))
    
    # Create passenger records
    passengers = []
    for name, ptype, age_group in family_members:
        # Distribute classes - families usually book same class
        if passenger_count == 1:
            cos = random.choices(["Economy", "Business"], weights=[0.85, 0.15])[0]
        else:
            # Families more likely in economy
            cos = random.choices(["Economy", "Business"], weights=class_distribution)[0]
        
        passengers.append((pnr, name, None, cos, ptype, age_group))  # seat assigned later
    
    return pnr, passengers

# Disrupted flights - mix of solo and group travelers - REALISTIC CAPACITY
for flight in disrupted_flights:
    flight_number = flight[0]
    
    # Generate realistic mix with HIGH occupancy (nearly full flights)
    bookings_config = [
        (1, 25),  # 25 solo travelers
        (2, 15),  # 15 couples
        (3, 8),   # 8 small families
        (4, 5),   # 5 larger families
        (5, 2),   # 2 large groups
        (6, 1),   # 1 very large group
    ]
    
    for pax_count, num_bookings in bookings_config:
        for _ in range(num_bookings):
            # Families more likely in economy (95/5), solo more mixed (80/20)
            class_dist = [0.95, 0.05] if pax_count > 1 else [0.80, 0.20]
            pnr, passengers = create_booking(flight_number, pax_count, class_dist)
            passengers_data.extend(passengers)

# Scheduled flights - REALISTIC loads (60-85% full)
for flight in random.sample(scheduled_flights, min(80, len(scheduled_flights))):  # More flights booked
    flight_number = flight[0]
    
    # Determine load factor (60-85%)
    load_factor = random.uniform(0.60, 0.85)
    
    # Get aircraft capacity (estimate based on type)
    aircraft_type = flight[6]
    capacity_map = {"A320": 158, "B737": 172, "B787": 297, "B777": 390}
    capacity = capacity_map.get(aircraft_type, 158)
    
    target_passengers = int(capacity * load_factor)
    
    # Create realistic booking distribution
    remaining = target_passengers
    while remaining > 0:
        if remaining >= 5:
            pax_count = random.choices([1, 2, 3, 4, 5], weights=[35, 30, 20, 10, 5])[0]
        elif remaining >= 3:
            pax_count = random.choices([1, 2, 3], weights=[40, 40, 20])[0]
        elif remaining >= 2:
            pax_count = random.choices([1, 2], weights=[50, 50])[0]
        else:
            pax_count = 1
        
        pax_count = min(pax_count, remaining)
        class_dist = [0.90, 0.10] if pax_count > 1 else [0.85, 0.15]
        pnr, passengers = create_booking(flight_number, pax_count, class_dist)
        passengers_data.extend(passengers)
        remaining -= pax_count

# Reserve flights - MODERATE bookings (30-50% full)
for flight in reserve_flights:
    flight_number = flight[0]
    
    # Reserve flights less booked
    aircraft_type = flight[6]
    capacity_map = {"A320": 158, "B737": 172, "B787": 297, "B777": 390}
    capacity = capacity_map.get(aircraft_type, 158)
    
    target_passengers = int(capacity * random.uniform(0.30, 0.50))
    
    remaining = target_passengers
    while remaining > 0:
        if remaining >= 4:
            pax_count = random.choices([1, 2, 3, 4], weights=[40, 30, 20, 10])[0]
        elif remaining >= 2:
            pax_count = random.choices([1, 2], weights=[60, 40])[0]
        else:
            pax_count = 1
        
        pax_count = min(pax_count, remaining)
        class_dist = [0.92, 0.08] if pax_count > 1 else [0.88, 0.12]
        pnr, passengers = create_booking(flight_number, pax_count, class_dist)
        passengers_data.extend(passengers)
        remaining -= pax_count

# OAG Flights - VARYING loads (40-80% full)
for flight in random.sample(oag_flights, min(40, len(oag_flights))):
    flight_number = flight[0]
    
    aircraft_type = flight[5]
    capacity_map = {"A320": 158, "B737": 172, "B787": 297, "B777": 390, "A330": 158}
    capacity = capacity_map.get(aircraft_type, 158)
    
    # OAG flights have varying loads
    target_passengers = int(capacity * random.uniform(0.40, 0.80))
    
    remaining = target_passengers
    while remaining > 0:
        if remaining >= 4:
            pax_count = random.choices([1, 2, 3, 4], weights=[45, 30, 15, 10])[0]
        elif remaining >= 2:
            pax_count = random.choices([1, 2], weights=[55, 45])[0]
        else:
            pax_count = 1
        
        pax_count = min(pax_count, remaining)
        class_dist = [0.88, 0.12] if pax_count > 1 else [0.82, 0.18]
        pnr, passengers = create_booking(flight_number, pax_count, class_dist)
        passengers_data.extend(passengers)
        remaining -= pax_count

print(f"📊 Inserting {len(pnrs_data)} PNRs...")
c.executemany("INSERT INTO pnrs VALUES (?,?,?,?,?,?)", pnrs_data)

print(f"📊 Inserting {len(passengers_data)} passengers...")
c.executemany("INSERT INTO passengers (pnr, name, seat, class_of_service, passenger_type, age_group) VALUES (?,?,?,?,?,?)", 
              passengers_data)

# ------------------------------
# Assign Seats Per Flight
# ------------------------------
print("Assigning seats...")
c.execute("SELECT DISTINCT flight_number FROM passengers p JOIN pnrs pr ON p.pnr = pr.pnr")
flights_with_passengers = [row[0] for row in c.fetchall()]

seat_assignments = []
for flight_number in flights_with_passengers:
    used_seats = set()
    
    c.execute("""
        SELECT p.passenger_id, p.class_of_service 
        FROM passengers p 
        JOIN pnrs pr ON p.pnr = pr.pnr 
        WHERE pr.flight_number = ?
        ORDER BY p.pnr, p.passenger_id
    """, (flight_number,))
    
    passengers_on_flight = c.fetchall()
    
    for passenger_id, cos in passengers_on_flight:
        seat = generate_seat(cos, used_seats)
        c.execute("UPDATE passengers SET seat = ? WHERE passenger_id = ?", (seat, passenger_id))
        seat_assignments.append((passenger_id, flight_number, seat))

c.executemany("INSERT INTO seat_assignments (passenger_id, flight_number, seat_number) VALUES (?,?,?)", 
              seat_assignments)

# ------------------------------
# Crew Data
# ------------------------------
crew_positions = [
    ("John Captain", "CP", "JFK", 4, 0, now.strftime(fmt)),
    ("Jane First", "FO", "JFK", 3, 0, now.strftime(fmt)),
    ("Mike Senior", "CP", "LAX", 2, 0, now.strftime(fmt)),
    ("Sarah CoPilot", "FO", "LAX", 5, 0, now.strftime(fmt)),
    ("Robert Veteran", "CP", "ORD", 6, 0, now.strftime(fmt)),
    ("Lisa Junior", "FO", "ORD", 1, 0, now.strftime(fmt)),
    ("Emily Attendant", "FA", "JFK", 4, 0, now.strftime(fmt)),
    ("David SeniorFA", "FA", "JFK", 5, 0, now.strftime(fmt)),
    ("Maria LeadFA", "FA", "LAX", 3, 0, now.strftime(fmt)),
    ("Chris Attendant", "FA", "LAX", 2, 0, now.strftime(fmt)),
    ("Jessica Attendant", "FA", "ORD", 4, 0, now.strftime(fmt)),
    ("Alex ReserveCP", "CP", "JFK", 0, 1, now.strftime(fmt)),
    ("Taylor ReserveFO", "FO", "JFK", 0, 1, now.strftime(fmt)),
    ("Morgan ReserveFA", "FA", "JFK", 0, 1, now.strftime(fmt)),
]

c.executemany("INSERT INTO crew (name,role,location,duty_hours,is_reserve,available_at) VALUES (?,?,?,?,?,?)", 
              crew_positions)

# ------------------------------
# Commit and Summary
# ------------------------------
conn.commit()

# Print statistics
c.execute("SELECT COUNT(*) FROM pnrs")
pnr_count = c.fetchone()[0]

c.execute("SELECT COUNT(*) FROM passengers")
passenger_count = c.fetchone()[0]

c.execute("SELECT AVG(passenger_count) FROM pnrs")
avg_pax_per_pnr = c.fetchone()[0]

c.execute("""
    SELECT pr.pnr, pr.lead_passenger_name, pr.passenger_count, pr.flight_number, f.status
    FROM pnrs pr
    JOIN flights f ON pr.flight_number = f.flight_number
    WHERE f.status IN ('Cancelled', 'Delayed')
    LIMIT 10
""")
disrupted_pnrs = c.fetchall()

# Commit all changes before closing connection
conn.commit()

print("✅ Enhanced multi-passenger database setup complete!")
print(f"\n📊 Database Statistics:")
print(f"   - {len(all_flights)} flights (including {len(disrupted_flights)} disrupted)")
print(f"   - {pnr_count} PNRs (bookings)")
print(f"   - {passenger_count} passengers")
print(f"   - {avg_pax_per_pnr:.1f} average passengers per PNR")
print(f"   - {len(crew_positions)} crew members")
print(f"   - {len(aircraft)} aircraft")
print(f"   - {len(oag_flights)} partner airline flights")

print(f"\n🛑 Sample Disrupted PNRs (Multi-Passenger):")
for pnr, lead_name, pax_count, flight, status in disrupted_pnrs:
    passenger_str = f"{pax_count} passenger" if pax_count == 1 else f"{pax_count} passengers"
    print(f"   PNR: {pnr}, Lead: {lead_name}, Flight: {flight}, Status: {status}, Passengers: {pax_count}")

# Show capacity analysis for disrupted routes (using a new connection for analysis)
print(f"\n✈️  Flight Capacity Analysis (Disrupted Routes):")
conn2 = sqlite3.connect(DB_PATH)
c2 = conn2.cursor()

for flight in disrupted_flights:
    flight_number = flight[0]
    origin, dest = flight[1], flight[2]
    
    # Get booked passengers on this flight
    c2.execute("""
        SELECT SUM(pr.passenger_count) 
        FROM pnrs pr 
        WHERE pr.flight_number = ?
    """, (flight_number,))
    booked = c2.fetchone()[0] or 0
    
    # Get aircraft capacity
    c2.execute("""
        SELECT a.capacity 
        FROM aircraft a 
        JOIN flights f ON f.aircraft_id = a.aircraft_id 
        WHERE f.flight_number = ?
    """, (flight_number,))
    capacity_row = c2.fetchone()
    capacity = capacity_row[0] if capacity_row else 0
    
    occupancy = (booked / capacity * 100) if capacity > 0 else 0
    
    print(f"   {flight_number} ({origin}→{dest}): {booked}/{capacity} seats ({occupancy:.1f}% full)")

# Show alternative flight availability
print(f"\n🔄 Alternative Flight Availability (JFK→LAX within next 12 hours):")
c2.execute("""
    SELECT f.flight_number, f.departure_time, a.capacity,
           COALESCE(SUM(pr.passenger_count), 0) as booked
    FROM flights f
    LEFT JOIN aircraft a ON f.aircraft_id = a.aircraft_id
    LEFT JOIN pnrs pr ON f.flight_number = pr.flight_number
    WHERE f.origin = 'JFK' AND f.destination = 'LAX'
      AND f.status = 'Scheduled'
      AND datetime(f.departure_time) BETWEEN datetime('now') AND datetime('now', '+12 hours')
    GROUP BY f.flight_number
    ORDER BY f.departure_time
    LIMIT 5
""")

for row in c2.fetchall():
    flight_num, dept_time, cap, booked = row
    available = (cap or 0) - booked
    occupancy = (booked / cap * 100) if cap and cap > 0 else 0
    print(f"   {flight_num} @ {dept_time}: {available}/{cap} available ({occupancy:.1f}% full)")

conn2.close()