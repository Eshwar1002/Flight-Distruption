#!/usr/bin/env python3
"""
RAG Knowledge Base Setup and Testing Utility
Helps initialize, test, and manage the flight policy knowledge base.
"""

import os
import sys
from pathlib import Path

def print_header(text):
    """Print formatted header."""
    print("\n" + "=" * 70)
    print(f"  {text}")
    print("=" * 70 + "\n")


def check_environment():
    """Check if environment is properly configured."""
    print_header("Checking Environment Configuration")
    
    from config import (
        AZURE_OPENAI_API_KEY,
        AZURE_OPENAI_ENDPOINT,
        AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
        POLICIES_DIR,
    )
    
    issues = []
    
    # Check Azure credentials
    if not AZURE_OPENAI_API_KEY:
        issues.append("❌ AZURE_OPENAI_API_KEY not set")
    else:
        print("✅ AZURE_OPENAI_API_KEY is set")
    
    if not AZURE_OPENAI_ENDPOINT:
        issues.append("❌ AZURE_OPENAI_ENDPOINT not set")
    else:
        print(f"✅ AZURE_OPENAI_ENDPOINT: {AZURE_OPENAI_ENDPOINT}")
    
    if not AZURE_OPENAI_EMBEDDING_DEPLOYMENT:
        issues.append("❌ AZURE_OPENAI_EMBEDDING_DEPLOYMENT not set")
    else:
        print(f"✅ Embedding Deployment: {AZURE_OPENAI_EMBEDDING_DEPLOYMENT}")
    
    # Check policies directory
    if not POLICIES_DIR.exists():
        issues.append(f"❌ Policies directory not found: {POLICIES_DIR}")
    else:
        pdf_files = list(POLICIES_DIR.glob("*.pdf"))
        if not pdf_files:
            issues.append(f"⚠️  No PDF files found in {POLICIES_DIR}")
        else:
            print(f"✅ Found {len(pdf_files)} PDF file(s) in policies directory")
    
    return issues


def check_dependencies():
    """Check if required packages are installed."""
    print_header("Checking Dependencies")
    
    required = [
        "langchain",
        "langchain_community",
        "langchain_openai",
        "faiss",
        "pypdf",
        "tiktoken",
    ]
    
    missing = []
    for package in required:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package} not installed")
            missing.append(package)
    
    return missing


def initialize_kb(rebuild=False):
    """Initialize or rebuild the knowledge base."""
    action = "Rebuilding" if rebuild else "Initializing"
    print_header(f"{action} Knowledge Base")
    
    try:
        from rag_knowledge_base import initialize_knowledge_base
        
        kb = initialize_knowledge_base(rebuild=rebuild)
        
        print(f"\n✅ Knowledge base {action.lower()} completed successfully!")
        return kb
    except Exception as e:
        print(f"\n❌ Error {action.lower()} knowledge base: {e}")
        import traceback
        traceback.print_exc()
        return None


def show_stats(kb):
    """Display knowledge base statistics."""
    print_header("Knowledge Base Statistics")
    
    stats = kb.get_stats()
    
    for key, value in stats.items():
        if key == "pdf_files":
            print(f"\n📄 PDF Files:")
            for i, pdf in enumerate(value, 1):
                print(f"   {i}. {pdf}")
        else:
            print(f"  {key}: {value}")


def test_queries(kb):
    """Run test queries against the knowledge base."""
    print_header("Testing Knowledge Base Queries")
    
    test_queries_list = [
        "What are the rebooking policies for cancelled flights?",
        "What compensation is available for delayed flights?",
        "What are the policies for group bookings?",
        "What are passenger rights during flight disruptions?",
        "What is the refund policy?",
    ]
    
    for i, query in enumerate(test_queries_list, 1):
        print(f"\n{'─' * 70}")
        print(f"Test Query {i}: {query}")
        print('─' * 70)
        
        try:
            results = kb.query(query, top_k=3)
            
            if not results:
                print("⚠️  No results found")
            else:
                print(f"✅ Found {len(results)} relevant excerpts:\n")
                for j, result in enumerate(results, 1):
                    print(f"  Excerpt {j} (from {result['source']}, page {result['page']}):")
                    preview = result['content'][:200] + "..." if len(result['content']) > 200 else result['content']
                    print(f"  {preview}")
                    print(f"  Similarity Score: {result['similarity_score']:.4f}\n")
        except Exception as e:
            print(f"❌ Error: {e}")


def interactive_query(kb):
    """Interactive query mode."""
    print_header("Interactive Query Mode")
    print("Enter your queries (or 'quit' to exit):\n")
    
    while True:
        try:
            query = input("Query: ").strip()
            
            if query.lower() in ['quit', 'exit', 'q']:
                break
            
            if not query:
                continue
            
            print("\n🔍 Searching knowledge base...")
            result = kb.query_with_context(query)
            print("\n" + result)
            print("\n" + "─" * 70 + "\n")
            
        except KeyboardInterrupt:
            print("\n\nExiting interactive mode...")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}\n")


def main_menu():
    """Display main menu and handle user choices."""
    print_header("RecoverAI RAG Knowledge Base Setup & Testing")
    
    print("""
Available Options:
    
1. Check Environment & Dependencies
2. Initialize Knowledge Base (First Time)
3. Rebuild Knowledge Base (From Scratch)
4. Show Knowledge Base Statistics
5. Run Test Queries
6. Interactive Query Mode
7. Full Setup & Test (Run All)
0. Exit

    """)
    
    choice = input("Select option (0-7): ").strip()
    return choice


def run_full_setup():
    """Run complete setup and testing."""
    print_header("Running Full Setup & Test")
    
    # Check environment
    issues = check_environment()
    if issues:
        print("\n⚠️  Environment Issues:")
        for issue in issues:
            print(f"  {issue}")
        print("\nPlease fix these issues before continuing.")
        return
    
    # Check dependencies
    missing = check_dependencies()
    if missing:
        print(f"\n⚠️  Missing dependencies. Install with:")
        print(f"pip install {' '.join(missing)}")
        return
    
    # Initialize knowledge base
    kb = initialize_kb(rebuild=False)
    if not kb:
        return
    
    # Show stats
    show_stats(kb)
    
    # Run test queries
    test_queries(kb)
    
    print("\n✅ Full setup and testing completed!")


def main():
    """Main entry point."""
    while True:
        try:
            choice = main_menu()
            
            if choice == "0":
                print("\nGoodbye!\n")
                break
            
            elif choice == "1":
                issues = check_environment()
                missing = check_dependencies()
                
                if not issues and not missing:
                    print("\n✅ All checks passed! Environment is ready.")
                else:
                    if issues:
                        print("\n⚠️  Environment Issues:")
                        for issue in issues:
                            print(f"  {issue}")
                    if missing:
                        print(f"\n⚠️  Install missing packages:")
                        print(f"pip install {' '.join(missing)}")
            
            elif choice == "2":
                kb = initialize_kb(rebuild=False)
                if kb:
                    show_stats(kb)
            
            elif choice == "3":
                confirm = input("⚠️  This will delete and rebuild the entire index. Continue? (yes/no): ")
                if confirm.lower() in ['yes', 'y']:
                    kb = initialize_kb(rebuild=True)
                    if kb:
                        show_stats(kb)
            
            elif choice == "4":
                from rag_knowledge_base import get_knowledge_base
                kb = get_knowledge_base()
                kb.load_or_create_vectorstore()
                show_stats(kb)
            
            elif choice == "5":
                from rag_knowledge_base import get_knowledge_base
                kb = get_knowledge_base()
                kb.load_or_create_vectorstore()
                test_queries(kb)
            
            elif choice == "6":
                from rag_knowledge_base import get_knowledge_base
                kb = get_knowledge_base()
                kb.load_or_create_vectorstore()
                interactive_query(kb)
            
            elif choice == "7":
                run_full_setup()
            
            else:
                print("Invalid option. Please try again.")
            
            input("\nPress Enter to continue...")
            
        except KeyboardInterrupt:
            print("\n\nExiting...\n")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            input("\nPress Enter to continue...")


if __name__ == "__main__":
    main()
