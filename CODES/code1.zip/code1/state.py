# state.py - COMPLETE VERSION
from typing import TypedDict, Dict, Any, Optional, List, Literal

class RecoverAIState(TypedDict, total=False):
    """
    Shared workflow state that flows through all nodes in the graph.
    Each agent adds its structured output here.
    """
    pnr: str
    passenger: Optional[Dict[str, Any]]
    original_flight: Optional[Dict[str, Any]]
    alternatives: Optional[List[Dict[str, Any]]]
    best_alternative: Optional[Dict[str, Any]]
    booking_summary: Optional[Dict[str, Any]]
    cost_summary: Optional[Dict[str, Any]]
    notification: Optional[str]
    summary: Optional[Dict[str, Any]]
    error: Optional[str]
    # Human-in-the-loop fields (interrupt-based, no manual flags)
    passenger_decision: Optional[Literal["wait", "rebook", "cancel", "explore_alternatives", "rebooked", "invalid", "rebook_group", "rebook_split"]]
    human_response: Optional[str]  # User's input when resuming from interrupt
    disruption_type: Optional[str]
    # Dual-option rebooking fields
    dual_option: Optional[bool]  # True if both group and split options available
    group_option: Optional[Dict[str, Any]]  # Single flight for all passengers
    split_option: Optional[Dict[str, Any]]  # Split booking plan
    score_difference: Optional[float]  # Difference in scores between options