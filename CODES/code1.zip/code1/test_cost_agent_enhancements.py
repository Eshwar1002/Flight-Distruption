#!/usr/bin/env python3
"""
Test the enhanced Cost Agent with care obligations and benefits
"""

import sys
sys.path.insert(0, '.')

from tools import calculate_wait_cost, calculate_rebook_cost, calculate_cancellation_cost
import json

def test_wait_cost():
    """Test enhanced wait cost calculation"""
    print("\n" + "="*70)
    print("TEST 1: WAIT COST CALCULATION (Cancelled Flight)")
    print("="*70)
    
    result = calculate_wait_cost.invoke({
        'pnr': 'BB9NSG',
        'original_flight': {
            'flight_number': 'SA101',
            'cost': 450,
            'distance': 5000
        },
        'disruption_type': 'cancelled'
    })
    
    if 'error' in result:
        print(f"❌ ERROR: {result['error']}")
        return
    
    print(f"\n✅ PNR: {result['pnr']}")
    print(f"✅ Passenger Count: {result['passenger_count']}")
    print(f"✅ Passenger Pays: ${result['cost_summary']['passenger_pays']}")
    
    print(f"\n💰 CARE OBLIGATIONS: ${result['cost_summary']['total_care_obligations']}")
    for key, val in result['care_obligations'].items():
        if isinstance(val, dict) and 'provided' in val and val['provided']:
            desc = val.get('description', key)
            total_val = val.get('total_value', val.get('initial_total_value', 0))
            print(f"   • {desc}: ${total_val}")
    
    print(f"\n🎁 VOUCHERS & BENEFITS: ${result['cost_summary']['total_vouchers_and_benefits']}")
    for key, val in result['vouchers_and_benefits'].items():
        if isinstance(val, dict) and 'provided' in val and val['provided']:
            desc = val.get('description', key)
            print(f"   • {desc}: ${val['total_value']}")
    
    print(f"\n📊 TOTAL ENTITLEMENT VALUE: ${result['cost_summary']['total_entitlement_value']}")
    print(f"📊 AIRLINE COST: ${result['cost_summary']['airline_cost']}")
    
    return result


def test_rebook_cost():
    """Test enhanced rebook cost calculation"""
    print("\n" + "="*70)
    print("TEST 2: REBOOK COST CALCULATION (Delayed Flight)")
    print("="*70)
    
    result = calculate_rebook_cost.invoke({
        'pnr': 'BB9NSG',
        'original_flight': {
            'flight_number': 'SA101',
            'cost': 450,
            'distance': 5000
        },
        'alternative_flight': {
            'flight_number': 'SA518',
            'cost': 487.55,
            'distance': 5000
        },
        'disruption_type': 'delayed'
    })
    
    if 'error' in result:
        print(f"❌ ERROR: {result['error']}")
        return
    
    print(f"\n✅ PNR: {result['pnr']}")
    print(f"✅ Passenger Count: {result['passenger_count']}")
    print(f"✅ Original Flight: {result['original_flight']}")
    print(f"✅ Alternative Flight: {result['alternative_flight']}")
    
    print(f"\n💵 FARE COMPARISON:")
    print(f"   Original: ${result['cost_breakdown']['original_cost_per_passenger']}/pax")
    print(f"   Alternative: ${result['cost_breakdown']['alternative_cost_per_passenger']}/pax")
    print(f"   Difference: ${result['cost_breakdown']['fare_difference_per_passenger']}/pax")
    print(f"   Passenger Charge: ${result['rebooking_terms']['passenger_total_charge']}")
    print(f"   Reason: {result['rebooking_terms']['charge_reason']}")
    
    print(f"\n💰 CARE OBLIGATIONS: ${result['care_obligations']['total_care_value']}")
    for key, val in result['care_obligations'].items():
        if isinstance(val, dict) and 'provided' in val and val['provided']:
            desc = val.get('description', key)
            print(f"   • {desc}: ${val['total_value']}")
    
    print(f"\n🎁 VOUCHERS & BENEFITS: ${result['vouchers_and_benefits']['total_vouchers_value']}")
    for key, val in result['vouchers_and_benefits'].items():
        if isinstance(val, dict) and 'provided' in val and val['provided']:
            desc = val.get('description', key)
            print(f"   • {desc}: ${val['total_value']}")
    
    print(f"\n📊 TOTAL PASSENGER BENEFITS: ${result['total_benefits_provided']['total_passenger_benefits']}")
    
    return result


def test_cancellation_cost():
    """Test enhanced cancellation cost calculation"""
    print("\n" + "="*70)
    print("TEST 3: CANCELLATION COST CALCULATION (Cancelled Flight)")
    print("="*70)
    
    result = calculate_cancellation_cost.invoke({
        'pnr': 'BB9NSG',
        'original_flight': {
            'flight_number': 'SA101',
            'cost': 450,
            'distance': 5000
        },
        'disruption_type': 'cancelled'
    })
    
    if 'error' in result:
        print(f"❌ ERROR: {result['error']}")
        return
    
    print(f"\n✅ PNR: {result['pnr']}")
    print(f"✅ Passenger Count: {result['passenger_count']}")
    print(f"✅ Original Ticket Cost: ${result['original_cost_per_passenger']}/pax")
    
    print(f"\n💵 REFUND DETAILS:")
    print(f"   Refund Amount: ${result['refund_details']['refund_amount']}")
    print(f"   Service Fee: ${result['refund_details']['service_fee']}")
    print(f"   Timeline: {result['refund_details']['refund_timeline']}")
    
    print(f"\n💰 EU261 COMPENSATION:")
    if result['eu261_compensation']['eligible']:
        print(f"   Per Passenger: ${result['eu261_compensation']['amount_per_passenger']}")
        print(f"   Total: ${result['eu261_compensation']['total_compensation']}")
        print(f"   Distance: {result['eu261_compensation']['distance_km']} km")
    
    print(f"\n💰 CARE OBLIGATIONS: ${result['care_obligations']['total_care_value']}")
    for key, val in result['care_obligations'].items():
        if isinstance(val, dict) and 'provided' in val and val['provided']:
            desc = val.get('description', key)
            print(f"   • {desc}: ${val['total_value']}")
    
    print(f"\n🎁 VOUCHERS & BENEFITS: ${result['vouchers_and_benefits']['total_vouchers_value']}")
    for key, val in result['vouchers_and_benefits'].items():
        if isinstance(val, dict) and 'provided' in val and val['provided']:
            desc = val.get('description', key)
            print(f"   • {desc}: ${val['total_value']}")
    
    print(f"\n📊 TOTAL PACKAGE:")
    print(f"   Refund: ${result['total_package']['refund_amount']}")
    print(f"   EU261 Compensation: ${result['total_package']['eu261_compensation']}")
    print(f"   Care Obligations: ${result['total_package']['care_obligations']}")
    print(f"   Vouchers & Benefits: ${result['total_package']['vouchers_and_benefits']}")
    print(f"   ✨ TOTAL PASSENGER RECEIVES: ${result['total_package']['total_passenger_receives']}")
    
    return result


if __name__ == "__main__":
    print("\n" + "🔬 COST AGENT ENHANCEMENT - VERIFICATION TESTS")
    print("="*70)
    print("Testing care obligations and benefits integration...")
    
    try:
        # Test 1: Wait Cost
        wait_result = test_wait_cost()
        
        # Test 2: Rebook Cost
        rebook_result = test_rebook_cost()
        
        # Test 3: Cancellation Cost
        cancel_result = test_cancellation_cost()
        
        print("\n" + "="*70)
        print("✅ ALL TESTS COMPLETED SUCCESSFULLY!")
        print("="*70)
        print("\n📋 Summary:")
        print(f"   Wait Cost Total: ${wait_result['cost_summary']['total_entitlement_value']}")
        print(f"   Rebook Benefits: ${rebook_result['total_benefits_provided']['total_passenger_benefits']}")
        print(f"   Cancel Total Package: ${cancel_result['total_package']['total_passenger_receives']}")
        print("\n✅ Cost Agent is now calculating comprehensive care obligations and benefits!")
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
