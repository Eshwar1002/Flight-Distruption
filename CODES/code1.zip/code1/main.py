# main.py
# RecoverAI  Airline Disruption Management (Multi-Agent System with Supervisor)

import os
import sys
from typing import Any, Dict
import time
import atexit

from logger_config import setup_logging, get_logger, log_user_interaction
from supervisor_graph import supervisor
from support_functions import get_disrupted_pnrs_active
from db_pool import DatabasePool, get_pool_stats, close_pool

# Initialize logging
setup_logging()
logger = get_logger('main')

# Initialize database connection pool
logger.info("Initializing database connection pool...")
db_pool = DatabasePool.get_instance()
logger.info(f"Database pool initialized: {get_pool_stats()}")

# Register cleanup function to close pool on exit
def cleanup_db_pool():
    """Close database connection pool on application exit."""
    logger.info("Shutting down database connection pool...")
    close_pool()
    logger.info("Database pool closed")

atexit.register(cleanup_db_pool)

def pretty_print_results(final_state: Dict[str, Any]):
    """Human-readable console output using the summary node only."""
    print("\n" + "=" * 70)
    print("RecoverAI Workflow Results")
    print("=" * 70 + "\n")

    summary = final_state.get("summary", {})
    
    # Basic Information
    print(" BOOKING INFORMATION")
    print("-" * 70)
    print(f"  PNR: {summary.get('pnr', 'N/A')}")
    print(f"  Lead Passenger: {summary.get('lead_passenger', 'Unknown')}")
    print(f"  Passenger Count: {summary.get('passenger_count', 1)} {summary.get('passenger_label', 'passenger')}")
    print(f"  Decision: {summary.get('passenger_decision', 'N/A')}")
    
    # Flight Information
    print(f"\n  FLIGHT INFORMATION")
    print("-" * 70)
    print(f"  Original Flight: {summary.get('original_flight', 'N/A')}")
    print(f"  Rebooked Flight: {summary.get('rebooked_flight', 'N/A')}")
    
    # Cost Breakdown - Enhanced for all action types
    cost_summary = summary.get('disruption_cost', {})
    if isinstance(cost_summary, dict) and cost_summary != "N/A":
        # Check if this is a rebook cost (enhanced)
        if cost_summary.get('action') == 'rebook':
            print(f"\n REBOOK COST BREAKDOWN")
            print("-" * 70)
            if 'error' in cost_summary:
                print(f"    Error: {cost_summary['error']}")
            else:
                cost_bd = cost_summary.get('cost_breakdown', {})
                print(f"  Original Flight Cost: ${cost_bd.get('original_cost_per_passenger', 0):.2f}/passenger")
                print(f"  Alternative Flight Cost: ${cost_bd.get('alternative_cost_per_passenger', 0):.2f}/passenger")
                print(f"  Total Original Cost: ${cost_bd.get('total_original_cost', 0):.2f}")
                print(f"  Total Alternative Cost: ${cost_bd.get('total_alternative_cost', 0):.2f}")
                print(f"  Fare Difference: ${cost_bd.get('fare_difference_per_passenger', 0):.2f}/passenger")
                print(f"  ")
                print(f"  Fare Class: {cost_summary.get('fare_class_message', 'N/A')}")
                print(f"  ")
                
                terms = cost_summary.get('rebooking_terms', {})
                print(f"  Rebooking Terms:")
                print(f"    • Free Rebook: {'Yes' if terms.get('is_free_rebook') else 'No'}")
                if terms.get('rebooking_fee', 0) > 0:
                    print(f"    • Rebooking Fee: ${terms.get('rebooking_fee', 0):.2f}")
                print(f"    • Passenger Total Charge: ${terms.get('passenger_total_charge', 0):.2f}")
                print(f"    • Reason: {terms.get('charge_reason', 'N/A')}")
                print(f"  ")
                print(f"  Policy: {cost_summary.get('policy_compliance', 'N/A')}")
        
        # Check if this is cancellation cost
        elif cost_summary.get('action') == 'cancel':
            print(f"\n CANCELLATION COST BREAKDOWN")
            print("-" * 70)
            if 'error' in cost_summary:
                print(f"    Error: {cost_summary['error']}")
            else:
                print(f"  Original Booking Cost: ${cost_summary.get('total_booking_cost', 0):.2f}")
                print(f"  Refund Percentage: {cost_summary.get('refund_percentage', 100)}%")
                if cost_summary.get('service_fee', 0) > 0:
                    print(f"  Service Fee: ${cost_summary.get('service_fee', 0):.2f}")
                print(f"  Refund Amount: ${cost_summary.get('refund_amount', 0):.2f}")
                print(f"  Compensation (EU261): ${cost_summary.get('compensation_amount', 0):.2f}")
                print(f"  ")
                print(f"  Total Refund + Compensation: ${cost_summary.get('total_refund_and_compensation', 0):.2f}")
                print(f"  Refund Timeline: {cost_summary.get('refund_timeline', 'N/A')}")
                print(f"  Eligibility: {cost_summary.get('eligibility_reason', 'N/A')}")
        
        # Check if this is wait cost
        elif cost_summary.get('action') == 'wait':
            print(f"\n WAIT ENTITLEMENTS")
            print("-" * 70)
            if 'error' in cost_summary:
                print(f"    Error: {cost_summary['error']}")
            else:
                print(f"  Additional Cost to Passenger: ${cost_summary.get('additional_cost_to_passenger', 0):.2f}")
                print(f"  {cost_summary.get('cost_message', 'No cost for waiting')}")
                
                entitlements = cost_summary.get('entitlements', {})
                if entitlements:
                    print(f"\n  Provided Entitlements:")
                    
                    meals = entitlements.get('meal_vouchers', {})
                    if meals.get('provided'):
                        print(f"    • Meal Vouchers: ${meals.get('value_per_passenger', 0):.2f}/passenger")
                    
                    hotel = entitlements.get('hotel_accommodation', {})
                    if hotel.get('provided'):
                        print(f"    • Hotel Accommodation: ${hotel.get('value_per_passenger', 0):.2f}/passenger")
                    
                    transport = entitlements.get('transportation', {})
                    if transport.get('provided'):
                        print(f"    • Transportation: ${transport.get('value_per_passenger', 0):.2f}/passenger")
                    
                    print(f"  ")
                    print(f"  Total Entitlement Value: ${cost_summary.get('total_entitlement_value', 0):.2f}")
        
        # Legacy format (backwards compatibility)
        elif all(cost_summary.get(key) is not None for key in ['original_cost', 'alternative_cost', 'difference']):
            print(f"\n COST BREAKDOWN")
            print("-" * 70)
            original = cost_summary.get('original_cost') or 0
            alternative = cost_summary.get('alternative_cost') or 0
            difference = cost_summary.get('difference') or 0
            penalty = cost_summary.get('disruption_penalty') or 0
            total = cost_summary.get('total_disruption_cost') or 0
            
            print(f"  Original Flight Cost: ${original:.2f}")
            print(f"  Alternative Flight Cost: ${alternative:.2f}")
            print(f"  Fare Difference: ${difference:.2f}")
            print(f"  Disruption Penalty: ${penalty:.2f}")
            print(f"  ")
            print(f"  Total Disruption Cost: ${total:.2f}")
        elif 'error' not in cost_summary:
            print(f"\n COST INFORMATION")
            print("-" * 70)
            print(f"    Cost calculation not available")
    elif cost_summary != "N/A":
        print(f"\n DISRUPTION COST")
        print("-" * 70)
        print(f"  {cost_summary}")
    
    # Booking Details
    booking_summary = summary.get('booking_summary', {})
    if isinstance(booking_summary, dict) and booking_summary != "N/A":
        print(f"\n BOOKING DETAILS")
        print("-" * 70)
        if 'error' in booking_summary and booking_summary['error']:
            print(f"    Error: {booking_summary['error']}")
        else:
            print(f"  Old Flight: {booking_summary.get('old_flight', 'N/A')}")
            print(f"  New Flight: {booking_summary.get('new_flight', 'N/A')}")
            
            # Seat assignments
            seats = booking_summary.get('seat_assignments', [])
            if seats:
                print(f"  Seat Assignments:")
                for seat in seats:
                    print(f"    - {seat.get('name', 'N/A')}: Seat {seat.get('seat', 'N/A')} ({seat.get('class_of_service', 'N/A')})")
    
    # Notification
    notification = summary.get('notification', 'N/A')
    if notification and notification != 'N/A':
        print(f"\n NOTIFICATION")
        print("-" * 70)
        # Truncate long notifications
        if len(notification) > 500:
            print(f"  {notification[:500]}...")
        else:
            print(f"  {notification}")
    
    print("\n" + "=" * 70)
    print("Workflow Complete")
    print("=" * 70 + "\n")


def interactive_workflow_execution(pnr: str):
    """Execute workflow with interrupt-based human-in-the-loop support"""
    state = {"pnr": pnr}
    final_state = None
    
    start_time = time.time()
    logger.info(f"Starting workflow for PNR: {pnr}", extra={"pnr": pnr})
    print(f"[START] Starting workflow for PNR: {pnr}")
    
    # Use thread_id for checkpoint persistence across interrupts
    config = {
        "recursion_limit": 50,
        "configurable": {"thread_id": f"pnr_{pnr}"}
    }
    
    try:
        # Run workflow - will stop at first interrupt (decision node)
        print(f"\n[WORKFLOW] Starting workflow execution...")
        for step in supervisor.stream(state, config=config):
            node_name = list(step.keys())[0]
            node_state = step[node_name]
            
            # Handle tuple responses (interrupts return tuples)
            if isinstance(node_state, tuple):
                # Interrupt occurred - extract state from tuple
                final_state = node_state[0] if len(node_state) > 0 else final_state
            else:
                final_state = node_state
            
            logger.debug(
                f"Workflow step: {node_name}",
                extra={
                    "pnr": pnr,
                    "node": node_name,
                    "passenger_decision": final_state.get('passenger_decision') if isinstance(final_state, dict) else None
                }
            )
            # Only print completion for non-supervisor nodes to avoid duplicate output
            if node_name != "run_supervisor":
                print(f"\n[STEP] Completed: {node_name}")
        
        # Check if we hit an interrupt
        current_state = supervisor.get_state(config)
        
        # Keep resuming until workflow completes (no more interrupts)
        while current_state.next:  # If there are pending nodes, we're interrupted
            print(f"\n[INTERRUPT] Workflow paused at node: {current_state.next}")
            print(f"[INPUT] Please enter your choice: ", end="")
            
            # Get human response
            human_response = input().strip()
            logger.info(f"Received human input: {human_response}", extra={"pnr": pnr, "response": human_response})
            print(f"[RECEIVED] Your choice: {human_response}\n")
            
            log_user_interaction(logger, "human_decision", pnr=pnr, decision=human_response)
            
            # Resume workflow with human response
            print(f"[WORKFLOW] Resuming workflow with your choice...")
            for step in supervisor.stream({"human_response": human_response}, config=config):
                node_name = list(step.keys())[0]
                node_state = step[node_name]
                
                # Handle tuple responses (interrupts return tuples)
                if isinstance(node_state, tuple):
                    # Interrupt occurred - extract state from tuple
                    final_state = node_state[0] if len(node_state) > 0 else final_state
                else:
                    final_state = node_state
                
                logger.debug(
                    f"Workflow step after resume: {node_name}",
                    extra={
                        "pnr": pnr,
                        "node": node_name,
                        "passenger_decision": final_state.get('passenger_decision') if isinstance(final_state, dict) else None
                    }
                )
                # Only print completion for non-supervisor nodes to avoid duplicate output
                if node_name != "run_supervisor":
                    print(f"\n[STEP] Completed: {node_name}")
            
            # Check state again
            current_state = supervisor.get_state(config)
        
        duration_ms = int((time.time() - start_time) * 1000)
        logger.info(
            f"Workflow completed for PNR: {pnr}",
            extra={"pnr": pnr, "duration_ms": duration_ms}
        )
        print(f"\n[COMPLETE] Workflow finished in {duration_ms}ms")
        
    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)
        logger.error(
            f"Workflow failed for PNR: {pnr}",
            extra={"pnr": pnr, "duration_ms": duration_ms},
            exc_info=True
        )
        print(f"\n[ERROR] Workflow failed: {e}")
        raise
    
    return final_state



if __name__ == "__main__":
    logger.info("RecoverAI system starting")
    print("\nRecoverAI + LangGraph  Human-in-the-Loop Rebooking System\n")

    try:
        # --- DB init check ---
        if not os.path.exists("data/recoverai.db"):
            logger.info("Database not found, initializing...")
            print("Initializing database...")
            import db_setup
            logger.info("Database initialized successfully")

        # --- Show disrupted passengers who still need assistance ---
        disrupted = get_disrupted_pnrs_active()
        if disrupted:
            logger.info(f"Found {len(disrupted)} disrupted PNRs requiring assistance")
            print("\n[ALERT] Disrupted Passengers Requiring Assistance:")
            print("-" * 120)
            for d in disrupted:
                passenger_count = d.get('passenger_count', 1)
                passenger_label = "passengers" if passenger_count > 1 else "passenger"
                flight_status = d.get('flight_status', 'Unknown')
                pnr_status = d.get('pnr_status', 'Confirmed')
                
                # Compact 2-line format
                print(f"  PNR: {d['pnr']:<8} | Lead: {d['lead_passenger_name']:<20} | Flight: {d['flight_number']:<6} ({flight_status})")
                print(f"    {pnr_status:<12} | Passengers: {passenger_count} {passenger_label}")
                print()
        else:
            logger.info("No disrupted passengers requiring assistance")
            print("\n[OK] No disrupted passengers requiring assistance.")
            print("All affected bookings have been processed (Rebooked, Cancelled, or Waiting).")
            raise SystemExit(0)

        # --- Ask user to pick a PNR ---
        pnr = input("\nEnter a PNR to process (single PNR): ").strip()
        if not pnr:
            logger.warning("No PNR entered by user")
            print("Please enter a valid PNR.")
            raise SystemExit(0)
        
        log_user_interaction(logger, "pnr_input", pnr=pnr)

        # --- Run enhanced workflow ---
        print(f"\n[START] Starting human-in-the-loop workflow for PNR: {pnr}")
        final_state = interactive_workflow_execution(pnr)

        if not final_state:
            logger.warning(f"Workflow did not complete successfully for PNR: {pnr}", extra={"pnr": pnr})
            print("\n[WARNING] Workflow did not complete successfully.\n")
            raise SystemExit(1)

        # --- Print results ---
        pretty_print_results(final_state)
        logger.info(f"Workflow completed successfully for PNR: {pnr}", extra={"pnr": pnr})
        
    except KeyboardInterrupt:
        logger.warning("System interrupted by user")
        print("\n\n[INTERRUPTED] System interrupted by user")
        raise SystemExit(0)
    except Exception as e:
        logger.critical("Unhandled exception in main", exc_info=True)
        print(f"\n[ERROR] System error: {e}")
        raise SystemExit(1)