#config.py
import os
from pathlib import Path
from dotenv import load_dotenv
from datetime import timedelta

# Base paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

# Load environment variables
load_dotenv(BASE_DIR / ".env")

# Database path
DB_PATH = str(DATA_DIR / "recoverai.db")

# Azure OpenAI Config
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
AZURE_OPENAI_EMBEDDING_DEPLOYMENT = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-ada-002")

# Standard OpenAI Config (for AI Supervisor using GPT-4)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", AZURE_OPENAI_API_KEY)  # Fallback to Azure key if not set

# RAG Knowledge Base Config
POLICIES_DIR = DATA_DIR / "policies"
POLICIES_DIR.mkdir(exist_ok=True)
VECTOR_DB_DIR = DATA_DIR / "vector_db"
VECTOR_DB_DIR.mkdir(exist_ok=True)

# RAG Settings
RAG_CHUNK_SIZE = 1000
RAG_CHUNK_OVERLAP = 200
RAG_TOP_K = 5  # Number of relevant chunks to retrieve

# ------------------------------
# RecoverAI Profile
# ------------------------------
RAI_PROFILE = {
    "airline_name": "Sun Airlines",
    "aircraft_types": ["A320", "B737", "B787", "B777"],
    "crew_roles": ["CP", "FO", "FA"],
    "connection_times": {"domestic": timedelta(minutes=15), "international": timedelta(minutes=30)},
    "long_haul_augmented_crew": True,
    "reserve_crew_and_aircraft": True,
    "crew_round_trip": True,
    "protect_pnr": True,
    "pnr_seat_assignment": True,
    "airports": {
        "domestic": ["JFK", "LAX", "ORD", "ATL", "DFW", "DEN", "SFO", "SEA", "MIA"],
        "international": ["HND", "ICN", "PVG", "HKG", "SIN", "LHR", "CDG", "FRA", "AMS", "MAD", "CUN", "PUJ", "MBJ", "SJU", "NAS"],
    },
    "home_bases": {"domestic": "DEN", "asia": "PVG", "europe": "FRA", "caribbean": "CUN"},
    "maintenance_bases": ["DEN", "JFK", "ATL", "ORD", "PVG", "FRA", "CUN"],
    "capacities": {
        "aircraft": {
            "A320": {"BC": 8, "EC": 150},
            "B737": {"BC": 10, "EC": 162},
            "B787": {"BC": 28, "EC": 269},
            "B777": {"BC": 40, "EC": 350},
        },
        "crew": {
            "A320": {"CP": 1, "FO": 1, "FA": 3},
            "B737": {"CP": 1, "FO": 1, "FA": 4},
            "B787": {"CP": 1, "FO": 1, "FA": 6},
            "B777": {"CP": 1, "FO": 1, "FA": 8},
        },
    },
}
