"""Fix comparison errors by using safe_numeric for all total_val extractions"""

# Read the file
with open('tools.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace patterns
replacements = 0

# Pattern 1: total_val = val.get("total_value", 0)
old1 = 'total_val = val.get("total_value", 0)'
new1 = 'total_val = safe_numeric(val.get("total_value", 0))'
count1 = content.count(old1)
content = content.replace(old1, new1)
replacements += count1

# Pattern 2: total_val = val.get("total_value", val.get("initial_total_value", 0))
old2 = 'total_val = val.get("total_value", val.get("initial_total_value", 0))'
new2 = 'total_val = safe_numeric(val.get("total_value", val.get("initial_total_value", 0)))'
count2 = content.count(old2)
content = content.replace(old2, new2)
replacements += count2

# Write back
with open('tools.py', 'w', encoding='utf-8') as f:
    f.write(content)

print(f"Fixed {replacements} comparisons")
print(f"  Pattern 1 (total_value, 0): {count1} replacements")
print(f"  Pattern 2 (initial_total_value): {count2} replacements")
