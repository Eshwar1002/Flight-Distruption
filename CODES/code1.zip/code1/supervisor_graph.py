# supervisor_graph.py 

from langgraph.graph import StateGraph, END
from langgraph.types import interrupt
from typing import Dict, Any
import asyncio
from typing import List
import time

from logger_config import get_logger, log_agent_start, log_agent_complete, log_agent_error
from custom_agents import build_all_specialized_agents

# Initialize logger
logger = get_logger('supervisor')

# ------------------------------
# Workflow State
# ------------------------------
class WorkflowState(Dict[str, Any]):
    pnr: str
    passenger: Dict[str, Any] | None
    original_flight: Dict[str, Any] | None
    alternatives: List[Dict[str, Any]] | None
    best_alternative: Dict[str, Any] | None
    booking_summary: Dict[str, Any] | None
    cost_summary: Dict[str, Any] | None
    notification: str | None
    summary: Dict[str, Any] | None
    # Human-in-the-loop fields (interrupt-based)
    passenger_decision: str | None
    human_response: str | None  # User's input when resuming from interrupt
    disruption_type: str | None
    # Multi-passenger fields
    passenger_count: int | None
    # Supervisor routing fields
    next_agent: str | None
    routing_reason: str | None
    policy_guidance: Dict[str, Any] | None
    cost_error_count: int | None
    notify_error_count: int | None


# ------------------------------
# Build Agents
# ------------------------------
logger.info("Building specialized agents...")
print("[INFO] Building specialized agents...")
agents = build_all_specialized_agents()
logger.info("Agents built successfully")
print("[OK] Agents built successfully!")

# Note: Supervisor is now an AI-powered agent that intelligently routes tasks


# ------------------------------
# Supervisor Node Function (AI-Powered)
# ------------------------------
def run_supervisor(state: WorkflowState) -> WorkflowState:
    """AI-powered supervisor agent that intelligently analyzes state and determines next action."""
    pnr = state.get("pnr", "N/A")
    logger.info(f"Supervisor analyzing state", extra={"pnr": pnr})
    print(f"\n[SUPERVISOR] AI SUPERVISOR AGENT - Analyzing current state with LLM reasoning")
    
    # Build a comprehensive state summary for the AI supervisor
    state_summary = {
        "pnr": pnr,
        "has_passenger_info": state.get("passenger") is not None,
        "has_flight_info": state.get("original_flight") is not None,
        "has_policy_guidance": state.get("policy_guidance") is not None,
        "has_alternatives": (
            (state.get("alternatives") is not None and len(state.get("alternatives", [])) > 0) or
            state.get("best_alternative") is not None
        ),
        "passenger_decision": state.get("passenger_decision"),
        "has_booking": state.get("booking_summary") is not None,
        "has_notification": state.get("notification") is not None,
        "disruption_type": state.get("disruption_type"),
        "passenger_count": state.get("passenger_count", 1),
        "cost_error_count": state.get("cost_error_count", 0),
        "notify_error_count": state.get("notify_error_count", 0),
    }
    
    # Check for errors in passenger/flight data
    passenger_data = state.get("passenger")
    flight_data = state.get("original_flight")
    
    passenger_has_error = (
        passenger_data is not None and 
        isinstance(passenger_data, dict) and 
        ('error' in passenger_data or 'error' in str(passenger_data.get('message', '')))
    )
    
    flight_has_error = (
        flight_data is not None and 
        isinstance(flight_data, dict) and 
        ('error' in flight_data or 'error' in str(flight_data.get('message', '')))
    )
    
    state_summary["passenger_has_error"] = passenger_has_error
    state_summary["flight_has_error"] = flight_has_error
    
    # Handle critical errors (PNR not found, etc.)
    if passenger_has_error or flight_has_error:
        error_msg = ""
        if passenger_has_error:
            error_msg = passenger_data.get('message', str(passenger_data))
        if flight_has_error:
            error_msg = flight_data.get('message', str(flight_data))
        
        logger.error(
            f"Invalid PNR or data retrieval failed",
            extra={"pnr": state.get("pnr"), "error": error_msg}
        )
        print(f"[ERROR] CRITICAL ERROR: Invalid PNR or data retrieval failed")
        if passenger_has_error:
            print(f"   Passenger Error: {error_msg}")
        if flight_has_error:
            print(f"   Flight Error: {error_msg}")
        
        # Set state to indicate error and terminate workflow
        state["error"] = "Invalid PNR or data retrieval failed. Please enter a valid PNR."
        next_agent = "summary_node"
        reason = "PNR not found or invalid - terminating workflow"
        
        print(f"[ROUTE] Supervisor Decision: Route to {next_agent}")
        print(f"   Reason: {reason}")
        
        state["next_agent"] = next_agent
        state["routing_reason"] = reason
        return state
    
    # ============================================================================
    # AI-POWERED INTELLIGENT ROUTING
    # ============================================================================
    print(f"[AI SUPERVISOR] Analyzing workflow state with GPT-4...")
    print(f"   - Passenger Info: {'[OK]' if state_summary['has_passenger_info'] else '[MISSING]'}")
    print(f"   - Flight Info: {'[OK]' if state_summary['has_flight_info'] else '[MISSING]'}")
    print(f"   - Policy Guidance: {'[OK]' if state_summary['has_policy_guidance'] else '[MISSING]'}")
    print(f"   - Alternatives: {'[OK]' if state_summary['has_alternatives'] else '[MISSING]'}")
    print(f"   - Decision: {state_summary.get('passenger_decision', '[MISSING]')}")
    print(f"   - Booking: {'[OK]' if state_summary['has_booking'] else '[MISSING]'}")
    print(f"   - Notification: {'[OK]' if state_summary['has_notification'] else '[MISSING]'}")
    
    # Invoke AI supervisor with state context
    supervisor_input = {
        "state_summary": state_summary,
        "pnr": state.get("pnr", "UNKNOWN")
    }
    
    result = agents["supervisor"].invoke(supervisor_input)
    
    next_agent = result.get("next_agent")
    reason = result.get("reasoning", "AI routing decision")
    confidence = result.get("confidence", "medium")
    
    # ============================================================================
    # CRITICAL SAFEGUARD: Prevent infinite cost loops for cancellations
    # ============================================================================
    passenger_decision = state.get("passenger_decision", "").lower()
    has_cost_summary = state.get("cost_summary") is not None
    
    # If passenger chose CANCEL and cost has already been calculated, skip to notify
    if passenger_decision == "cancel" and has_cost_summary and next_agent == "cost":
        print(f"\n[SAFEGUARD] Cancellation already processed by cost agent - redirecting to notify")
        logger.warning(
            f"Preventing duplicate cost processing for cancellation",
            extra={"pnr": state.get("pnr"), "original_next": next_agent}
        )
        next_agent = "notify"
        reason = "Cancellation refund already calculated - proceeding to notification"
        confidence = "high"
    
    # If passenger chose WAIT and cost has already been calculated, skip to notify
    if passenger_decision == "wait" and has_cost_summary and next_agent == "cost":
        print(f"\n[SAFEGUARD] Wait decision already processed by cost agent - redirecting to notify")
        logger.warning(
            f"Preventing duplicate cost processing for wait",
            extra={"pnr": state.get("pnr"), "original_next": next_agent}
        )
        next_agent = "notify"
        reason = "Wait decision already processed - proceeding to notification"
        confidence = "high"
    
    logger.info(
            f"AI Supervisor routing decision",
            extra={
                "pnr": state.get("pnr"),
                "next_agent": next_agent,
                "reason": reason,
                "confidence": confidence
            }
    )
    
    print(f"\n[AI ROUTE] Next Agent: {next_agent}")
    print(f"   Reasoning: {reason}")
    print(f"   Confidence: {confidence}")
    
    return {
        **state,
        "next_agent": next_agent,
        "routing_reason": reason
    }



# ------------------------------
# Node Functions (Updated for Multi-Passenger)
# ------------------------------
def run_support(state: WorkflowState) -> WorkflowState:
    # Input validation
    if 'pnr' not in state:
        logger.error("Support agent missing required input: pnr")
        state["passenger"] = {"error": "Missing PNR"}
        state["original_flight"] = {"error": "Missing PNR"}
        return state
        
    pnr = state['pnr']
    start_time = time.time()
    
    log_agent_start(logger, "Support", pnr=pnr)
    print(f"\n[TARGET] SUPPORT AGENT - Processing PNR: {pnr}")
    print(f"[INPUT] Data received: PNR={pnr}")
    
    try:
        result = agents["support"].invoke({"pnr": pnr})
        logger.debug(f"Support agent result received", extra={"pnr": pnr})
        print(f"[DATA] Support Agent Result: {result}")
        
        # Display agent reasoning if available
        if isinstance(result, dict):
            if 'reasoning' in result:
                print(f"\n[REASONING] Support Agent Reasoning:")
                print(f"  {result['reasoning']}")
            if 'message' in result and len(str(result.get('message', ''))) > 50:
                print(f"\n[NOTES] Support Agent Notes:")
                message = str(result['message'])
                print(f"  {message[:500]}")
                if len(message) > 500:
                    print(f"  ... (truncated)")
    
        # The support agent returns a flat structure with pnr, passengers, original_flight, etc.
        # Extract and validate passenger info
        if result:
            
            # Check for errors in the result
            if result.get("error"):
                logger.error(f"Support agent returned error", extra={"pnr": pnr, "error": result["error"]})
                print(f"[ERROR] Support agent returned error: {result['error']}")
                state["passenger"] = {"error": result["error"]}
                state["original_flight"] = {"error": result["error"]}
                return state
            
            # Extract original flight info - it could be nested or flat
            original_flight = result.get("original_flight")
            
            # If original_flight is not nested, try to construct it from flat result
            if not original_flight or not isinstance(original_flight, dict):
                # Check if flight info is in flat result structure
                if result.get("flight_number"):
                    original_flight = {
                        "flight_number": result.get("flight_number"),
                        "origin": result.get("origin"),
                        "destination": result.get("destination"),
                        "departure_time": result.get("departure_time"),
                        "arrival_time": result.get("arrival_time"),
                        "aircraft_type": result.get("aircraft_type"),
                        "status": result.get("status", result.get("flight_status")),
                        "cost": result.get("cost"),
                        "distance": result.get("distance"),
                    }
                    print(f"[FIX] Reconstructed original_flight from flat result structure")
            
            # Validate that we have essential flight data
            if not original_flight or not original_flight.get("flight_number"):
                print(f"[ERROR] Missing flight information in support agent result")
                state["passenger"] = {"error": "Missing flight information"}
                state["original_flight"] = {"error": "Missing flight information"}
                return state
            
            # Extract passenger info with validation
            passenger_data = {
                "pnr": result.get("pnr"),
                "lead_passenger_name": result.get("lead_passenger_name"),
                "passenger_count": result.get("passenger_count", 1),
                "passengers": result.get("passengers", []),
                "booking_status": result.get("booking_status"),
                "flight_status": original_flight.get("status")  # Use status from flight data
            }
            
            # Ensure passenger_data has all required fields
            if not passenger_data["pnr"] or not passenger_data["lead_passenger_name"]:
                print(f"[ERROR] Missing essential passenger information")
                state["passenger"] = {"error": "Missing passenger information"}
                state["original_flight"] = {"error": "Missing passenger information"}
                return state
            
            # Update state with validated data
            state["passenger"] = passenger_data
            state["original_flight"] = original_flight
            state["passenger_count"] = passenger_data["passenger_count"]
            
            print(f"[OK] Passenger Info: PNR {passenger_data['pnr']}, Lead: {passenger_data['lead_passenger_name']}, Count: {passenger_data['passenger_count']}")
            print(f"[OK] Flight Info: {original_flight['flight_number']} ({original_flight.get('origin')} -> {original_flight.get('destination')}), Status: {original_flight.get('status')}")
            
            duration_ms = int((time.time() - start_time) * 1000)
            log_agent_complete(
                logger, "Support", pnr=pnr, duration_ms=duration_ms,
                passenger_count=passenger_data['passenger_count'],
                flight_number=original_flight['flight_number']
            )
    
    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)
        log_agent_error(logger, "Support", e, pnr=pnr, duration_ms=duration_ms)
        logger.error(f"Support agent exception", extra={"pnr": pnr}, exc_info=True)
        state["passenger"] = {"error": str(e)}
        state["original_flight"] = {"error": str(e)}
        return state
    
    # Determine disruption type from flight status
    if state.get("original_flight") and not state["original_flight"].get("error"):
        status = state["original_flight"].get("status", "").lower()
        if "cancelled" in status:
            state["disruption_type"] = "cancelled"
        elif "delayed" in status:
            state["disruption_type"] = "delayed"
        else:
            state["disruption_type"] = "unknown"
        print(f"[INFO] Disruption Type: {state['disruption_type']}")
    
    return state


def run_resource(state: WorkflowState) -> WorkflowState:
    pnr = state['pnr']
    passenger_count = state.get("passenger_count", 1)
    policy_guidance_from_state = state.get("policy_guidance", {})
    start_time = time.time()
    
    log_agent_start(logger, "Resource", pnr=pnr, passenger_count=passenger_count)
    print(f"\n[TARGET] RESOURCE AGENT - Processing PNR: {pnr}")
    print(f"[GROUP] Finding alternatives for {passenger_count} passenger(s)")
    
    # Log input data received from previous agents
    print(f"[INPUT] Data received from previous agents:")
    print(f"   - PNR: {pnr}")
    print(f"   - Passenger Count: {passenger_count}")
    print(f"   - Policy Guidance: {'Yes' if policy_guidance_from_state else 'No'} ({len(str(policy_guidance_from_state))} chars)")
    print(f"   - Original Flight: {state.get('original_flight', {}).get('flight_number', 'Unknown')}")
    print(f"   - Disruption Type: {state.get('disruption_type', 'Unknown')}")
    
    # Store policy guidance in global context for tool to use
    # (Tool will automatically retrieve it from context)
    from tools import _policy_context
    if policy_guidance_from_state:
        # Extract policy_info from the policy_guidance dict if it exists
        policy_text = policy_guidance_from_state.get('policy_guidance', '')
        if not policy_text:
            # Try to get the full dict as string
            policy_text = str(policy_guidance_from_state)
        _policy_context['latest'] = policy_text
        print(f"[CONTEXT] Stored policy guidance in context for tool use")
    
    try:
        result = agents["resource"].invoke({"pnr": pnr})
        logger.debug(f"Resource agent result received", extra={"pnr": pnr})
        print(f"[DATA] Resource Agent Result Type: {type(result)}")
        print(f"[DATA] Resource Agent Result Keys: {result.keys() if isinstance(result, dict) else 'Not a dict'}")
        
        # Display agent reasoning if available
        if isinstance(result, dict):
            if 'reasoning' in result:
                print(f"\n[REASONING] Resource Agent Reasoning:")
                print(f"  {result['reasoning']}")
            if 'thought_process' in result:
                print(f"\n[THINKING] Resource Agent Thought Process:")
                print(f"  {result['thought_process']}")
            if 'message' in result and len(str(result.get('message', ''))) > 50:
                print(f"\n[NOTES] Resource Agent Notes:")
                message = str(result['message'])
                # Display first 500 chars of reasoning/message
                print(f"  {message[:500]}")
                if len(message) > 500:
                    print(f"  ... (truncated)")
        
        # Parse agent output - ReAct agents return dict with 'output' key containing the final answer
        parsed_result = result
        if isinstance(result, dict) and 'output' in result:
            output_text = result['output']
            print(f"[PARSE] Parsing agent output text: {output_text[:200]}...")
            
            # Try to parse JSON from output
            import json
            import re
            
            # Look for JSON object in the output
            json_match = re.search(r'\{[\s\S]*\}', output_text)
            if json_match:
                try:
                    parsed_result = json.loads(json_match.group())
                    print(f"[OK] Successfully parsed JSON from agent output")
                except json.JSONDecodeError:
                    print(f"[WARN] Failed to parse JSON from agent output, using raw result")
                    parsed_result = result
            else:
                print(f"[WARN] No JSON found in agent output, using raw result")
                parsed_result = result
        
        # Extract alternatives and best_alternative from parsed result
        state["alternatives"] = parsed_result.get("alternatives", [])
        state["best_alternative"] = parsed_result.get("best_alternative")
        state["disruption_type"] = parsed_result.get("disruption_type", state.get("disruption_type"))
        state["policy_compliance"] = parsed_result.get("policy_compliance", {})
        
        alt_count = len(state["alternatives"]) if state["alternatives"] else 0
        print(f"[FLIGHT] Found {alt_count} alternative(s) with sufficient capacity")
        
        if state.get("policy_compliance"):
            filtered_count = state["policy_compliance"].get("filtered_out", 0)
            print(f"[POLICY] Policy filtering removed {filtered_count} non-compliant flight(s)")
        
        duration_ms = int((time.time() - start_time) * 1000)
        log_agent_complete(logger, "Resource", pnr=pnr, duration_ms=duration_ms, alternatives_found=alt_count)
        
    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)
        log_agent_error(logger, "Resource", e, pnr=pnr, duration_ms=duration_ms)
        print(f"[ERROR] Resource agent error: {str(e)}")
        state["alternatives"] = []
        state["best_alternative"] = None
    
    return state


def run_policy(state: WorkflowState) -> WorkflowState:
    """Query policy knowledge base for guidance (optional but helpful)"""
    pnr = state.get("pnr", "N/A")
    start_time = time.time()
    
    log_agent_start(logger, "Policy", pnr=pnr)
    print(f"\n[TARGET] POLICY AGENT - Querying flight policy knowledge base")
    
    # Log input data received from previous agents
    disruption_type = state.get("disruption_type", "unknown")
    passenger_count = state.get("passenger_count", 1)
    original_flight_number = state.get("original_flight", {}).get("flight_number", "Unknown")
    
    print(f"[INPUT] Data received from previous agents:")
    print(f"   - Disruption Type: {disruption_type}")
    print(f"   - Passenger Count: {passenger_count}")
    print(f"   - Original Flight: {original_flight_number}")
    
    # Build policy query based on disruption context
    has_alternatives = len(state.get("alternatives", [])) > 0
    
    # Construct relevant policy query
    if disruption_type == "cancelled":
        policy_query = f"What are the rebooking and compensation policies for cancelled flights with {passenger_count} passengers?"
    elif disruption_type == "delayed":
        policy_query = f"What are the policies for delayed flights with {passenger_count} passengers?"
    else:
        policy_query = f"What are the general disruption handling policies for {passenger_count} passengers?"
    
    if passenger_count > 1:
        policy_query += " What are the policies for group bookings?"
    
    try:
        result = agents["policy"].invoke({"query": policy_query})
        logger.debug(f"Policy agent result received", extra={"pnr": pnr, "query": policy_query})
        print(f"[DATA] Policy Agent Result Keys: {result.keys() if isinstance(result, dict) else 'Not a dict'}")
        
        # Display agent reasoning if available
        if isinstance(result, dict):
            if 'reasoning' in result:
                print(f"\n[REASONING] Policy Agent Reasoning:")
                print(f"  {result['reasoning']}")
            if 'policy_summary' in result:
                print(f"\n[SUMMARY] Policy Summary:")
                print(f"  {result['policy_summary']}")
            if 'message' in result and len(str(result.get('message', ''))) > 50:
                print(f"\n[NOTES] Policy Agent Notes:")
                message = str(result['message'])
                print(f"  {message[:500]}")
                if len(message) > 500:
                    print(f"  ... (truncated)")
        
        state["policy_guidance"] = result
        print(f"[OK] Retrieved policy guidance for {disruption_type} situation")
        
        duration_ms = int((time.time() - start_time) * 1000)
        log_agent_complete(logger, "Policy", pnr=pnr, duration_ms=duration_ms)
        
    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)
        log_agent_error(logger, "Policy", e, pnr=pnr, duration_ms=duration_ms)
        print(f"[WARN] Policy agent error (non-critical): {e}")
        state["policy_guidance"] = {"error": str(e), "policy_guidance": "Using default policies"}
    
    return state


def run_decision(state: WorkflowState) -> WorkflowState:
    """Handle passenger decision-making (multi-passenger aware)"""
    # Input validation
    required_fields = ["pnr", "alternatives"]
    missing = [f for f in required_fields if not state.get(f)]
    if missing:
        logger.error(f"Decision agent missing required inputs: {missing}")
        state["passenger_decision"] = "error"
        state["error"] = f"Missing required inputs: {missing}"
        return state
    
    print(f"\n[TARGET] DECISION AGENT - Processing PNR: {state['pnr']}")
    passenger_count = state.get("passenger_count", 1)
    alternatives_count = len(state.get("alternatives", []))
    
    print(f"[INPUT] Data received from previous agents:")
    print(f"   - Passenger Count: {passenger_count}")
    print(f"   - Alternatives Available: {alternatives_count}")
    print(f"   - Best Alternative: {state.get('best_alternative', {}).get('flight_number', 'None')}")
    print(f"   - Has Policy Guidance: {'Yes' if state.get('policy_guidance') else 'No'}")
    
    print(f"[GROUP] Group size: {passenger_count} passenger(s)")
    print(f"[STATE] Current state - passenger_decision: {state.get('passenger_decision')}, human_response: {state.get('human_response')}")
    
    # If we have a human response, process it FIRST (resuming from interrupt)
    if state.get("human_response"):
        print(f"[INFO] Processing human response: {state['human_response']}")
        
        # Check if this is a numeric choice (direct selection OR after EXPLORE)
        if state["human_response"].strip().isdigit():
            print("[NUMBER] Processing numeric choice - selecting specific flight")
            choice = int(state["human_response"].strip())
            alternatives = state.get("alternatives", [])
            
            if 1 <= choice <= len(alternatives):
                # Select the chosen alternative
                selected_alt = alternatives[choice - 1]
                selected_flight = selected_alt.get('flight', selected_alt) if isinstance(selected_alt, dict) else selected_alt
                
                print(f"[OK] User selected option {choice}: Flight {selected_flight.get('flight_number', 'N/A')}")
                
                # Set the selected flight as best_alternative and mark as rebook
                state["best_alternative"] = selected_flight
                state["passenger_decision"] = "rebook"
                state["human_response"] = None
                
                print(f"[OK] Flight selection complete - will rebook to {selected_flight.get('flight_number', 'N/A')}")
                return state
            else:
                print(f"[ERROR] Invalid choice {choice} - must be between 1 and {len(alternatives)}")
                # Clear response and trigger interrupt again with error message
                state["human_response"] = None
                print(f"\n[ERROR] Invalid choice. Please select a number between 1 and {len(alternatives)}, or type CANCEL.\n")
                interrupt(f"Invalid choice. Please select 1-{len(alternatives)}, or type CANCEL.")
                return state
        else:
            # Handle text responses: CANCEL, WAIT, EXPLORE, REBOOK
            response_upper = state["human_response"].strip().upper()
            
            if response_upper == "CANCEL":
                print("[CANCEL] User chose to cancel booking")
                state["passenger_decision"] = "cancel"
                state["human_response"] = None
                return state
            
            elif response_upper == "WAIT":
                disruption_type = state.get("disruption_type", "unknown")
                
                # WAIT is only valid for delayed flights
                if disruption_type == "delayed":
                    print("[WAIT] User chose to wait for updated flight status")
                    state["passenger_decision"] = "wait"
                    state["human_response"] = None
                    return state
                else:
                    # For cancelled flights, WAIT is not an option
                    print(f"[WARN] WAIT not available for {disruption_type} flights")
                    state["human_response"] = None
                    print(f"\n[ERROR] WAIT option is not available for {disruption_type} flights. Please select a flight number (1-3) or type CANCEL.\n")
                    interrupt(f"WAIT not available for {disruption_type} flights. Please select a flight (1-3) or type CANCEL.")
                    return state
            
            elif response_upper == "EXPLORE":
                print("[EXPLORE] User wants to explore all alternatives")
                # Don't set passenger_decision - user hasn't decided yet, just exploring
                
                # Show all alternatives
                alternatives = state.get("alternatives", [])
                disruption_type = state.get("disruption_type", "unknown")
                
                print(f"\n[ALL AVAILABLE ALTERNATIVES]")
                print(f"Showing all {len(alternatives)} flight options:\n")
                
                for idx, alt in enumerate(alternatives, 1):
                    flight = alt.get('flight', alt) if isinstance(alt, dict) else alt
                    score = alt.get('score', 0) if isinstance(alt, dict) else 0
                    print(
                        f"  {idx}. Flight {flight.get('flight_number', 'N/A')}: "
                        f"{flight.get('origin', 'N/A')} -> {flight.get('destination', 'N/A')} "
                        f"Departs: {flight.get('departure_time', 'N/A')} "
                        f"Arrives: {flight.get('arrival_time', 'N/A')} "
                        f"Cost: ${flight.get('cost', 0):.2f} "
                        f"(Score: {score:.1f}%)"
                    )
                
                print(f"\n[YOUR OPTIONS]")
                print(f"  - Enter the number (1-{len(alternatives)}) of your preferred flight")
                print(f"  - Type CANCEL to cancel your booking")
                
                # Show WAIT only for DELAYED flights
                if disruption_type == "delayed":
                    print(f"  - Type WAIT to wait for updated flight status")
                
                print("")
                
                state["human_response"] = None
                print(f"[OK] Showing all {len(alternatives)} alternatives - WAIT option {'enabled' if disruption_type == 'delayed' else 'disabled'}")
                interrupt(f"Please choose a flight (1-{len(alternatives)}), CANCEL" + (" or WAIT" if disruption_type == "delayed" else ""))
                return state
            
            elif response_upper == "REBOOK-GROUP":
                print("[OK] User chose GROUP option (keep everyone together)")
                if state.get("group_option"):
                    group_flight = state["group_option"].get("flight", {})
                    state["best_alternative"] = group_flight
                    state["passenger_decision"] = "rebook_group"
                    state["human_response"] = None
                    return state
                else:
                    print("[WARN] No group option available")
                    state["human_response"] = None
                    print("\n[ERROR] Group option not available. Please choose another option.\n")
                    interrupt("Group option not available. Please choose another option.")
                    return state
            
            elif response_upper == "REBOOK-SPLIT":
                print("[OK] User chose SPLIT option (higher quality flights)")
                if state.get("split_option"):
                    state["passenger_decision"] = "rebook_split"
                    state["split_booking"] = True
                    state["split_assignments"] = state["split_option"].get("split_assignments", {})
                    state["split_flights"] = state["split_option"].get("split_flights", [])
                    state["human_response"] = None
                    return state
                else:
                    print("[WARN] No split option available")
                    state["human_response"] = None
                    print("\n[ERROR] Split option not available. Please choose another option.\n")
                    interrupt("Split option not available. Please choose another option.")
                    return state
            
            elif response_upper == "REBOOK":
                print("[OK] User confirmed rebooking")
                # Use the best_alternative if already set
                if state.get("best_alternative"):
                    state["passenger_decision"] = "rebook"
                    state["human_response"] = None
                    return state
                else:
                    print("[WARN] No alternative selected yet, asking for selection")
                    state["human_response"] = None
                    print("\n[ERROR] Please select a flight number first.\n")
                    interrupt("Please select a flight number first.")
                    return state
            
            else:
                print(f"[WARN] Unknown response: {state['human_response']}")
                state["human_response"] = None
                print("\n[ERROR] Invalid input. Please enter a number (1, 2, 3...), or type CANCEL, WAIT, or EXPLORE.\n")
                interrupt("Invalid input. Please enter a number, or type CANCEL, WAIT, or EXPLORE.")
                return state
    
    # If we don't have a passenger decision yet and no human response, show options and interrupt
    if not state.get("passenger_decision"):
        print("[NEW] No decision yet - requesting passenger input")
        
        # Check if this is a dual-option scenario (both group and split available)
        if state.get("dual_option"):
            print("[TARGET] Dual-option scenario detected: Group vs Split")
            
            group_option = state.get("group_option", {})
            split_option = state.get("split_option", {})
            score_difference = state.get("score_difference", 0)
            
            original_flight = state.get("original_flight", {})
            disruption_type = state.get("disruption_type", "disrupted")
            passenger_count = state.get("passenger_count", 0)
            
            # Extract group flight info
            group_flight = group_option.get("flight", {})
            group_score = group_option.get("score", 0)
            
            # Extract split info
            split_assignments = split_option.get("split_assignments", {})
            split_flights = split_option.get("split_flights", [])
            split_avg_score = split_option.get("average_score", 0)
            children_count = split_option.get("children_count", 0)
            
            print(f"\n[ALERT] Your flight {original_flight.get('flight_number', 'N/A')} from {original_flight.get('origin', 'N/A')} to {original_flight.get('destination', 'N/A')} has been {disruption_type}.")
            print(f"\n[SPECIAL] We have found TWO rebooking options for your group of {passenger_count} passenger(s):\n")
            
            # OPTION 1: Keep group together
            print("")
            print("[GROUP] OPTION 1: KEEP GROUP TOGETHER")
            print("")
            print(f"  [FLIGHT] Flight {group_flight.get('flight_number', 'N/A')}")
            print(f"     {group_flight.get('origin', 'N/A')} -> {group_flight.get('destination', 'N/A')}")
            print(f"     Departs: {group_flight.get('departure_time', 'N/A')}")
            print(f"     Arrives: {group_flight.get('arrival_time', 'N/A')}")
            print(f"     Cost: ${group_flight.get('cost', 0):.2f}")
            print(f"     Quality Score: {group_score:.1f}%")
            print(f"\n  [OK] Benefit: All {passenger_count} passengers travel together")
            print(f"  [WARN]  Trade-off: Lower flight quality score\n")
            
            # OPTION 2: Split for better quality
            print("")
            print("[SPLIT]  OPTION 2: SPLIT FOR HIGHER QUALITY")
            print("")
            
            for flight_number, passenger_ids in split_assignments.items():
                flight_info = next((f for f in split_flights if f['flight_number'] == flight_number), {})
                pax_count = len(passenger_ids)
                flight_score = flight_info.get('score', 0)
                
                print(f"  [FLIGHT] Flight {flight_number}: {pax_count} passenger(s)")
                print(f"     {flight_info.get('origin', 'N/A')} -> {flight_info.get('destination', 'N/A')}")
                print(f"     Departs: {flight_info.get('departure_time', 'N/A')}")
                print(f"     Arrives: {flight_info.get('arrival_time', 'N/A')}")
                print(f"     Cost: ${flight_info.get('cost', 0):.2f}")
                print(f"     Quality Score: {flight_score:.1f}%\n")
            
            print(f"  Average Quality Score: {split_avg_score:.1f}%")
            print(f"  [OK] Benefit: Better overall flight quality (+{score_difference:.1f}% higher)")
            if children_count > 0:
                print(f"   Safety: All {children_count} child(ren) will be with an adult")
            print(f"  [WARN]  Trade-off: Group travels on separate flights\n")
            
            print("")
            print("\n[INPUT] Which option do you prefer?")
            print("  - Type REBOOK-GROUP to keep everyone together (Option 1)")
            print("  - Type REBOOK-SPLIT to accept split for better quality (Option 2)")
            print("  - Type CANCEL to cancel your booking")
            
            # Show WAIT only for delayed flights
            if disruption_type == "delayed":
                print("  - Type WAIT to wait for updated flight status")
            
            print("")
            
            print(f"[OK] Dual-option prompt created - WAIT option {'enabled' if disruption_type == 'delayed' else 'disabled'}")
            interrupt("Please choose: REBOOK-GROUP, REBOOK-SPLIT, CANCEL" + (" or WAIT" if disruption_type == "delayed" else ""))
            return state
        
        # Check if this is a split-only booking scenario
        elif state.get("split_booking"):
            print("[SPECIAL] Split booking scenario detected (no group option available)")
            split_assignments = state.get("split_assignments", {})
            split_flights = state.get("split_flights", [])
            children_count = state.get("children_count", 0)
            adults_count = state.get("adults_count", 0)
            
            original_flight = state.get("original_flight", {})
            disruption_type = state.get("disruption_type", "disrupted")
            
            print(f"\n[ALERT] Your flight {original_flight.get('flight_number', 'N/A')} from {original_flight.get('origin', 'N/A')} to {original_flight.get('destination', 'N/A')} has been {disruption_type}.")
            print(f"\n[WARN] No single flight has enough capacity for your entire group of {passenger_count} passenger(s).")
            print(f"\n[OK] We have found a solution that splits your group across {len(split_assignments)} flights:")
            
            if children_count > 0:
                print(f"\n Note: Your group includes {children_count} child(ren). All children will be accompanied by an adult.")
            
            print("\n[DATA] Proposed Split Booking:\n")
            
            for flight_number, passenger_ids in split_assignments.items():
                flight_info = next((f for f in split_flights if f['flight_number'] == flight_number), {})
                pax_count = len(passenger_ids)
                
                print(
                    f"  [FLIGHT] Flight {flight_number}: {pax_count} passenger(s)\n"
                    f"     {flight_info.get('origin', 'N/A')} -> {flight_info.get('destination', 'N/A')}\n"
                    f"     Departs: {flight_info.get('departure_time', 'N/A')}\n"
                    f"     Arrives: {flight_info.get('arrival_time', 'N/A')}\n"
                    f"     Cost: ${flight_info.get('cost', 0):.2f}\n"
                )
            
            print("\n[INPUT] Do you accept this split booking arrangement?")
            print("  - Type REBOOK to accept the split booking")
            print("  - Type CANCEL to cancel your booking")
            
            # Show WAIT only for delayed flights
            if disruption_type == "delayed":
                print("  - Type WAIT to wait for updated flight status")
            
            print("")
            
            print(f"[OK] Split booking prompt created - WAIT option {'enabled' if disruption_type == 'delayed' else 'disabled'}")
            interrupt("Please choose: REBOOK, CANCEL" + (" or WAIT" if disruption_type == "delayed" else ""))
            return state
        
        # Fallback: Normal alternatives display (TOP 3)
        alternatives = state.get("alternatives", [])
        best_alternative = state.get("best_alternative")
        disruption_type = state.get("disruption_type", "unknown")
        
        if alternatives or best_alternative:
            # Build human-friendly flight options
            original_flight = state.get("original_flight", {})
            
            print(f"\n[ALERT] Your flight {original_flight.get('flight_number', 'N/A')} from {original_flight.get('origin', 'N/A')} to {original_flight.get('destination', 'N/A')} has been {disruption_type}.")
            
            # ====== AI-POWERED RECOMMENDATION ENGINE ======
            # Get intelligent recommendation from AI agent
            ai_recommendation = None
            if alternatives and len(alternatives) >= 2:  # Only if multiple options
                try:
                    print(f"\n[AI] Analyzing alternatives with GPT-4o recommendation engine...")
                    
                    # Prepare input for AI recommendation agent
                    from custom_agents import build_decision_agent
                    decision_agent = build_decision_agent()
                    
                    recommendation_input = {
                        "alternatives": alternatives[:3],  # Top 3 only
                        "original_flight": original_flight,
                        "passenger_count": passenger_count,
                        "passenger": state.get("passenger", {}),
                        "policy_guidance": state.get("policy_guidance", {}),
                    }
                    
                    ai_recommendation = decision_agent.invoke(recommendation_input)
                    print(f"[OK] AI recommendation generated successfully")
                    
                except Exception as e:
                    print(f"[WARN] AI recommendation failed (non-critical): {e}")
                    ai_recommendation = None
            
            # If we have alternatives list, show TOP 3 ONLY (not all)
            if alternatives:
                total_alternatives = len(alternatives)
                # Show only top 3 alternatives initially
                top_alternatives = alternatives[:3]
                
                # ====== DISPLAY AI RECOMMENDATION (IF AVAILABLE) ======
                if ai_recommendation:
                    recommended_option = ai_recommendation.get("recommended_option", 1)
                    reasoning = ai_recommendation.get("recommendation_reasoning", "")
                    confidence = ai_recommendation.get("confidence", "medium")
                    
                    print(f"\n{'='*80}")
                    print(f"[AI RECOMMENDATION] 🤖 GPT-4o Analysis")
                    print(f"{'='*80}")
                    print(f"\n✨ RECOMMENDED: Option {recommended_option}")
                    print(f"\n💡 WHY THIS CHOICE:")
                    print(f"   {reasoning}")
                    print(f"\n🎯 Confidence: {confidence.upper()}")
                    
                    # Show pros/cons for each option
                    for i in range(1, min(4, len(alternatives) + 1)):
                        pros_key = f"option_{i}_pros"
                        cons_key = f"option_{i}_cons"
                        
                        pros = ai_recommendation.get(pros_key, "")
                        cons = ai_recommendation.get(cons_key, "")
                        
                        if pros or cons:
                            print(f"\n   Option {i}:")
                            if pros:
                                print(f"      ✓ Pros: {pros}")
                            if cons:
                                print(f"      ✗ Cons: {cons}")
                    
                    # Show key considerations
                    key_considerations = ai_recommendation.get("key_considerations", "")
                    if key_considerations:
                        print(f"\n💭 KEY CONSIDERATIONS:")
                        print(f"   {key_considerations}")
                    
                    print(f"\n{'='*80}\n")
                
                print(f"\n[ALL OPTIONS] We've found {total_alternatives} alternative flight(s). Here are the top 3:\n")
                
                for idx, alt in enumerate(top_alternatives, 1):
                    flight = alt.get('flight', alt) if isinstance(alt, dict) else alt
                    score = alt.get('score', 0) if isinstance(alt, dict) else 0
                    print(
                        f"  {idx}. Flight {flight.get('flight_number', 'N/A')}: "
                        f"{flight.get('origin', 'N/A')} -> {flight.get('destination', 'N/A')} "
                        f"Departs: {flight.get('departure_time', 'N/A')} "
                        f"Cost: ${flight.get('cost', 0):.2f} "
                        f"(Score: {score:.1f}%)"
                    )
            # If we only have best_alternative, show it
            elif best_alternative:
                print(f"\nWe've found an alternative flight for you:\n")
                print(
                    f"  1. Flight {best_alternative.get('flight_number', 'N/A')}: "
                    f"{best_alternative.get('origin', 'N/A')} -> {best_alternative.get('destination', 'N/A')} "
                    f"Departs: {best_alternative.get('departure_time', 'N/A')} "
                    f"Cost: ${best_alternative.get('cost', 0):.2f}"
                )
            
            print("\n[YOUR OPTIONS]")
            
            # Show numbered options based on what we displayed
            if alternatives and len(alternatives) > 1:
                top_count = min(3, len(alternatives))
                print(f"  - Enter a number (1-{top_count}) to select that flight")
                if len(alternatives) > 3:
                    print(f"  - Type EXPLORE to see all {len(alternatives)} available flights")
            elif alternatives and len(alternatives) == 1:
                print("  - Type 1 to accept this flight")
            elif best_alternative:
                print("  - Type 1 to accept this flight")
            
            # Always show CANCEL
            print("  - Type CANCEL to cancel your booking")
            
            # Show WAIT only for DELAYED flights (not cancelled)
            if disruption_type == "delayed":
                print("  - Type WAIT to wait for updated flight status")
            
            print("")
            
            print(f"[OK] Requesting human input - showing top 3 of {len(alternatives) if alternatives else 1} options")
            print(f"[CONTEXT] Disruption type: {disruption_type} - WAIT option {'enabled' if disruption_type == 'delayed' else 'disabled'}")
            
            # Interrupt with prompt
            options = []
            if alternatives:
                top_count = min(3, len(alternatives))
                options.append(f"1-{top_count}")
                if len(alternatives) > 3:
                    options.append("EXPLORE")
            options.extend(["CANCEL"])
            if disruption_type == "delayed":
                options.append("WAIT")
            
            interrupt(f"Please choose: {', '.join(options)}")
            return state
        
        # No alternatives at all - shouldn't happen with proper supervisor routing
        print("[ERROR] No alternatives or best_alternative available")
        interrupt("No alternatives found. Type CANCEL to cancel or WAIT to wait for another solution.")
        return state
    
    print(f"[OK] Decision processing complete - passenger_decision: {state.get('passenger_decision')}")
    return state


def run_cost(state: WorkflowState) -> WorkflowState:
    """Calculate cost and apply booking based on passenger action"""
    # Input validation
    required_fields = ["pnr", "passenger_decision"]
    missing = [f for f in required_fields if not state.get(f)]
    if missing:
        logger.error(f"Cost agent missing required inputs: {missing}")
        state["cost_summary"] = {"error": f"Missing required inputs: {missing}"}
        return state
    
    passenger_decision = state.get("passenger_decision", "")
    passenger_count = state.get("passenger_count", 1)
    
    print(f"\n[TARGET] COST AGENT - Processing {passenger_decision} action for {passenger_count} passenger(s) (PNR: {state['pnr']})")
    print(f"[INPUT] Data received from previous agents:")
    print(f"   - Passenger Decision: {passenger_decision}")
    print(f"   - Original Flight: {state.get('original_flight', {}).get('flight_number', 'Unknown')}")
    if passenger_decision == "rebook":
        print(f"   - Best Alternative: {state.get('best_alternative', {}).get('flight_number', 'Unknown')}")
    print(f"   - Disruption Type: {state.get('disruption_type', 'Unknown')}")
    
    # Determine action type and prepare input data
    disruption_info = state.get("policy_guidance", {})
    disruption_type = disruption_info.get("disruption_type", "cancelled") if isinstance(disruption_info, dict) else "cancelled"
    
    # CANCEL ACTION
    if passenger_decision == "cancel":
        print("[ACTION] Processing CANCEL - calculating refund and compensation")
        
        input_data = {
            "pnr": state["pnr"],
            "original_flight": state.get("original_flight"),
            "disruption_type": disruption_type,
            "passenger_decision": "cancel"
        }
        
        result = agents["cost"].invoke(input_data)
        print(f"[DATA] Cancellation Cost Result: {result}")
        
        # Display agent reasoning if available
        if isinstance(result, dict):
            if 'reasoning' in result:
                print(f"\n[REASONING] Cost Agent Reasoning (Cancel):")
                print(f"  {result['reasoning']}")
            if 'message' in result and len(str(result.get('message', ''))) > 50:
                print(f"\n[NOTES] Cost Agent Notes:")
                message = str(result['message'])
                print(f"  {message[:500]}")
                if len(message) > 500:
                    print(f"  ... (truncated)")
        
        if result.get("error"):
            print(f"[WARN] Cost agent error: {result.get('error')}")
            state["cost_error_count"] = state.get("cost_error_count", 0) + 1
            state["cost_summary"] = {"error": result.get("error")}
        else:
            # Extract cancellation cost details
            state["cost_summary"] = result.get("cancellation_cost") or result
            print(f"[COST] Refund: ${state['cost_summary'].get('refund_amount', 0):.2f}, Compensation: ${state['cost_summary'].get('compensation_amount', 0):.2f}")
        
        return state
    
    # WAIT ACTION
    elif passenger_decision == "wait":
        print("[ACTION] Processing WAIT - calculating entitlements and care obligations")
        
        input_data = {
            "pnr": state["pnr"],
            "original_flight": state.get("original_flight"),
            "disruption_type": disruption_type,
            "passenger_decision": "wait"
        }
        
        result = agents["cost"].invoke(input_data)
        print(f"[DATA] Wait Cost Result: {result}")
        
        if result.get("error"):
            print(f"[WARN] Cost agent error: {result.get('error')}")
            state["cost_error_count"] = state.get("cost_error_count", 0) + 1
            state["cost_summary"] = {"error": result.get("error")}
        else:
            # Extract wait cost details
            state["cost_summary"] = result.get("wait_cost") or result
            print(f"[COST] Entitlements: ${state['cost_summary'].get('total_entitlement_value', 0):.2f} (No cost to passenger)")
        
        return state
    
    # REBOOK ACTION (existing logic continues)
    # Check if we should calculate rebook cost
    should_calculate_rebook = (
        passenger_decision in ["rebook", "rebooked", "rebook_group", "rebook_split"] or 
        (passenger_decision == "rebook" and state.get("split_booking"))
    )
    
    if not should_calculate_rebook:
        print(f" Skipping cost calculation - passenger decision: {passenger_decision}")
        return state
    
    # Handle split booking (either from dual-option choice or split-only scenario)
    if (passenger_decision == "rebook_split" or state.get("split_booking")) and state.get("split_assignments"):
        print("[SPECIAL] Processing split booking")
        
        # Call booking_apply with split_assignments
        from tools import booking_apply
        
        booking_result = booking_apply(
            pnr=state["pnr"],
            split_assignments=state["split_assignments"]
        )
        
        print(f"[DATA] Split Booking Result: {booking_result}")
        
        if booking_result.get("error"):
            print(f"[CANCEL] Split booking failed: {booking_result['error']}")
            state["booking_summary"] = {"error": booking_result["error"]}
            state["cost_summary"] = {"error": "Booking failed"}
        else:
            state["booking_summary"] = booking_result
            state["split_booking_result"] = booking_result
            
            # Calculate total cost across all flights
            total_cost = 0
            for flight_info in state.get("split_flights", []):
                total_cost += flight_info.get("cost", 0) * len(state["split_assignments"].get(flight_info["flight_number"], []))
            
            original_cost = state.get("original_flight", {}).get("cost", 0) * passenger_count
            
            state["cost_summary"] = {
                "original_cost": original_cost,
                "new_cost": total_cost,
                "difference": total_cost - original_cost,
                "split_booking": True
            }
            
            print(f"[COST] Split Booking Cost: ${total_cost:.2f} (Original: ${original_cost:.2f})")
        
        return state
    
    # Original single-flight rebook logic
    if not state.get("original_flight") or not state.get("best_alternative"):
        print("[CANCEL] Skipping cost calculation - missing required data")
        print(f"   Original flight: {state.get('original_flight') is not None}")
        print(f"   Best alternative: {state.get('best_alternative') is not None}")
        return state
    
    print("[ACTION] Processing REBOOK - calculating fare differences and applying booking")
    
    input_data = {
        "pnr": state["pnr"],
        "original_flight": state.get("original_flight"),
        "new_flight": state.get("best_alternative"),
        "disruption_type": disruption_type,
        "passenger_decision": "rebook"
    }
    
    result = agents["cost"].invoke(input_data)
    print(f"[DATA] Rebook Cost Result: {result}")
    
    # Check if there was an error
    if result.get("error") or result.get("message"):
        error_msg = result.get("error") or result.get("message")
        print(f"[WARN] Cost agent encountered an error: {error_msg}")
        # Increment error counter
        state["cost_error_count"] = state.get("cost_error_count", 0) + 1
        state["booking_summary"] = {"error": error_msg}
        state["cost_summary"] = {"error": error_msg}
    else:
        # The result itself IS the cost breakdown from the agent
        # Check if result has action field (indicating it's the cost result directly)
        if "action" in result:
            # Cost result - use it as cost summary
            state["cost_summary"] = result
            
            # Build booking_summary from state data
            # The booking_apply tool was called but its result is not in the final answer
            # We can reconstruct booking info from the rebook cost result and state
            original_flight = state.get("original_flight", {})
            new_flight = state.get("best_alternative", {})
            
            # Get passenger details to show seat assignments
            passenger_data = state.get("passenger", {})
            passengers = passenger_data.get("passengers", [])
            
            state["booking_summary"] = {
                "pnr": result.get("pnr"),
                "old_flight": result.get("original_flight") or original_flight.get("flight_number"),
                "new_flight": result.get("alternative_flight") or new_flight.get("flight_number"),
                "passenger_count": result.get("passenger_count"),
                "seat_assignments": [
                    {
                        "name": p.get("name"),
                        "seat": p.get("seat"),
                        "class_of_service": p.get("class_of_service")
                    }
                    for p in passengers
                ],
                "status": "Booking completed successfully"
            }
        else:
            # Legacy format - extract nested fields
            state["booking_summary"] = result.get("booking_summary") or result.get("booking_result")
            state["cost_summary"] = (result.get("cost_summary") or 
                                    result.get("cost_calculation_result") or 
                                    result.get("disruption_cost"))
    
    # Log cost summary for debugging
    if state.get("cost_summary"):
        print(f"[COST] Cost Summary Set: {state['cost_summary']}")
    else:
        print(f"[WARN] Warning: cost_summary is None or empty")
    
    return state


def run_notify(state: WorkflowState) -> WorkflowState:
    """Final notification (multi-passenger aware with context-specific notifications)"""
    # Input validation
    required_fields = ["pnr", "passenger_decision", "cost_summary"]
    missing = [f for f in required_fields if not state.get(f)]
    if missing:
        logger.error(f"Notify agent missing required inputs: {missing}")
        state["notification"] = {"error": f"Missing required inputs: {missing}"}
        return state
    
    passenger_count = state.get("passenger_count", 1)
    passenger_decision = state.get("passenger_decision", "selected")
    disruption_type = state.get("disruption_type", "unknown")
    
    print(f"\n[TARGET] NOTIFY AGENT - Final notification for {passenger_count} passenger(s) (PNR: {state['pnr']})")
    print(f"[INPUT] Data received from previous agents:")
    print(f"   - Passenger Decision: {passenger_decision}")
    print(f"   - Cost Summary Available: {'Yes' if state.get('cost_summary') else 'No'}")
    if passenger_decision == "rebook":
        print(f"   - Booking Summary Available: {'Yes' if state.get('booking_summary') else 'No'}")
    print(f"   - Disruption Type: {disruption_type}")
    
    print(f"[CONTEXT] Action: {passenger_decision}, Disruption: {disruption_type}")
    
    # Map passenger_decision to action for notify_passenger function
    # This is critical for both cancelled and delayed cases
    if passenger_decision in ["rebook", "rebooked", "rebook_group", "rebook_split"]:
        action = "selected"
    elif passenger_decision == "cancel":
        action = "cancel"
    elif passenger_decision == "wait":
        action = "wait"
    else:
        action = "selected"  # Default to selected for any other case
    
    print(f"[MAP] Mapped passenger_decision '{passenger_decision}' to action '{action}'")
    
    # Handle split booking notification
    if state.get("split_booking_result"):
        print("[SPECIAL] Generating split booking notification")
        from tools import notify_passenger
        
        notification = notify_passenger(
            pnr=state["pnr"],
            split_booking_result=state["split_booking_result"],
            action=action,
            disruption_type=disruption_type
        )
        
        print(f"[DATA] Split Booking Notification: {notification}")
        
        return {
            **state,
            "notification": notification
        }
    
    # Prepare input for notification agent with full context
    # Pass the MAPPED action, not the original passenger_decision
    notify_input = {
        "pnr": state["pnr"],
        "new_flight": state.get("best_alternative"),
        "action": action,  # Use mapped action instead of passenger_decision
        "passenger_decision": passenger_decision,  # Keep original for reference
        "disruption_type": disruption_type,
        "split_booking_result": state.get("split_booking_result"),
        "cost_summary": state.get("cost_summary")  # Include cost information
    }
    
    print(f"[DATA] Notify Agent Input: pnr={state['pnr']}, action={action}, disruption={disruption_type}, has_cost={state.get('cost_summary') is not None}")
    
    # Call notification agent with context
    result = agents["notify"].invoke(notify_input)
    
    print(f"[DATA] Notify Agent Result: {result}")
    
    # Display agent reasoning if available
    if isinstance(result, dict):
        if 'reasoning' in result:
            print(f"\n[REASONING] Notify Agent Reasoning:")
            print(f"  {result['reasoning']}")
        if 'message' in result and len(str(result.get('message', ''))) > 50 and 'notification' not in result:
            print(f"\n[NOTES] Notify Agent Notes:")
            message = str(result['message'])
            print(f"  {message[:500]}")
            if len(message) > 500:
                print(f"  ... (truncated)")
    
    # Check if there was an error
    if result.get("error"):
        print(f"[WARN] Notify agent encountered an error: {result['error']}")
        # Increment error counter and return new state (immutability)
        new_count = state.get("notify_error_count", 0) + 1
        print(f"[NUMBER] Notify error count: {new_count}")
        return {
            **state,
            "notify_error_count": new_count,
            "notification": result  # Store the error dict
        }
    else:
        # Extract notification message - could be "message" or "notification_message"
        notification_msg = result.get("notification_message") or result.get("message") or result
        return {
            **state,
            "notification": notification_msg
        }


def supervisor_route(state: WorkflowState) -> str:
    """Conditional edge: route based on supervisor's decision"""
    next_agent = state.get("next_agent", "support")
    print(f"[ROUTE] Supervisor routing to: {next_agent}")
    logger.debug(
        f"Supervisor routing",
        extra={
            "next_agent": next_agent,
            "state_keys": list(state.keys()),
            "pnr": state.get("pnr", "N/A")
        }
    )
    
    # Return the next agent directly (must match conditional_edges keys)
    valid_routes = ["support", "policy", "resource", "decision", "cost", "notify", "summary_node"]
    if next_agent in valid_routes:
        return next_agent
    else:
        logger.warning(
            f"Invalid next_agent, defaulting to summary_node",
            extra={"invalid_agent": next_agent, "pnr": state.get("pnr", "N/A")}
        )
        print(f"   WARNING: Invalid next_agent '{next_agent}', defaulting to summary_node")
        return "summary_node"


def run_summary(state: WorkflowState) -> WorkflowState:
    """Final summarizer node (multi-passenger aware)"""
    print(f"\n[STATE] CREATING FINAL SUMMARY")
    print(f"[INPUT] Summary aggregating data from all agents:")
    print(f"   - Passenger Info: {'Yes' if state.get('passenger') else 'No'}")
    print(f"   - Original Flight: {state.get('original_flight', {}).get('flight_number', 'Unknown')}")
    print(f"   - Policy Guidance: {'Yes' if state.get('policy_guidance') else 'No'}")
    print(f"   - Alternatives Found: {len(state.get('alternatives', []))}")
    print(f"   - Passenger Decision: {state.get('passenger_decision', 'None')}")
    print(f"   - Cost Summary: {'Yes' if state.get('cost_summary') else 'No'}")
    print(f"   - Notification: {'Yes' if state.get('notification') else 'No'}")
    
    # Check if there's an error state (e.g., invalid PNR)
    if state.get("error"):
        error_msg = state["error"]
        print(f"[CANCEL] Error encountered: {error_msg}")
        
        summary = {
            "pnr": state.get("pnr", "N/A"),
            "error": error_msg,
            "status": "failed",
            "message": f"[CANCEL] {error_msg}"
        }
        
        state["summary"] = summary
        
        # Display error to user
        print("\n" + "=" * 70)
        print("[CANCEL] WORKFLOW FAILED")
        print("=" * 70)
        print(f"\nPNR: {state.get('pnr', 'N/A')}")
        print(f"Error: {error_msg}")
        print("\nPlease check the PNR and try again.")
        print("=" * 70)
        
        return state
    
    passenger_info = state.get("passenger") or {}
    passenger_count = passenger_info.get("passenger_count", 1) if passenger_info else 1
    pax_label = "passenger" if passenger_count == 1 else "passengers"
    
    # Check if passenger cancelled or chose to wait
    passenger_decision = state.get("passenger_decision", "N/A")
    
    if passenger_decision == "cancel":
        print("[CANCEL] Passenger chose to CANCEL booking")
        
        # Update database status
        from support_functions import update_pnr_status
        pnr = state.get("pnr", "N/A")
        update_pnr_status(pnr, "Cancelled")
        
        summary = {
            "pnr": pnr,
            "lead_passenger": passenger_info.get("lead_passenger_name", "Unknown") if passenger_info else "Unknown",
            "passenger_count": passenger_count,
            "passenger_label": pax_label,
            "original_flight": (state.get("original_flight") or {}).get("flight_number", "N/A"),
            "passenger_decision": "cancel",
            "status": "cancelled",
            "message": "Booking cancelled by passenger request"
        }
        
        state["summary"] = summary
        
        # Database update already done above
        # Return state without printing (main.py will print)
        
        return state
    
    elif passenger_decision == "wait":
        print("[WAIT] Passenger chose to WAIT for another solution")
        
        # Update database status
        from support_functions import update_pnr_status
        pnr = state.get("pnr", "N/A")
        update_pnr_status(pnr, "Waiting")
        
        summary = {
            "pnr": pnr,
            "lead_passenger": passenger_info.get("lead_passenger_name", "Unknown") if passenger_info else "Unknown",
            "passenger_count": passenger_count,
            "passenger_label": pax_label,
            "original_flight": (state.get("original_flight") or {}).get("flight_number", "N/A"),
            "passenger_decision": "wait",
            "status": "waiting",
            "message": "Passenger chose to wait for alternative solution"
        }
        
        state["summary"] = summary
        
        # Database update already done above
        # Return state without printing (main.py will print)
        
        return state
    
    # Get cost summary - ensure it's properly formatted
    cost_summary = state.get("cost_summary", "N/A")
    if isinstance(cost_summary, dict):
        # Add formatting if needed
        if "total_disruption_cost" not in cost_summary and "difference" in cost_summary:
            cost_summary["total_disruption_cost"] = abs(float(cost_summary.get("difference", 0))) + float(cost_summary.get("disruption_penalty", 0))
    
    summary = {
        "pnr": state.get("pnr", "N/A"),
        "lead_passenger": passenger_info.get("lead_passenger_name", "Unknown") if passenger_info else "Unknown",
        "passenger_count": passenger_count,
        "passenger_label": pax_label,
        "original_flight": (state.get("original_flight") or {}).get("flight_number", "N/A"),
        "rebooked_flight": (state.get("best_alternative") or {}).get("flight_number", "N/A"),
        "disruption_cost": cost_summary,
        "notification": state.get("notification", "N/A"),
        "passenger_decision": state.get("passenger_decision", "N/A"),
        "booking_summary": state.get("booking_summary", "N/A"),
    }

    state["summary"] = summary
    return state


# ------------------------------
# Build Supervisor-Driven Workflow (PRIMARY WORKFLOW)
# ------------------------------
print("[INFO] Building supervisor-driven dynamic routing graph...")
workflow = StateGraph(WorkflowState)

# Add supervisor node
workflow.add_node("supervisor", run_supervisor)

# Add all agent nodes
workflow.add_node("support", run_support)
workflow.add_node("resource", run_resource)
workflow.add_node("policy", run_policy)
workflow.add_node("decision", run_decision)  # Decision node now uses interrupts, no human_input node needed
workflow.add_node("cost", run_cost)
workflow.add_node("notify", run_notify)
workflow.add_node("summary_node", run_summary)

# Set entry point to supervisor
workflow.set_entry_point("supervisor")

# Supervisor routes to appropriate agent based on state analysis
workflow.add_conditional_edges(
    "supervisor",
    supervisor_route,
    {
        "support": "support",
        "policy": "policy",
        "resource": "resource",
        "decision": "decision",
        "cost": "cost",
        "notify": "notify",
        "summary_node": "summary_node"
    }
)

# After each agent completes, return to supervisor for next routing decision
workflow.add_edge("support", "supervisor")
workflow.add_edge("policy", "supervisor")
workflow.add_edge("resource", "supervisor")

# Decision agent now uses interrupts - returns to supervisor after decision made
workflow.add_edge("decision", "supervisor")

# After cost, notify, return to supervisor
workflow.add_edge("cost", "supervisor")
workflow.add_edge("notify", "supervisor")

# Summary is terminal
workflow.add_edge("summary_node", END)

# Compile the supervisor-driven workflow with MemorySaver for interrupt support
from langgraph.checkpoint.memory import MemorySaver

memory = MemorySaver()
supervisor = workflow.compile(
    checkpointer=memory,  # Enable checkpointing for interrupts
    debug=False  # Set to True for detailed debugging
)
print("[OK] Supervisor-driven workflow built successfully!")
print("[OK] Interrupt support enabled with MemorySaver checkpointer")
print("[CONFIG] Recursion limit: Default (25 steps)")
print("[INFO] To increase recursion limit, pass config={'recursion_limit': 50} to stream/invoke")