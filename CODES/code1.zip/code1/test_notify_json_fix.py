"""
Quick test to verify the notify agent JSON formatting fix
Tests with PNR DY7QTY which we know has proper cost calculations
"""

import os
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Set environment
os.environ["OPENAI_API_KEY"] = "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"

from config import initialize_logger
from db_setup import DatabasePool
from custom_agents import build_notify_agent
from state import State
from langchain_core.messages import HumanMessage

# Initialize
initialize_logger()
print("[TEST] Initializing database pool...")
DatabasePool.get_instance()
print("[TEST] Database pool initialized\n")

# Build notify agent
print("[TEST] Building Notify Agent with updated instructions...")
notify_agent = build_notify_agent()
print("[TEST] Notify Agent built successfully\n")

# Create test state with PNR DY7QTY data (from previous successful test)
test_state = State(
    pnr="DY7QTY",
    passenger_info={
        "pnr": "DY7QTY",
        "lead_passenger": "Robert Wilson",
        "passengers": [
            {"name": "Robert Wilson", "passenger_id": 1},
            {"name": "Linda Wilson", "passenger_id": 2}
        ],
        "passenger_count": 2
    },
    flight_info={
        "flight_number": "SA101",
        "route": "JFK-LAX",
        "scheduled_departure": "2025-10-30 08:00:00",
        "status": "Cancelled"
    },
    alternatives_found=[
        {
            "flight_number": "SA513",
            "route": "JFK-LAX",
            "departure_time": "2025-10-31 13:29:00",
            "arrival_time": "2025-10-31 19:29:00"
        }
    ],
    passenger_decision="selected",
    booking_result={
        "success": True,
        "message": "Booking confirmed",
        "seats": ["26E", "23F"]
    },
    cost_summary={
        "fare_difference": {
            "original_fare": 450.00,
            "new_fare": 480.69,
            "difference": 30.69,
            "total_difference": 61.38,
            "passengers": 2
        },
        "care_obligations": {
            "meal_vouchers": {"total_value": 50.00},
            "refreshments": {"total_value": 30.00},
            "lounge_access": {"total_value": 100.00},
            "total_care_value": 180.00
        },
        "vouchers_and_benefits": {
            "retail_vouchers": {"total_value": 40.00},
            "upgrade_voucher": {"total_value": 200.00},
            "mileage_bonus": {"total_value": 100.00},
            "goodwill_voucher": {"total_value": 200.00},
            "total_vouchers_value": 540.00
        },
        "total_benefits_provided": 720.00
    },
    messages=[
        HumanMessage(content="Process notification for PNR DY7QTY with selected flight SA513")
    ]
)

print("="*80)
print("TEST: Invoking Notify Agent with JSON formatting fix")
print("="*80)
print(f"PNR: {test_state['pnr']}")
print(f"Action: {test_state['passenger_decision']}")
print(f"Total Benefits: ${test_state['cost_summary']['total_benefits_provided']}")
print(f"Care Obligations: ${test_state['cost_summary']['care_obligations']['total_care_value']}")
print(f"Vouchers: ${test_state['cost_summary']['vouchers_and_benefits']['total_vouchers_value']}")
print("="*80 + "\n")

try:
    print("[AGENT] Invoking notify agent...")
    result = notify_agent.invoke(test_state)
    
    print("\n" + "="*80)
    print("AGENT INVOCATION RESULT")
    print("="*80)
    
    if "error" in result:
        print(f"[ERROR] {result['error']}")
    else:
        print("[SUCCESS] Notify agent completed")
        
        # Check if airline notification was generated
        if result.get("notification_sent"):
            print("\n✅ Airline notification: SENT")
        
        # Check if customer notification was generated  
        if result.get("notification_customer"):
            print("✅ Customer notification: SENT")
        
        # Display final message
        if result.get("messages"):
            last_message = result["messages"][-1]
            print(f"\nFinal Agent Message:\n{last_message.content[:500]}...")
    
    print("\n" + "="*80)
    print("TEST COMPLETED")
    print("="*80)
    
except Exception as e:
    print(f"\n[ERROR] Exception during test: {str(e)}")
    import traceback
    traceback.print_exc()

finally:
    # Cleanup
    print("\n[TEST] Closing database connections...")
    DatabasePool.get_instance().close_all()
    print("[TEST] Test cleanup complete")
