"""
Retry Utilities with Exponential Backoff
Provides decorators and helper functions for robust error handling with automatic retries.
"""

import time
import functools
import logging
from typing import Callable, Type, Tuple, Optional, Any
from openai import RateLimitError, APIError, APITimeoutError, APIConnectionError

logger = logging.getLogger(__name__)


class RetryConfig:
    """Configuration for retry behavior"""
    
    # Default configuration
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_INITIAL_DELAY = 1.0  # seconds
    DEFAULT_MAX_DELAY = 60.0  # seconds
    DEFAULT_EXPONENTIAL_BASE = 2.0
    DEFAULT_JITTER = True
    
    # Retryable exceptions for different scenarios
    RETRYABLE_API_ERRORS = (
        RateLimitError,
        APITimeoutError,
        APIConnectionError,
        APIError,
    )
    
    RETRYABLE_DB_ERRORS = (
        Exception,  # Will be more specific based on actual DB errors
    )


def exponential_backoff(
    attempt: int,
    initial_delay: float = RetryConfig.DEFAULT_INITIAL_DELAY,
    exponential_base: float = RetryConfig.DEFAULT_EXPONENTIAL_BASE,
    max_delay: float = RetryConfig.DEFAULT_MAX_DELAY,
    jitter: bool = RetryConfig.DEFAULT_JITTER,
) -> float:
    """
    Calculate exponential backoff delay.
    
    Args:
        attempt: Current attempt number (0-indexed)
        initial_delay: Initial delay in seconds
        exponential_base: Base for exponential calculation
        max_delay: Maximum delay in seconds
        jitter: Whether to add random jitter
        
    Returns:
        Delay in seconds
    """
    import random
    
    # Calculate exponential delay
    delay = min(initial_delay * (exponential_base ** attempt), max_delay)
    
    # Add jitter to prevent thundering herd
    if jitter:
        delay = delay * (0.5 + random.random() * 0.5)  # 50-100% of calculated delay
    
    return delay


def retry_with_backoff(
    max_retries: int = RetryConfig.DEFAULT_MAX_RETRIES,
    initial_delay: float = RetryConfig.DEFAULT_INITIAL_DELAY,
    max_delay: float = RetryConfig.DEFAULT_MAX_DELAY,
    exponential_base: float = RetryConfig.DEFAULT_EXPONENTIAL_BASE,
    retryable_exceptions: Tuple[Type[Exception], ...] = RetryConfig.RETRYABLE_API_ERRORS,
    on_retry: Optional[Callable[[Exception, int, float], None]] = None,
    on_failure: Optional[Callable[[Exception, int], None]] = None,
):
    """
    Decorator for retrying functions with exponential backoff.
    
    Args:
        max_retries: Maximum number of retry attempts
        initial_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
        exponential_base: Base for exponential calculation
        retryable_exceptions: Tuple of exceptions that should trigger retry
        on_retry: Callback function called on each retry (exception, attempt, delay)
        on_failure: Callback function called on final failure (exception, attempts)
        
    Usage:
        @retry_with_backoff(max_retries=3)
        def api_call():
            return client.chat.completions.create(...)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                    
                except retryable_exceptions as e:
                    last_exception = e
                    
                    # If this was the last attempt, raise the exception
                    if attempt >= max_retries:
                        if on_failure:
                            on_failure(e, attempt + 1)
                        logger.error(
                            f"Function {func.__name__} failed after {attempt + 1} attempts: {e}"
                        )
                        raise
                    
                    # Calculate backoff delay
                    delay = exponential_backoff(
                        attempt,
                        initial_delay=initial_delay,
                        exponential_base=exponential_base,
                        max_delay=max_delay,
                        jitter=True,
                    )
                    
                    # Log retry attempt
                    logger.warning(
                        f"Function {func.__name__} failed (attempt {attempt + 1}/{max_retries + 1}): {e}. "
                        f"Retrying in {delay:.2f}s..."
                    )
                    
                    # Call retry callback if provided
                    if on_retry:
                        on_retry(e, attempt + 1, delay)
                    
                    # Wait before retrying
                    time.sleep(delay)
                    
                except Exception as e:
                    # Non-retryable exception, raise immediately
                    logger.error(f"Function {func.__name__} failed with non-retryable error: {e}")
                    raise
            
            # Should never reach here, but just in case
            if last_exception:
                raise last_exception
                
        return wrapper
    return decorator


def retry_database_operation(
    max_retries: int = 3,
    initial_delay: float = 0.5,
    max_delay: float = 10.0,
):
    """
    Specialized retry decorator for database operations.
    
    Args:
        max_retries: Maximum number of retry attempts
        initial_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
    """
    return retry_with_backoff(
        max_retries=max_retries,
        initial_delay=initial_delay,
        max_delay=max_delay,
        exponential_base=2.0,
        retryable_exceptions=(Exception,),  # Catch all DB errors
    )


def execute_with_retry(
    retry_operation: 'RetryableOperation',
    logger_instance: Optional[logging.Logger] = None,
    extra_context: Optional[dict] = None
):
    """
    Execute a RetryableOperation with exponential backoff.
    
    This is a convenience function that executes an operation wrapped in
    RetryableOperation with proper retry logic and logging.
    
    Args:
        retry_operation: RetryableOperation instance containing the operation to execute
        logger_instance: Logger instance for logging (uses module logger if not provided)
        extra_context: Additional context to include in log messages
        
    Returns:
        Result of the operation
        
    Raises:
        Exception: The last exception if all retries fail
        
    Usage:
        retry_op = RetryableOperation(
            operation=my_function,
            operation_name="my_operation",
            max_retries=3
        )
        result = execute_with_retry(retry_op, logger)
    """
    log = logger_instance or logger
    op = retry_operation
    last_exception = None
    
    for attempt in range(op.max_retries + 1):
        try:
            # Execute the operation
            if op.operation is None:
                raise ValueError("RetryableOperation must have an operation callable")
            
            result = op.operation()
            
            # Success
            log.info(
                f"Operation '{op.operation_name}' succeeded on attempt {attempt + 1}",
                extra=extra_context or {}
            )
            return result
            
        except Exception as e:
            last_exception = e
            op.last_exception = e
            op.attempt = attempt + 1
            
            # If this was the last attempt, raise the exception
            if attempt >= op.max_retries:
                log.error(
                    f"Operation '{op.operation_name}' failed after {attempt + 1} attempts: {e}",
                    extra=extra_context or {},
                    exc_info=True
                )
                raise
            
            # Calculate backoff delay
            delay = exponential_backoff(
                attempt,
                initial_delay=op.initial_delay,
                exponential_base=op.exponential_base,
                max_delay=op.max_delay,
                jitter=True,
            )
            
            # Log retry attempt
            log.warning(
                f"Operation '{op.operation_name}' failed (attempt {attempt + 1}/{op.max_retries + 1}): {e}. "
                f"Retrying in {delay:.2f}s...",
                extra=extra_context or {}
            )
            
            # Wait before retrying
            time.sleep(delay)
    
    # Should never reach here, but just in case
    if last_exception:
        raise last_exception


def retry_api_call(
    max_retries: int = 5,
    initial_delay: float = 1.0,
    max_delay: float = 60.0,
):
    """
    Specialized retry decorator for API calls (Azure OpenAI, etc.).
    
    Args:
        max_retries: Maximum number of retry attempts (higher for API calls)
        initial_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
    """
    return retry_with_backoff(
        max_retries=max_retries,
        initial_delay=initial_delay,
        max_delay=max_delay,
        exponential_base=2.0,
        retryable_exceptions=RetryConfig.RETRYABLE_API_ERRORS,
        on_retry=lambda e, attempt, delay: logger.warning(
            f"API call failed (attempt {attempt}): {type(e).__name__} - {e}. "
            f"Retrying in {delay:.2f}s..."
        ),
    )


def retry_with_circuit_breaker(
    max_retries: int = 3,
    circuit_breaker_threshold: int = 5,
    circuit_breaker_timeout: float = 60.0,
):
    """
    Advanced retry decorator with circuit breaker pattern.
    
    Circuit breaker prevents repeated attempts when a service is known to be down,
    reducing load and allowing faster failure.
    
    Args:
        max_retries: Maximum retry attempts per call
        circuit_breaker_threshold: Number of consecutive failures before opening circuit
        circuit_breaker_timeout: Seconds to wait before attempting to close circuit
    """
    class CircuitBreaker:
        def __init__(self):
            self.failure_count = 0
            self.last_failure_time = 0
            self.state = "closed"  # closed, open, half-open
    
    breaker = CircuitBreaker()
    
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Check circuit breaker state
            if breaker.state == "open":
                time_since_failure = time.time() - breaker.last_failure_time
                if time_since_failure < circuit_breaker_timeout:
                    raise Exception(
                        f"Circuit breaker is OPEN for {func.__name__}. "
                        f"Retry after {circuit_breaker_timeout - time_since_failure:.1f}s"
                    )
                else:
                    breaker.state = "half-open"
                    logger.info(f"Circuit breaker for {func.__name__} entering HALF-OPEN state")
            
            # Try the operation with retries
            try:
                result = retry_with_backoff(max_retries=max_retries)(func)(*args, **kwargs)
                
                # Success - reset circuit breaker
                if breaker.state == "half-open":
                    breaker.state = "closed"
                    breaker.failure_count = 0
                    logger.info(f"Circuit breaker for {func.__name__} CLOSED (recovered)")
                
                return result
                
            except Exception as e:
                # Failure - update circuit breaker
                breaker.failure_count += 1
                breaker.last_failure_time = time.time()
                
                if breaker.failure_count >= circuit_breaker_threshold:
                    breaker.state = "open"
                    logger.error(
                        f"Circuit breaker for {func.__name__} is now OPEN "
                        f"(threshold: {circuit_breaker_threshold} failures)"
                    )
                
                raise
        
        return wrapper
    return decorator


class RetryableOperation:
    """
    Wrapper for operations that need retry logic.
    
    Can be used as a context manager OR as a simple operation wrapper.
    
    Usage as context manager:
        with RetryableOperation(max_retries=3) as retry:
            while retry.should_retry():
                try:
                    result = perform_operation()
                    retry.success()
                    break
                except Exception as e:
                    retry.failure(e)
    
    Usage as operation wrapper:
        retry_op = RetryableOperation(
            operation=my_function,
            operation_name="my_operation",
            max_retries=3
        )
        result = retry_with_backoff(retry_op, logger)
    """
    
    def __init__(
        self,
        operation: Optional[Callable] = None,
        operation_name: Optional[str] = None,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        initial_delay: Optional[float] = None,  # Alias for base_delay
    ):
        self.operation = operation
        self.operation_name = operation_name or (operation.__name__ if operation else "unknown")
        self.max_retries = max_retries
        # Support both base_delay and initial_delay names
        self.initial_delay = initial_delay if initial_delay is not None else base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.attempt = 0
        self.last_exception = None
        self._success = False
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_val and not self._success:
            logger.error(f"Retryable operation failed after {self.attempt} attempts: {exc_val}")
        return False  # Don't suppress exceptions
    
    def should_retry(self) -> bool:
        """Check if operation should be retried"""
        return self.attempt <= self.max_retries
    
    def failure(self, exception: Exception):
        """Record a failure and wait before next retry"""
        self.last_exception = exception
        
        if self.attempt < self.max_retries:
            delay = exponential_backoff(
                self.attempt,
                initial_delay=self.initial_delay,
                exponential_base=self.exponential_base,
                max_delay=self.max_delay,
            )
            logger.warning(
                f"Operation failed (attempt {self.attempt + 1}/{self.max_retries + 1}): {exception}. "
                f"Retrying in {delay:.2f}s..."
            )
            time.sleep(delay)
        
        self.attempt += 1
    
    def success(self):
        """Mark operation as successful"""
        self._success = True


# Pre-configured retry decorators for common use cases
retry_llm_call = retry_api_call(max_retries=5, initial_delay=1.0, max_delay=60.0)
retry_db_query = retry_database_operation(max_retries=3, initial_delay=0.5, max_delay=10.0)
retry_external_api = retry_api_call(max_retries=4, initial_delay=2.0, max_delay=30.0)


if __name__ == "__main__":
    # Test the retry logic
    import random
    
    @retry_with_backoff(max_retries=3, initial_delay=0.5)
    def flaky_function():
        """Simulates a flaky function that fails randomly"""
        if random.random() < 0.7:
            raise APIError("Simulated API error")
        return "Success!"
    
    try:
        result = flaky_function()
        print(f"Result: {result}")
    except Exception as e:
        print(f"Failed: {e}")
