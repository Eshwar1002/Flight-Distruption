"""
Database Connection Pool Module

This module provides a thread-safe connection pool for SQLite database operations.
It replaces direct sqlite3.connect() calls with a pooled connection manager
for better performance and resource management.

Key Features:
- Connection pooling with configurable size
- Thread-safe connection management
- Automatic connection validation and recycling
- Context manager support for proper resource cleanup
- Configurable timeout and retry logic

Usage:
    from db_pool import get_connection, DatabasePool
    
    # Using context manager (recommended)
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM flights")
        results = cursor.fetchall()
    
    # Or get pool instance directly
    pool = DatabasePool.get_instance()
    conn = pool.get_connection()
    # ... use connection ...
    pool.release_connection(conn)
"""

import sqlite3
import threading
import time
from queue import Queue, Empty
from contextlib import contextmanager
from typing import Optional
from config import DB_PATH
from logger_config import get_logger
from retry_utils import execute_with_retry, RetryableOperation

# Initialize logger for db_pool module
logger = get_logger('db_pool')


class DatabasePool:
    """
    Thread-safe SQLite connection pool using Queue for connection management.
    
    Implements singleton pattern to ensure only one pool exists per application.
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __init__(self, db_path: str, pool_size: int = 10, timeout: int = 30):
        """
        Initialize the database connection pool.
        
        Args:
            db_path: Path to SQLite database file
            pool_size: Maximum number of connections in pool (default: 10)
            timeout: Timeout in seconds for getting connection (default: 30)
        """
        self.db_path = db_path
        self.pool_size = pool_size
        self.timeout = timeout
        self._pool = Queue(maxsize=pool_size)
        self._all_connections = []
        self._lock = threading.Lock()
        self._initialized = False
        
        logger.info(f"Initializing connection pool: path={db_path}, size={pool_size}, timeout={timeout}s")
        self._initialize_pool()
    
    @classmethod
    def get_instance(cls, db_path: str = None, pool_size: int = 10, timeout: int = 30) -> 'DatabasePool':
        """
        Get singleton instance of DatabasePool.
        
        Args:
            db_path: Database path (only used on first call)
            pool_size: Pool size (only used on first call)
            timeout: Timeout (only used on first call)
            
        Returns:
            DatabasePool instance
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    if db_path is None:
                        db_path = DB_PATH
                    cls._instance = cls(db_path, pool_size, timeout)
                    logger.info("Database pool singleton created")
        return cls._instance
    
    def _initialize_pool(self):
        """Create initial pool of database connections."""
        try:
            for i in range(self.pool_size):
                conn = self._create_connection()
                self._all_connections.append(conn)
                self._pool.put(conn)
            self._initialized = True
            logger.info(f"Connection pool initialized with {self.pool_size} connections")
        except Exception as e:
            logger.error(f"Failed to initialize connection pool: {e}")
            raise
    
    def _create_connection(self) -> sqlite3.Connection:
        """
        Create a new database connection with optimal settings.
        
        Returns:
            Configured SQLite connection
        """
        try:
            conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,  # Allow connection sharing across threads
                timeout=20.0,  # Database lock timeout
                isolation_level=None  # Autocommit mode for better concurrency
            )
            
            # Enable foreign key constraints
            conn.execute("PRAGMA foreign_keys = ON")
            
            # Optimize for concurrent access
            conn.execute("PRAGMA journal_mode = WAL")  # Write-Ahead Logging
            conn.execute("PRAGMA synchronous = NORMAL")  # Balance safety and speed
            conn.execute("PRAGMA cache_size = -64000")  # 64MB cache
            conn.execute("PRAGMA temp_store = MEMORY")  # Use memory for temp tables
            
            # Set row factory for dict-like access
            conn.row_factory = sqlite3.Row
            
            return conn
        except Exception as e:
            logger.error(f"Failed to create database connection: {e}")
            raise
    
    def _validate_connection(self, conn: sqlite3.Connection) -> bool:
        """
        Validate that a connection is still usable.
        
        Args:
            conn: Connection to validate
            
        Returns:
            True if connection is valid, False otherwise
        """
        try:
            conn.execute("SELECT 1").fetchone()
            return True
        except Exception as e:
            logger.warning(f"Connection validation failed: {e}")
            return False
    
    def get_connection(self, timeout: Optional[float] = None) -> sqlite3.Connection:
        """
        Get a connection from the pool with retry logic.
        
        Args:
            timeout: Override default timeout (seconds)
            
        Returns:
            Database connection
            
        Raises:
            RuntimeError: If no connection available after all retries
        """
        if timeout is None:
            timeout = self.timeout
        
        def _acquire_connection():
            """Inner function to acquire connection with validation"""
            try:
                conn = self._pool.get(timeout=timeout)
                
                # Validate connection and recreate if invalid
                if not self._validate_connection(conn):
                    logger.warning("Invalid connection detected, creating new one")
                    try:
                        conn.close()
                    except:
                        pass
                    conn = self._create_connection()
                    with self._lock:
                        if conn not in self._all_connections:
                            self._all_connections.append(conn)
                
                return conn
                
            except Empty:
                logger.error(f"Connection pool timeout after {timeout}s")
                raise RuntimeError(f"Could not get database connection within {timeout}s")
        
        # Wrap connection acquisition with retry logic
        retry_operation = RetryableOperation(
            operation=_acquire_connection,
            operation_name="get_db_connection",
            max_retries=3,
            base_delay=0.5,
            max_delay=5.0,
            exponential_base=2.0
        )
        
        try:
            return execute_with_retry(retry_operation, logger)
        except Exception as e:
            logger.error(f"Failed to acquire database connection after all retries: {e}")
            raise
    
    def release_connection(self, conn: sqlite3.Connection):
        """
        Return a connection to the pool.
        
        Args:
            conn: Connection to return
        """
        if conn is None:
            return
        
        try:
            # Rollback any uncommitted transactions
            try:
                conn.rollback()
            except:
                pass
            
            # Return to pool
            self._pool.put(conn, block=False)
        except Exception as e:
            logger.warning(f"Error releasing connection: {e}")
            # If pool is full, close the connection
            try:
                conn.close()
            except:
                pass
    
    def close_all(self):
        """Close all connections in the pool. Call this on application shutdown."""
        logger.info("Closing all database connections...")
        
        with self._lock:
            for conn in self._all_connections:
                try:
                    conn.close()
                except Exception as e:
                    logger.warning(f"Error closing connection: {e}")
            
            self._all_connections.clear()
            
            # Clear the queue
            while not self._pool.empty():
                try:
                    self._pool.get_nowait()
                except Empty:
                    break
        
        logger.info("All database connections closed")
    
    def get_stats(self) -> dict:
        """
        Get pool statistics.
        
        Returns:
            Dictionary with pool metrics
        """
        return {
            "pool_size": self.pool_size,
            "available_connections": self._pool.qsize(),
            "total_connections": len(self._all_connections),
            "in_use": len(self._all_connections) - self._pool.qsize(),
            "db_path": self.db_path
        }


# ----------------------------------------------------------------------
# Convenience Functions
# ----------------------------------------------------------------------

@contextmanager
def get_connection(timeout: Optional[float] = None):
    """
    Context manager for getting a database connection from the pool.
    
    Usage:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM flights")
            results = cursor.fetchall()
    
    Args:
        timeout: Optional timeout override
        
    Yields:
        Database connection
    """
    pool = DatabasePool.get_instance()
    conn = pool.get_connection(timeout=timeout)
    try:
        yield conn
    finally:
        pool.release_connection(conn)


def get_pool_stats() -> dict:
    """
    Get current pool statistics.
    
    Returns:
        Dictionary with pool metrics
    """
    pool = DatabasePool.get_instance()
    return pool.get_stats()


def close_pool():
    """Close all connections in the pool. Call on application shutdown."""
    pool = DatabasePool.get_instance()
    pool.close_all()


# ----------------------------------------------------------------------
# Legacy Compatibility Function
# ----------------------------------------------------------------------

def _conn() -> sqlite3.Connection:
    """
    Legacy function for backward compatibility.
    Returns a connection from the pool.
    
    NOTE: When using this function, you MUST manually release the connection
    back to the pool by calling DatabasePool.get_instance().release_connection(conn)
    or use the get_connection() context manager instead.
    
    Deprecated: Use get_connection() context manager instead.
    """
    pool = DatabasePool.get_instance()
    return pool.get_connection()
