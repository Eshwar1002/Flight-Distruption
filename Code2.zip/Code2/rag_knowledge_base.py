# rag_knowledge_base.py
# RAG-based Knowledge Base for Flight Policy Documents

import os
import pickle
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

# PDF and text processing
from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_openai import AzureOpenAIEmbeddings

from config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
    POLICIES_DIR,
    VECTOR_DB_DIR,
    RAG_CHUNK_SIZE,
    RAG_CHUNK_OVERLAP,
    RAG_TOP_K,
)

# Import retry utilities
from retry_utils import retry_api_call, retry_with_backoff, RetryableOperation

print("[OK] rag_knowledge_base.py loaded")


class PolicyKnowledgeBase:
    """
    RAG-based knowledge base for flight policy documents.
    Uses Azure OpenAI for embeddings and FAISS for vector storage.
    """

    def __init__(self):
        self.policies_dir = Path(POLICIES_DIR)
        self.vector_db_path = Path(VECTOR_DB_DIR) / "policy_faiss_index"
        self.metadata_path = Path(VECTOR_DB_DIR) / "policy_metadata.pkl"
        self.vectorstore: Optional[FAISS] = None
        self.embeddings = self._initialize_embeddings()
        self.is_initialized = False

    def _initialize_embeddings(self) -> AzureOpenAIEmbeddings:
        """Initialize Azure OpenAI embeddings."""
        if not AZURE_OPENAI_API_KEY:
            raise ValueError("AZURE_OPENAI_API_KEY not set in environment variables")

        return AzureOpenAIEmbeddings(
            azure_deployment=AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
            api_key=AZURE_OPENAI_API_KEY,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            api_version=AZURE_OPENAI_API_VERSION,
        )

    def load_or_create_vectorstore(self) -> None:
        """Load existing vector store or create a new one from PDFs."""
        if self.vector_db_path.exists():
            print("[INFO] Loading existing policy vector database...")
            try:
                self.vectorstore = FAISS.load_local(
                    str(self.vector_db_path),
                    self.embeddings,
                    allow_dangerous_deserialization=True
                )
                self.is_initialized = True
                print("[OK] Policy vector database loaded successfully")
                return
            except Exception as e:
                print(f"[WARNING] Error loading vector store: {e}")
                print("[INFO] Will create new vector store from PDFs...")

        # Create new vector store from PDFs
        self.create_vectorstore_from_pdfs()

    def create_vectorstore_from_pdfs(self) -> None:
        """Create vector store from PDF and TXT documents in the policies directory."""
        print(f" Loading policy documents from {self.policies_dir}...")

        # Check if policies directory has documents
        pdf_files = list(self.policies_dir.glob("*.pdf"))
        txt_files = list(self.policies_dir.glob("*.txt"))
        
        # Filter out README.txt from txt_files
        txt_files = [f for f in txt_files if f.name.lower() != "readme.txt"]
        
        total_files = len(pdf_files) + len(txt_files)
        
        if total_files == 0:
            print(f" No PDF or TXT files found in {self.policies_dir}")
            print(" Creating sample policy directory structure...")
            self._create_sample_policy_structure()
            return

        print(f" Found {len(pdf_files)} PDF files and {len(txt_files)} TXT files")

        all_documents = []

        # Load PDFs
        if pdf_files:
            pdf_loader = DirectoryLoader(
                str(self.policies_dir),
                glob="**/*.pdf",
                loader_cls=PyPDFLoader,
                show_progress=True,
            )
            try:
                pdf_documents = pdf_loader.load()
                all_documents.extend(pdf_documents)
                print(f" Loaded {len(pdf_documents)} pages from PDF files")
            except Exception as e:
                print(f" Error loading PDFs: {e}")

        # Load TXT files
        if txt_files:
            for txt_file in txt_files:
                try:
                    txt_loader = TextLoader(str(txt_file), encoding='utf-8')
                    txt_documents = txt_loader.load()
                    all_documents.extend(txt_documents)
                    print(f" Loaded {txt_file.name}")
                except Exception as e:
                    print(f" Error loading {txt_file.name}: {e}")

        try:
            documents = all_documents
            print(f" Total: Loaded {len(documents)} document sections from {total_files} files")

            if not documents:
                print(" No content extracted from PDFs")
                return

            # Split documents into chunks
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=RAG_CHUNK_SIZE,
                chunk_overlap=RAG_CHUNK_OVERLAP,
                length_function=len,
                separators=["\n\n", "\n", " ", ""],
            )

            chunks = text_splitter.split_documents(documents)
            print(f" Split into {len(chunks)} chunks")

            # Add metadata to chunks
            for chunk in chunks:
                chunk.metadata["indexed_date"] = datetime.now().isoformat()
                chunk.metadata["source_file"] = Path(chunk.metadata.get("source", "unknown")).name

            # Create vector store
            print(" Creating embeddings and vector store (this may take a while)...")
            self.vectorstore = FAISS.from_documents(chunks, self.embeddings)

            # Save vector store
            self.vectorstore.save_local(str(self.vector_db_path))
            print(f" Vector store saved to {self.vector_db_path}")

            # Save metadata
            metadata = {
                "pdf_count": len(pdf_files),
                "txt_count": len(txt_files),
                "total_files": total_files,
                "chunk_count": len(chunks),
                "created_date": datetime.now().isoformat(),
                "pdf_files": [f.name for f in pdf_files],
                "txt_files": [f.name for f in txt_files],
            }
            with open(self.metadata_path, "wb") as f:
                pickle.dump(metadata, f)

            self.is_initialized = True
            print(" Policy knowledge base created successfully")

        except Exception as e:
            print(f" Error creating vector store: {e}")
            raise

    def _create_sample_policy_structure(self) -> None:
        """Create sample policy directory structure and README."""
        readme_path = self.policies_dir / "README.txt"
        with open(readme_path, "w") as f:
            f.write("""Flight Policy Documents - README
=====================================

This directory should contain your flight policy PDF documents.

Please add PDF files covering topics such as:
- Rebooking policies
- Cancellation policies
- Compensation rules
- Passenger rights
- Special accommodation policies
- Multi-passenger group policies
- International flight regulations
- Delayed flight procedures
- Emergency situations

Once you add PDF files to this directory, run the policy indexing:
    python -c "from rag_knowledge_base import initialize_knowledge_base; initialize_knowledge_base()"

Or the knowledge base will be automatically created when first queried.
""")
        print(f" Created README at {readme_path}")
        print(" Please add your flight policy PDF documents to this directory")

    def query(self, query: str, top_k: int = None) -> List[Dict[str, Any]]:
        """
        Query the knowledge base and return relevant policy information with automatic retry.

        Args:
            query: Search query string
            top_k: Number of results to return (default: RAG_TOP_K from config)

        Returns:
            List of dictionaries containing relevant policy text and metadata
        """
        if not self.is_initialized:
            self.load_or_create_vectorstore()

        if not self.vectorstore:
            print(" Vector store not initialized")
            return []

        top_k = top_k or RAG_TOP_K

        # Wrap the similarity search with retry logic for API errors
        @retry_api_call(max_retries=3, initial_delay=1.0, max_delay=10.0)
        def _query_with_retry():
            return self.vectorstore.similarity_search_with_score(query, k=top_k)

        try:
            # Perform similarity search with retry
            results = _query_with_retry()

            # Format results
            formatted_results = []
            for doc, score in results:
                formatted_results.append({
                    "content": doc.page_content,
                    "source": doc.metadata.get("source_file", "unknown"),
                    "page": doc.metadata.get("page", "unknown"),
                    "similarity_score": float(score),
                    "metadata": doc.metadata,
                })

            return formatted_results

        except Exception as e:
            print(f" Error querying knowledge base after retries: {e}")
            return []

    def query_with_context(self, query: str, top_k: int = None) -> str:
        """
        Query the knowledge base and return formatted context for LLM.

        Args:
            query: Search query string
            top_k: Number of results to return

        Returns:
            Formatted string with relevant policy information
        """
        results = self.query(query, top_k)

        if not results:
            return "No relevant policy information found in the knowledge base."

        # Format results for LLM context
        context_parts = []
        context_parts.append(f"Relevant Flight Policy Information for: '{query}'\n")
        context_parts.append("=" * 70 + "\n")

        for i, result in enumerate(results, 1):
            context_parts.append(f"\n Policy Excerpt {i} (from {result['source']}, page {result['page']}):")
            context_parts.append("-" * 70)
            context_parts.append(result["content"])
            context_parts.append("")

        return "\n".join(context_parts)

    def add_documents(self, pdf_paths: List[str]) -> None:
        """
        Add new PDF documents to the knowledge base.

        Args:
            pdf_paths: List of paths to PDF files to add
        """
        if not self.is_initialized:
            self.load_or_create_vectorstore()

        print(f" Adding {len(pdf_paths)} new documents to knowledge base...")

        all_chunks = []
        for pdf_path in pdf_paths:
            loader = PyPDFLoader(pdf_path)
            documents = loader.load()

            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=RAG_CHUNK_SIZE,
                chunk_overlap=RAG_CHUNK_OVERLAP,
            )
            chunks = text_splitter.split_documents(documents)

            for chunk in chunks:
                chunk.metadata["indexed_date"] = datetime.now().isoformat()
                chunk.metadata["source_file"] = Path(pdf_path).name

            all_chunks.extend(chunks)

        if all_chunks:
            if self.vectorstore is None:
                # Create new vectorstore
                self.vectorstore = FAISS.from_documents(all_chunks, self.embeddings)
            else:
                # Add to existing vectorstore
                new_vectorstore = FAISS.from_documents(all_chunks, self.embeddings)
                self.vectorstore.merge_from(new_vectorstore)

            # Save updated vectorstore
            self.vectorstore.save_local(str(self.vector_db_path))
            print(f" Added {len(all_chunks)} chunks from {len(pdf_paths)} documents")

    def rebuild_index(self) -> None:
        """Rebuild the entire index from scratch."""
        print(" Rebuilding policy knowledge base index...")
        if self.vector_db_path.exists():
            import shutil
            shutil.rmtree(self.vector_db_path)
        if self.metadata_path.exists():
            os.remove(self.metadata_path)
        self.is_initialized = False
        self.vectorstore = None
        self.create_vectorstore_from_pdfs()

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the knowledge base."""
        stats = {
            "is_initialized": self.is_initialized,
            "policies_directory": str(self.policies_dir),
            "vector_db_path": str(self.vector_db_path),
        }

        if self.metadata_path.exists():
            with open(self.metadata_path, "rb") as f:
                metadata = pickle.load(f)
                stats.update(metadata)

        pdf_files = list(self.policies_dir.glob("*.pdf"))
        stats["current_pdf_count"] = len(pdf_files)

        return stats


# Global instance
_knowledge_base: Optional[PolicyKnowledgeBase] = None


def get_knowledge_base() -> PolicyKnowledgeBase:
    """Get or create the global knowledge base instance."""
    global _knowledge_base
    if _knowledge_base is None:
        _knowledge_base = PolicyKnowledgeBase()
    return _knowledge_base


def initialize_knowledge_base(rebuild: bool = False) -> PolicyKnowledgeBase:
    """
    Initialize the knowledge base.

    Args:
        rebuild: If True, rebuild the index from scratch

    Returns:
        PolicyKnowledgeBase instance
    """
    kb = get_knowledge_base()
    if rebuild:
        kb.rebuild_index()
    else:
        kb.load_or_create_vectorstore()
    return kb


def query_flight_policies(query: str, top_k: int = None) -> str:
    """
    Query flight policies - convenience function for agents.

    Args:
        query: Search query
        top_k: Number of results to return

    Returns:
        Formatted context string with relevant policy information
    """
    kb = get_knowledge_base()
    if not kb.is_initialized:
        kb.load_or_create_vectorstore()
    return kb.query_with_context(query, top_k)


if __name__ == "__main__":
    # Test the knowledge base
    print(" Testing Policy Knowledge Base...")
    kb = initialize_knowledge_base()
    print(f"\n Knowledge Base Stats:")
    stats = kb.get_stats()
    for key, value in stats.items():
        print(f"   {key}: {value}")

    # Test query
    if kb.is_initialized:
        test_query = "What are the rebooking policies for cancelled flights?"
        print(f"\n Test Query: {test_query}")
        results = kb.query_with_context(test_query)
        print(results)
