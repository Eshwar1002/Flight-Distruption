# tools.py - MULTI-PASSENGER PNR SUPPORT
import os
import json
import sqlite3
import random
from typing import Any, Dict, Optional
from datetime import datetime, timedelta

from langchain_core.tools import tool
from config import DB_PATH, RAI_PROFILE
from support_functions import (
    get_pnr_details,
    calculate_flight_cost,
    get_aircraft_type,
    update_flight_status,
    update_pnr_flight,
    check_flight_capacity,
    get_pnr_passenger_count,
    update_pnr_status,
    get_disrupted_pnrs_active,
    get_pnr_action_history,
)
from db_pool import get_connection, DatabasePool

# Import retry utilities
from retry_utils import (
    retry_with_backoff,
    retry_db_query,
    retry_llm_call,
    retry_api_call,
    RetryableOperation,
)

# Import RAG knowledge base
try:
    from rag_knowledge_base import query_flight_policies as _query_kb
    RAG_AVAILABLE = True
except ImportError as e:
    print(f"[WARNING] RAG knowledge base not available: {e}")
    RAG_AVAILABLE = False

# Global context for policy guidance (thread-safe per-execution)
_policy_context = {}

print("[OK] tools.py loaded (Multi-Passenger Support)")

# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------
DEBUG = os.getenv("RECOVERAI_DEBUG", "1").lower() in ("1", "true", "yes")

def log(section: str, msg: str, level: str = "info"):
    """Log a message with section label"""
    if DEBUG:
        try:
            # Sanitize section and message to remove non-ASCII characters
            section_clean = ''.join(c if ord(c) < 128 else '?' for c in str(section))
            msg_clean = ''.join(c if ord(c) < 128 else '?' for c in str(msg))
            print(f"[{section_clean}] {msg_clean}")
        except UnicodeEncodeError:
            # If even printing fails, just skip logging
            pass


# -----------------------------------------------------------------------------
# DB helpers (Using Connection Pool with Retry Logic)
# -----------------------------------------------------------------------------

@retry_db_query
def _execute_db_query(query: str, params: tuple = ()) -> list:
    """
    Execute a database query with automatic retry logic.
    
    Args:
        query: SQL query string
        params: Query parameters
        
    Returns:
        List of rows returned by the query
        
    Note: Uses connection pool and retries on failure with exponential backoff
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor.fetchall()

@retry_db_query
def _execute_db_write(query: str, params: tuple = ()) -> int:
    """
    Execute a database write operation (INSERT/UPDATE/DELETE) with retry logic.
    
    Args:
        query: SQL query string
        params: Query parameters
        
    Returns:
        Number of rows affected (lastrowid for INSERTs)
        
    Note: Uses connection pool and retries on failure with exponential backoff
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        return cursor.lastrowid if cursor.lastrowid else cursor.rowcount

def _conn() -> sqlite3.Connection:
    """
    DEPRECATED: Get database connection (backward compatibility).
    
    WARNING: This function creates DIRECT connections, not pooled connections,
    for backward compatibility with existing code that doesn't release connections.
    These connections will be automatically closed by Python's garbage collector.
    
    For new code, use the connection pool with context manager:
        with get_connection() as conn:
            # your code here
    """
    return sqlite3.connect(DB_PATH)

def _parse_dt(value: Any) -> datetime:
    """Accept datetime or string (%Y-%m-%d %H:%M[:%S] or ISO-ish)."""
    if isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        raise TypeError(f"Expected datetime or str, got {type(value)}")

    s = value.strip().replace("Z", "")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    raise ValueError(f"Unrecognized datetime format: {value}")


def _assign_seat(aircraft_type: str, class_of_service: str, cursor: sqlite3.Cursor,
                 flight_number: str) -> str:
    """Assign a random seat avoiding duplicates for the target flight."""
    cos_key = "BC" if class_of_service in ("Business", "BC", "Business Class") else "EC"
    caps = RAI_PROFILE["capacities"]["aircraft"].get(aircraft_type, {"BC": 8, "EC": 150})
    max_rows = caps.get(cos_key, 100)

    attempts = 0
    max_attempts = 100
    
    while attempts < max_attempts:
        if cos_key == "BC":
            seat = f"{random.randint(1, max_rows):02}{chr(random.randint(65, 68))}"  # A-D
        else:
            seat = f"{random.randint(1, max_rows):02}{chr(random.randint(65, 70))}"  # A-F
        
        exists = cursor.execute(
            "SELECT 1 FROM seat_assignments WHERE flight_number=? AND seat_number=?",
            (flight_number, seat)
        ).fetchone()
        
        if not exists:
            return seat
        
        attempts += 1
    
    # Fallback if all attempts fail
    return f"{random.randint(1, max_rows):02}{chr(random.randint(65, 70))}"


def _ensure_flight_record(cursor: sqlite3.Cursor, new_flight: Dict[str, Any]) -> None:
    """If an OAG flight is selected, ensure a row exists in flights for booking."""
    fn = new_flight["flight_number"]
    exists = cursor.execute("SELECT 1 FROM flights WHERE flight_number=?", (fn,)).fetchone()
    if exists:
        return

    dep = _parse_dt(new_flight["departure_time"]).strftime("%Y-%m-%d %H:%M:%S")
    arr = _parse_dt(new_flight["arrival_time"]).strftime("%Y-%m-%d %H:%M:%S")
    ac_type = new_flight.get("aircraft_type", "Unknown")
    cost = float(new_flight.get("cost") or calculate_flight_cost({
        "aircraft_type": ac_type,
        "distance": float(new_flight.get("distance", 0) or 0)
    }))
    distance = float(new_flight.get("distance", 0) or 0)

    # Create aircraft ID for OAG flight (without flight number for consistency)
    aircraft_id = f"OAG-{ac_type}"
    
    # Get default capacity based on aircraft type
    capacity_map = {
        "A320": 158,
        "B737": 158,
        "B777": 366,
        "B787": 242
    }
    capacity = capacity_map.get(ac_type, 158)  # Default to 158 if unknown
    
    # Ensure aircraft record exists (shared across all OAG flights of this type)
    cursor.execute("SELECT 1 FROM aircraft WHERE aircraft_id=?", (aircraft_id,))
    if not cursor.fetchone():
        cursor.execute(
            """
            INSERT INTO aircraft
            (aircraft_id, location, status, aircraft_type, is_reserve, capacity)
            VALUES (?,?,?,?,?,?)
            """,
            (aircraft_id, new_flight["origin"], "Available", ac_type, 0, capacity)
        )
        log("booking_apply", f"Created aircraft record: {aircraft_id} (capacity: {capacity})")

    cursor.execute(
        """
        INSERT INTO flights
        (flight_number, origin, destination, departure_time, arrival_time,
         aircraft_id, aircraft_type, status, cost, distance)
        VALUES (?,?,?,?,?,?,?,?,?,?)
        """,
        (
            fn, new_flight["origin"], new_flight["destination"], dep, arr,
            aircraft_id, ac_type, "Scheduled", cost, distance
        )
    )
    log("booking_apply", f"Inserted external flight into DB: {fn} with aircraft {aircraft_id} (capacity: {capacity})")


# -----------------------------------------------------------------------------
# Policy Filtering and Compliance
# -----------------------------------------------------------------------------
def _apply_policy_filters(candidates: list, original: Dict[str, Any], policy_guidance: str = None) -> tuple:
    """
    Apply policy constraints to filter flight alternatives.
    
    Args:
        candidates: List of candidate flight dictionaries
        original: Original flight dictionary
        policy_guidance: Optional policy text from RAG knowledge base
    
    Returns:
        Tuple of (filtered_candidates, policy_compliance_report)
    """
    filtered = []
    violations = []
    compliance_report = {
        "total_candidates": len(candidates),
        "policy_checks_applied": [],
        "filtered_out": 0,
        "violations": [],
        "policy_source": "RAG Knowledge Base" if policy_guidance else "Default Policies"
    }
    
    # Log policy guidance preview for debugging
    if policy_guidance:
        preview = policy_guidance[:500] if len(policy_guidance) > 500 else policy_guidance
        log("policy_filter", f"Using policy guidance ({len(policy_guidance)} chars): {preview}...")
    else:
        log("policy_filter", "No policy guidance provided - using default constraints")
    
    # Default policy constraints (can be overridden by RAG policy guidance)
    max_delay_hours = 24.0  # Maximum acceptable delay from original departure
    allow_connecting = False  # Only direct flights by default
    maintain_class = True  # Maintain or upgrade booking class
    
    # Parse policy guidance if provided
    if policy_guidance:
        log("policy_filter", "Applying policy guidance from knowledge base")
        policy_lower = policy_guidance.lower()
        
        # Extract delay tolerance from policy using multiple pattern matching
        import re
        
        # Look for delay limits: "6 hours", "24 hours", "12 hours", etc.
        delay_patterns = [
            r'(?:maximum delay|delay limit|within)\s*[:\-]?\s*(\d+)\s*hours?',
            r'depart within\s+(\d+)\s*hours?',
            r'alternative.{0,30}(\d+)\s*hours?',
            r'cancellation.*?(\d+)\s*hours?',
            r'delay.*?(\d+)\s*hours?'
        ]
        
        found_delays = []
        for pattern in delay_patterns:
            matches = re.findall(pattern, policy_lower)
            if matches:
                found_delays.extend([int(m) for m in matches])
        
        # Use the maximum delay found in policy (typically 24 hours for cancellations)
        if found_delays:
            max_delay_hours = max(found_delays)
            log("policy_filter", f"Policy specifies maximum delay: {max_delay_hours} hours (found: {found_delays})")
        else:
            log("policy_filter", "No specific delay limit found in policy, using default 24 hours")
        
        # Check for connecting flight policy - look for various phrasings
        connecting_phrases = [
            "connecting flight",
            "connection",
            "multi-leg",
            "indirect flight",
            "layover"
        ]
        
        allows_phrases = ["allowed", "acceptable", "permitted", "may include", "can use"]
        prohibits_phrases = ["not allowed", "prohibited", "must be direct", "direct flight only", "no connection"]
        
        # Check if any prohibit phrases are present
        has_prohibition = any(phrase in policy_lower for phrase in prohibits_phrases)
        
        # Check if allows phrases are present with connecting references
        has_allowance = any(
            conn_phrase in policy_lower and any(allow_phrase in policy_lower for allow_phrase in allows_phrases)
            for conn_phrase in connecting_phrases
        )
        
        if has_prohibition:
            allow_connecting = False
            log("policy_filter", "Policy PROHIBITS connecting flights - direct flights only")
        elif has_allowance:
            allow_connecting = True
            log("policy_filter", "Policy ALLOWS connecting flights")
        else:
            # Default to direct flights only for safety
            allow_connecting = False
            log("policy_filter", "Policy unclear on connecting flights - defaulting to direct only")
    
    compliance_report["policy_checks_applied"].append(f"Maximum delay: {max_delay_hours} hours")
    compliance_report["policy_checks_applied"].append(f"Connecting flights: {'Allowed' if allow_connecting else 'Not allowed'}")
    compliance_report["policy_checks_applied"].append(f"Class of service: {'Must maintain or upgrade' if maintain_class else 'Any class'}")
    
    for cand in candidates:
        violated = False
        violation_reasons = []
        
        # Check 1: Maximum delay constraint
        try:
            delay_hours = (_parse_dt(cand["departure_time"]) - _parse_dt(original["departure_time"])).total_seconds() / 3600.0
            if delay_hours > max_delay_hours:
                violated = True
                violation_reasons.append(f"Delay {delay_hours:.1f}h exceeds policy limit of {max_delay_hours}h")
        except Exception as e:
            log("policy_filter", f"Could not check delay for {cand.get('flight_number')}: {e}")
        
        # Check 2: Direct flight requirement
        if not allow_connecting and not cand.get("is_direct", True):
            violated = True
            violation_reasons.append("Connecting flight violates direct-only policy")
        
        # Check 3: Route equivalence (same origin and destination)
        if cand.get("origin") != original.get("origin") or cand.get("destination") != original.get("destination"):
            violated = True
            violation_reasons.append("Route differs from original booking")
        
        # Check 4: Class of service (if cost is significantly lower, might be downgrade)
        if maintain_class:
            orig_cost = float(original.get("cost", 0))
            cand_cost = float(cand.get("cost", 0))
            if cand_cost < orig_cost * 0.7:  # More than 30% cheaper suggests downgrade
                violation_reasons.append("Potential class downgrade (cost significantly lower)")
                # Note: This is a warning, not a hard violation
        
        if violated:
            violations.append({
                "flight_number": cand.get("flight_number"),
                "reasons": violation_reasons
            })
            compliance_report["filtered_out"] += 1
            log("policy_filter", f"Filtered out {cand.get('flight_number')}: {', '.join(violation_reasons)}")
        else:
            filtered.append(cand)
    
    compliance_report["violations"] = violations
    compliance_report["compliant_candidates"] = len(filtered)
    
    log("policy_filter", f"Policy filtering: {len(filtered)}/{len(candidates)} candidates comply with policies")
    
    return filtered, compliance_report


# -----------------------------------------------------------------------------
# Candidate scoring
# -----------------------------------------------------------------------------
def _score_candidate(cand: Dict[str, Any], original: Dict[str, Any]) -> float:
    """
    Score flight alternatives by comparing them to the original flight.
    Higher score is better (closer to original = better).
    Score range: 0-100 (capped at 100)
    
    Scoring methodology:
    score = 100.0 - (delay_hours * 5.0) - (cost_diff * 0.01)
    score = max(0.0, score)  # Ensure non-negative
    
    Where:
    - delay_hours: How many hours later the candidate departs vs original (0 if earlier)
    - cost_diff: How much more expensive the candidate is vs original (0 if cheaper)
    
    Returns:
        float: Score 0-100 (higher = better alternative)
    """
    score = 100.0
    
    # -------------------------------------------------------------------------
    # 1. TIME PENALTY (Departure time vs Original)
    # -------------------------------------------------------------------------
    try:
        original_dt = _parse_dt(original["departure_time"])
        candidate_dt = _parse_dt(cand["departure_time"])
        time_diff_hours = (candidate_dt - original_dt).total_seconds() / 3600.0
        
        # Only penalize if departure is LATER (positive delay)
        if time_diff_hours > 0:
            delay_hours = time_diff_hours
            score -= (delay_hours * 5.0)
        # If earlier, delay_hours = 0, no penalty
    except Exception:
        pass
    
    # -------------------------------------------------------------------------
    # 2. COST PENALTY (Fare vs Original)
    # -------------------------------------------------------------------------
    try:
        original_cost = float(original.get("cost", 0))
        candidate_cost = float(cand.get("cost", 0))
        cost_difference = candidate_cost - original_cost
        
        # Only penalize if MORE expensive (positive cost diff)
        if cost_difference > 0:
            cost_diff = cost_difference
            score -= (cost_diff * 0.01)
        # If cheaper, cost_diff = 0, no penalty
    except Exception:
        pass
    
    # Ensure non-negative
    score = max(0.0, score)
    
    return score


# -----------------------------------------------------------------------------
# Group Split Booking Helpers
# -----------------------------------------------------------------------------
def _identify_children_and_adults(passengers: list) -> tuple:
    """
    Separate passengers into children and adults.
    Returns: (children_list, adults_list)
    """
    children = []
    adults = []
    
    for p in passengers:
        age_group = p.get("age_group", "adult").lower()
        # child or infant are considered children needing supervision
        if age_group in ["child", "infant"]:
            children.append(p)
        else:
            adults.append(p)
    
    return children, adults


def _can_split_group_safely(passengers: list, split_assignments: dict) -> bool:
    """
    Verify that each child is assigned to the same flight as at least one adult.
    
    Args:
        passengers: list of passenger dicts with age_group field
        split_assignments: dict mapping flight_number to list of passenger_ids
    
    Returns:
        True if split is safe (all children accompanied), False otherwise
    """
    children, adults = _identify_children_and_adults(passengers)
    
    # If no children, any split is safe
    if not children:
        return True
    
    # Create reverse mapping: passenger_id -> flight_number
    passenger_to_flight = {}
    for flight_num, passenger_ids in split_assignments.items():
        for pid in passenger_ids:
            passenger_to_flight[pid] = flight_num
    
    # Check each child has at least one adult on same flight
    for child in children:
        child_flight = passenger_to_flight.get(child["passenger_id"])
        if not child_flight:
            log("split_validation", f"Child {child['passenger_id']} not assigned to any flight")
            return False
        
        # Find at least one adult on the same flight
        has_adult_companion = False
        for adult in adults:
            adult_flight = passenger_to_flight.get(adult["passenger_id"])
            if adult_flight == child_flight:
                has_adult_companion = True
                break
        
        if not has_adult_companion:
            log("split_validation", f"Child {child['passenger_id']} ({child['name']}) has no adult on flight {child_flight}")
            return False
    
    return True


def _create_split_booking_plan(passengers: list, available_flights: list) -> dict:
    """
    Create an intelligent split booking plan that ensures:
    1. Each child is on the same flight as at least one adult
    2. Passengers are distributed across flights based on available capacity
    
    Args:
        passengers: List of passenger dicts with passenger_id, name, age_group
        available_flights: List of flight dicts with flight_number and available_seats
    
    Returns:
        dict with:
        - "split_assignments": {flight_number: [passenger_ids]}
        - "is_valid": bool
        - "unassigned_passengers": list of passenger_ids
    """
    children, adults = _identify_children_and_adults(passengers)
    
    log("split_booking", f"Planning split for {len(passengers)} passengers: {len(children)} children, {len(adults)} adults")
    
    # Sort flights by departure time (prefer earlier)
    sorted_flights = sorted(available_flights, 
                           key=lambda f: f.get("departure_time", ""))
    
    split_assignments = {}
    unassigned_passengers = []
    
    # Strategy: Assign children with adults, allowing one adult to accompany multiple children
    remaining_adults = adults.copy()
    remaining_children = children.copy()
    
    for flight in sorted_flights:
        flight_num = flight["flight_number"]
        available_seats = flight.get("available_seats", 0)
        split_assignments[flight_num] = []
        
        if available_seats <= 0:
            continue
        
        # If we have children to assign, ensure at least one adult accompanies them
        if remaining_children and remaining_adults and available_seats >= 2:
            # Assign one adult first
            adult = remaining_adults.pop(0)
            split_assignments[flight_num].append(adult["passenger_id"])
            available_seats -= 1
            log("split_booking", f"Assigned adult {adult['name']} to {flight_num} (guardian)")
            
            # Assign as many children as possible with this adult
            children_on_this_flight = 0
            while remaining_children and available_seats > 0:
                child = remaining_children.pop(0)
                split_assignments[flight_num].append(child["passenger_id"])
                available_seats -= 1
                children_on_this_flight += 1
                log("split_booking", f"Assigned child {child['name']} to {flight_num} (with adult {adult['name']})")
            
            log("split_booking", f"Flight {flight_num}: 1 adult accompanying {children_on_this_flight} child(ren)")
        
        # Fill remaining seats with adults only (no children left or no adult available)
        while remaining_adults and available_seats > 0:
            adult = remaining_adults.pop(0)
            split_assignments[flight_num].append(adult["passenger_id"])
            available_seats -= 1
            log("split_booking", f"Assigned adult {adult['name']} to {flight_num}")
    
    # Track unassigned
    for child in remaining_children:
        unassigned_passengers.append(child["passenger_id"])
        log("split_booking", f"WARNING: Could not assign child {child['name']}")
    
    for adult in remaining_adults:
        unassigned_passengers.append(adult["passenger_id"])
        log("split_booking", f"WARNING: Could not assign adult {adult['name']}")
    
    # Validate the split
    is_valid = _can_split_group_safely(passengers, split_assignments) and len(unassigned_passengers) == 0
    
    return {
        "split_assignments": split_assignments,
        "is_valid": is_valid,
        "unassigned_passengers": unassigned_passengers,
        "children_count": len(children),
        "adults_count": len(adults)
    }


def _get_available_seats(flight_number: str, exclude_pnr: str = None) -> int:
    """
    Get the number of available seats on a flight.
    
    Args:
        flight_number: The flight to check
        exclude_pnr: PNR to exclude from booked count (useful when rebooking)
    """
    conn = _conn()
    cursor = conn.cursor()
    
    # Get aircraft capacity - first try from flights table
    cursor.execute("""
        SELECT a.capacity
        FROM aircraft a
        JOIN flights f ON f.aircraft_id = a.aircraft_id
        WHERE f.flight_number = ?
    """, (flight_number,))
    
    row = cursor.fetchone()
    
    # If not found in flights table, check if it's an OAG flight
    if not row:
        cursor.execute("""
            SELECT aircraft_type
            FROM oag_flights
            WHERE flight_number = ?
        """, (flight_number,))
        
        oag_row = cursor.fetchone()
        if oag_row:
            # Estimate capacity for OAG flights based on aircraft type
            aircraft_type = oag_row[0]
            capacity_map = {
                "A320": 158,
                "B737": 158,
                "B777": 366,
                "B787": 242,
                "A330": 158  # Added A330
            }
            capacity = capacity_map.get(aircraft_type, 158)
        else:
            capacity = 0
    else:
        capacity = int(row[0])
    
    # Count currently booked passengers (excluding the PNR being rebooked)
    if exclude_pnr:
        cursor.execute("""
            SELECT COALESCE(SUM(pr.passenger_count), 0)
            FROM pnrs pr
            WHERE pr.flight_number = ? AND pr.pnr != ?
        """, (flight_number, exclude_pnr))
    else:
        cursor.execute("""
            SELECT COALESCE(SUM(pr.passenger_count), 0)
            FROM pnrs pr
            WHERE pr.flight_number = ?
        """, (flight_number,))
    
    booked = cursor.fetchone()[0]
    conn.close()
    
    available = capacity - booked
    return max(0, available)


# -----------------------------------------------------------------------------
# Tools - UPDATED FOR MULTI-PASSENGER
# -----------------------------------------------------------------------------
@tool
def get_passenger_by_pnr(pnr: str) -> dict:
    """
    Return complete PNR details with ALL passengers (multi-passenger support).
    Returns: PNR info with lead passenger name, total count, and list of all passengers.
    """
    pnr_details = get_pnr_details(pnr)
    if not pnr_details:
        return {"error": f"PNR {pnr} not found"}
    
    return {
        "pnr": pnr_details["pnr"],
        "lead_passenger_name": pnr_details["lead_passenger_name"],
        "passenger_count": pnr_details["passenger_count"],
        "flight_number": pnr_details["flight_number"],
        "booking_status": pnr_details["booking_status"],
        "flight_status": pnr_details["flight_status"],
        "passengers": pnr_details["passengers"]
    }


@tool
def get_original_flight(pnr: str) -> dict:
    """Return original flight details for a PNR."""
    conn = _conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT f.flight_number, f.origin, f.destination, f.departure_time, f.arrival_time,
               f.aircraft_type, f.status, f.cost, f.distance
        FROM flights f
        JOIN pnrs pr ON pr.flight_number = f.flight_number
        WHERE pr.pnr=?
    """, (pnr,))
    row = cur.fetchone()
    conn.close()
    
    if not row:
        return {"error": f"No flight found for PNR {pnr}"}
    
    return {
        "flight_number": row[0],
        "origin": row[1],
        "destination": row[2],
        "departure_time": row[3],
        "arrival_time": row[4],
        "aircraft_type": row[5],
        "status": row[6],
        "cost": row[7],
        "distance": row[8],
    }


@tool
def resource_find_alternative(pnr: str) -> dict:
    """
    Find alternative flights for a given PNR code. This tool searches for available flights that can accommodate all passengers in the booking.
    
    Use this tool to find replacement flights when a passenger's original flight is disrupted (cancelled or delayed).
    The tool automatically checks capacity for the entire passenger group and returns ranked alternatives.
    
    IMPORTANT: Always query the policy knowledge base BEFORE calling this tool.
    The tool will automatically use the policy information from your previous query to filter alternatives.
    
    Args:
        pnr: The 6-character PNR (Passenger Name Record) code, e.g., 'LXV93M'.
    
    Returns:
        A dictionary containing:
        - alternatives: List of policy-compliant available alternative flights
        - best_alternative: The top recommended flight
        - policy_compliance: Information about policy checks applied
        - violations: Flights that were filtered out due to policy violations
    
    Example:
        # Step 1: Query policy first
        query_policy_knowledge_base("flight rebooking policies")
        # Step 2: Find alternatives (will use policy from Step 1)
        resource_find_alternative(pnr="LXV93M")
    """
    global _policy_context
    
    # Retrieve policy guidance from context (set by previous query_policy_knowledge_base call)
    policy_guidance = _policy_context.get('latest')
    
    log("resource_agent", f"Finding alternatives for PNR: {pnr} | Policy guidance: {'YES' if policy_guidance else 'NO'}")
    
    # Validate input
    if not pnr or not isinstance(pnr, str):
        error_msg = f"Invalid PNR provided: {pnr}. PNR must be a valid string."
        log("resource_agent", f"ERROR: {error_msg}", level="error")
        return {"error": "Invalid PNR", "message": error_msg}
    
    pnr = pnr.strip().upper()
    
    pnr_details = get_pnr_details(pnr)
    if not pnr_details:
        error_msg = f"The provided PNR '{pnr}' could not be located in the system. Please verify the PNR and try again."
        log("resource_agent", f"ERROR: PNR not found - {error_msg}", level="error")
        return {"error": "PNR not found", "message": error_msg}
    
    passenger_count = pnr_details["passenger_count"]
    
    conn = _conn()
    cur = conn.cursor()
    
    # Get original flight
    cur.execute("""
        SELECT f.flight_number, f.origin, f.destination, f.departure_time, f.arrival_time,
               f.aircraft_type, f.status, f.cost, f.distance
        FROM flights f
        JOIN pnrs pr ON pr.flight_number = f.flight_number
        WHERE pr.pnr=?
    """, (pnr,))
    
    original_row = cur.fetchone()
    if not original_row:
        conn.close()
        return {"error": f"No flight found for PNR {pnr}"}
    
    original = {
        "flight_number": original_row[0],
        "origin": original_row[1],
        "destination": original_row[2],
        "departure_time": original_row[3],
        "arrival_time": original_row[4],
        "aircraft_type": original_row[5],
        "status": original_row[6],
        "cost": original_row[7],
        "distance": original_row[8],
    }
    
    # Determine disruption type
    disruption_type = "unknown"
    original_status = original.get("status", "").lower()
    if "cancelled" in original_status:
        disruption_type = "cancelled"
    elif "delayed" in original_status:
        disruption_type = "delayed"

    try:
        original_departure = _parse_dt(original["departure_time"])
    except Exception as e:
        conn.close()
        return {"error": f"Bad original departure time: {e}"}

    search_start = original_departure
    search_end = original_departure + timedelta(hours=24)

    scored_candidates = []
    best = None
    best_score = -1.0
    
    log("resource_find_alternative", "=== STARTING HIERARCHICAL FLIGHT SEARCH ===")
    
    try:
        # -------------------------------------------------------------------------
        # PRIORITY 1: DIRECT FLIGHTS - SAME AIRLINE (SUN AIRLINES)
        # -------------------------------------------------------------------------
        log("resource_find_alternative", "[P1] Searching direct flights on Sun Airlines (Scheduled)...")
        
        cur.execute("""
            SELECT flight_number, origin, destination, departure_time, arrival_time,
                   aircraft_id, aircraft_type, cost, distance
            FROM flights
            WHERE origin=? AND destination=? AND status='Scheduled'
              AND departure_time >= ? AND departure_time <= ?
        """, (original["origin"], original["destination"],
              search_start.strftime("%Y-%m-%d %H:%M:%S"),
              search_end.strftime("%Y-%m-%d %H:%M:%S")))
        
        for row in cur.fetchall():
            flight_number = row[0]
            
            cand = {
                "flight_number": flight_number,
                "origin": row[1],
                "destination": row[2],
                "departure_time": row[3],
                "arrival_time": row[4],
                "aircraft_id": row[5],
                "aircraft_type": row[6],
                "cost": float(row[7] or 0),
                "distance": float(row[8] or 0),
                "is_oag": False,
                "is_direct": True,
                "airline": "Sun Airlines",
                "priority": 1  # Highest priority
            }
            
            score = _score_candidate(cand, original)
            scored_candidates.append((cand, score))
            
            # Check if this flight has capacity for entire group
            if check_flight_capacity(flight_number, passenger_count):
                log("resource_find_alternative", f"[P1] ✓ Flight {flight_number} can accommodate {passenger_count} passenger(s)")
                if score > best_score:
                    best, best_score = cand, score
            else:
                available_seats = _get_available_seats(flight_number, pnr)
                if available_seats > 0:
                    log("resource_find_alternative", f"[P1] ○ Flight {flight_number} has only {available_seats}/{passenger_count} seats available (excluding PNR {pnr})")
                    cand["available_seats"] = available_seats
                else:
                    log("resource_find_alternative", f"[P1] ✗ Flight {flight_number} is fully booked (0 seats available)")

        # Check Reserve flights (still Priority 1 - same airline, direct)
        if not best:
            log("resource_find_alternative", "[P1] No scheduled flights found, checking Reserve flights...")
            cur.execute("""
                SELECT flight_number, origin, destination, departure_time, arrival_time,
                       aircraft_id, aircraft_type, cost, distance
                FROM flights
                WHERE origin=? AND destination=? AND status='Reserve'
                  AND departure_time >= ? AND departure_time <= ?
            """, (original["origin"], original["destination"],
                  search_start.strftime("%Y-%m-%d %H:%M:%S"),
                  search_end.strftime("%Y-%m-%d %H:%M:%S")))
            
            for row in cur.fetchall():
                flight_number = row[0]
                
                cand = {
                    "flight_number": flight_number,
                    "origin": row[1],
                    "destination": row[2],
                    "departure_time": row[3],
                    "arrival_time": row[4],
                    "aircraft_id": row[5],
                    "aircraft_type": row[6],
                    "cost": float(row[7] or 0),
                    "distance": float(row[8] or 0),
                    "is_oag": False,
                    "is_direct": True,
                    "airline": "Sun Airlines",
                    "priority": 1
                }
                
                score = _score_candidate(cand, original)
                scored_candidates.append((cand, score))
                
                if check_flight_capacity(flight_number, passenger_count):
                    log("resource_find_alternative", f"[P1] ✓ Reserve flight {flight_number} can accommodate {passenger_count} passenger(s)")
                    if score > best_score:
                        best, best_score = cand, score
                else:
                    available_seats = _get_available_seats(flight_number, pnr)
                    if available_seats > 0:
                        log("resource_find_alternative", f"[P1] ○ Reserve flight {flight_number} has only {available_seats}/{passenger_count} seats available")
                        cand["available_seats"] = available_seats
                    else:
                        log("resource_find_alternative", f"[P1] ✗ Reserve flight {flight_number} is fully booked (0 seats available)")
            
            if best:
                update_flight_status(best["flight_number"], "Scheduled")
        
        if best:
            log("resource_find_alternative", f"[P1] Found direct flight: {best['flight_number']}")
        
        # Priority 2: Connecting flights - Not implemented (requires multi-leg support)
        
        # Priority 3: Partner airlines (OAG)
        if not best:
            log("resource_find_alternative", "[P3] Searching direct flights on partner airlines (OAG)...")
            
            cur.execute("""
                SELECT flight_number, origin, destination, departure_time, arrival_time,
                       aircraft_type, cost, distance
                FROM oag_flights
                WHERE origin=? AND destination=?
                  AND departure_time >= ? AND departure_time <= ?
            """, (original["origin"], original["destination"],
                  search_start.strftime("%Y-%m-%d %H:%M:%S"),
                  search_end.strftime("%Y-%m-%d %H:%M:%S")))
            
            for row in cur.fetchall():
                flight_number = row[0]
                aircraft_type = row[5]
                
                # For OAG flights, estimate available capacity based on aircraft type
                capacity_map = {
                    "A320": 158,
                    "B737": 158,
                    "B777": 366,
                    "B787": 242,
                    "A330": 242
                }
                estimated_capacity = capacity_map.get(aircraft_type, 158)
                
                cand = {
                    "flight_number": flight_number,
                    "origin": row[1],
                    "destination": row[2],
                    "departure_time": row[3],
                    "arrival_time": row[4],
                    "aircraft_type": aircraft_type,
                    "cost": float(row[6] or 0),
                    "distance": float(row[7] or 0),
                    "is_oag": True,
                    "is_direct": True,
                    "airline": "Partner Airline",
                    "priority": 3  # Lower priority than same-airline direct
                }
                
                score = _score_candidate(cand, original)
                scored_candidates.append((cand, score))
                
                # Check if OAG flight can accommodate entire group
                if passenger_count <= estimated_capacity:
                    log("resource_find_alternative", f"[P3] ✓ Partner flight {flight_number} can accommodate {passenger_count} passengers (capacity: {estimated_capacity})")
                    if score > best_score:
                        best, best_score = cand, score
                else:
                    cand["available_seats"] = estimated_capacity
                    log("resource_find_alternative", f"[P3] ○ Partner flight {flight_number} has partial capacity: {estimated_capacity}/{passenger_count} seats")
            
            if best:
                log("resource_find_alternative", f"[P3] ✓✓✓ Found direct flight on partner airline: {best['flight_number']}")
        
        # -------------------------------------------------------------------------
        # PRIORITY 4: CONNECTING FLIGHTS - PARTNER AIRLINES
        # -------------------------------------------------------------------------
        if not best:
            log("resource_find_alternative", "[P4] Connecting flights on partner airlines - Not implemented (requires multi-leg support)")
        
        log("resource_find_alternative", f"=== HIERARCHICAL SEARCH COMPLETE: Found {len(scored_candidates)} total candidates ===")
        
        if best:
            log("resource_find_alternative", f"*** BEST OPTION: {best['flight_number']} (Priority {best.get('priority', 'N/A')}, Airline: {best.get('airline', 'Unknown')}, Score: {best_score:.2f}) ***")

    except Exception as e:
        conn.close()
        return {"error": f"Alternative search failed: {e}"}

    conn.close()

    if not scored_candidates:
        log("resource_find_alternative", f"No alternatives found for {passenger_count} passengers")
        return {
            "alternatives": [],
            "best_alternative": None,
            "disruption_type": disruption_type,
            "passenger_count": passenger_count
        }

    log("resource_find_alternative", f"Found {len(scored_candidates)} alternatives for {passenger_count} passengers")
    
    # ============================================================================
    # APPLY POLICY FILTERS - Use RAG-retrieved policy guidance
    # ============================================================================
    policy_compliance_report = None
    if policy_guidance:
        print(f"\n[POLICY] ═══════════════════════════════════════════════════════")
        print(f"[POLICY] APPLYING POLICY-BASED FILTERING")
        print(f"[POLICY] Policy guidance length: {len(policy_guidance)} characters")
        print(f"[POLICY] Candidates before filtering: {len(scored_candidates)}")
        log("resource_agent", "Applying policy-based filtering to candidates")
        
        # Extract just the flight dictionaries for filtering
        candidate_flights = [cand for cand, score in scored_candidates]
        
        # Apply policy filters
        filtered_flights, policy_compliance_report = _apply_policy_filters(
            candidate_flights, 
            original, 
            policy_guidance
        )
        
        print(f"[POLICY] Candidates after filtering: {len(filtered_flights)}")
        print(f"[POLICY] Filtered out: {len(candidate_flights) - len(filtered_flights)} flights")
        print(f"[POLICY] ═══════════════════════════════════════════════════════")
        log("resource_agent", f"Policy filtering: {len(filtered_flights)}/{len(candidate_flights)} candidates comply with policies")
        
        # Rebuild scored_candidates with only policy-compliant flights
        filtered_scored = []
        for cand, score in scored_candidates:
            if cand in filtered_flights:
                filtered_scored.append((cand, score))
        
        scored_candidates = filtered_scored
        
        if not scored_candidates:
            log("resource_agent", "WARNING: All candidates filtered out by policy constraints")
            return {
                "alternatives": [],
                "best_alternative": None,
                "disruption_type": disruption_type,
                "passenger_count": passenger_count,
                "policy_compliance": policy_compliance_report,
                "error": "No policy-compliant alternatives found"
            }
    else:
        log("resource_agent", "No policy guidance - using default constraints")
    
    # ============================================================================
    # Sort alternatives by score in DESCENDING order (highest score first)
    # ============================================================================
    scored_candidates.sort(key=lambda x: x[1], reverse=True)
    
    # Filter out flights with 0 available seats from alternatives list
    # Keep only flights that have capacity for at least 1 passenger
    viable_alternatives = []
    for cand, score in scored_candidates:
        flight_num = cand['flight_number']
        available_seats = _get_available_seats(flight_num, exclude_pnr=pnr)
        
        if available_seats > 0:
            viable_alternatives.append((cand, score))
        else:
            log("resource_find_alternative", f"Excluding {flight_num} from alternatives list - 0 seats available")
    
    log("resource_find_alternative", f"After filtering: {len(viable_alternatives)} viable alternatives with available capacity")
    
    # Check if we have a dual-option scenario:
    # 1. At least one flight can fit entire group (lower score)
    # 2. Higher-scored flights exist that require splitting
    group_option = None  # Single flight for all passengers
    group_option_score = -1.0
    
    if best:
        group_option = best
        group_option_score = best_score
        log("resource_find_alternative", f"Group option available: {best['flight_number']} (score: {best_score:.2f})")
    
    # Always evaluate split booking potential to compare with group option
    # Collect flights with available seats - REFRESH capacity to get current data
    # Exclude current PNR from capacity calculation (in case of re-booking)
    partial_flights = []
    for cand, score in scored_candidates:
        flight_num = cand['flight_number']
        
        # Always get fresh capacity data, excluding current PNR from count
        available_seats = _get_available_seats(flight_num, exclude_pnr=pnr)
        
        if available_seats > 0:
            partial_flights.append({
                **cand,
                'available_seats': available_seats,
                'score': score
            })
    
    if partial_flights:
        log("resource_find_alternative", f"Found {len(partial_flights)} flights with available seats for potential split booking")
    
    # Evaluate split booking option if we have partial flights
    split_option = None
    split_option_data = None
    
    if partial_flights:
        # Get passenger details with age_group
        passengers = pnr_details.get("passengers", [])
        
        if passengers:
            split_plan = _create_split_booking_plan(passengers, partial_flights)
            
            if split_plan["is_valid"]:
                log("resource_find_alternative", f"Valid split booking plan created across {len(split_plan['split_assignments'])} flights")
                
                flights_with_passengers = {flight_num for flight_num, pax_list in split_plan['split_assignments'].items() if pax_list}
                
                if len(flights_with_passengers) == 1:
                    log("resource_find_alternative", "Split plan uses only ONE flight - same as group option, skipping split")
                    split_option_data = None
                else:
                    split_flights_used = []
                    split_total_score = 0.0
                    for flight_num in split_plan['split_assignments'].keys():
                        flight_data = next((f for f in partial_flights if f['flight_number'] == flight_num), None)
                        if flight_data and split_plan['split_assignments'][flight_num]:
                            split_flights_used.append(flight_data)
                            split_total_score += flight_data['score']
                    
                    split_avg_score = split_total_score / len(split_flights_used) if split_flights_used else 0.0
                    
                    split_option_data = {
                        "split_assignments": split_plan["split_assignments"],
                        "split_flights": split_flights_used,
                        "children_count": split_plan["children_count"],
                        "adults_count": split_plan["adults_count"],
                        "average_score": split_avg_score
                    }
                    
                    log("resource_find_alternative", f"Split option average score: {split_avg_score:.2f}")
            else:
                log("resource_find_alternative", f"Could not create valid split plan - {len(split_plan['unassigned_passengers'])} unassigned")
    
    # Determine what to return based on available options
    if group_option and split_option_data:
        split_avg_score = split_option_data['average_score']
        score_difference = split_avg_score - group_option_score
        percentage_diff = (score_difference / group_option_score * 100) if group_option_score > 0 else 0
        
        if score_difference > 5.0:
            log("resource_find_alternative", f" Dual-option scenario: Group (score {group_option_score:.2f}) vs Split (avg score {split_avg_score:.2f}, +{percentage_diff:.2f}% better)")
            
            result = {
                "alternatives": [{"flight": c, "score": s} for c, s in viable_alternatives],
                "best_alternative": None,
                "dual_option": True,
                "group_option": {
                    "flight": group_option,
                    "score": group_option_score
                },
                "split_option": split_option_data,
                "score_difference": score_difference,
                "disruption_type": disruption_type,
                "passenger_count": passenger_count,
                "policy_compliance": policy_compliance_report
            }
            return result
        else:
            # Split not significantly better - just offer group option
            if score_difference < 0:
                log("resource_find_alternative", f"Split option is WORSE ({percentage_diff:.2f}% lower), offering group option only")
            else:
                log("resource_find_alternative", f"Split option not significantly better (+{percentage_diff:.2f}%), offering group option only")
            result = {
                "alternatives": [{"flight": c, "score": s} for c, s in viable_alternatives],
                "best_alternative": group_option,
                "disruption_type": disruption_type,
                "passenger_count": passenger_count,
                "policy_compliance": policy_compliance_report
            }
            return result
    
    # CASE 2: Only split option available (no single flight has capacity)
    elif not group_option and split_option_data:
        log("resource_find_alternative", "Only split booking available - no single flight has full capacity")
        
        result = {
            "alternatives": [{"flight": c, "score": s} for c, s in viable_alternatives],
            "best_alternative": None,
            "split_booking": True,
            "split_assignments": split_option_data["split_assignments"],
            "split_flights": split_option_data["split_flights"],
            "children_count": split_option_data["children_count"],
            "adults_count": split_option_data["adults_count"],
            "disruption_type": disruption_type,
            "passenger_count": passenger_count,
            "policy_compliance": policy_compliance_report
        }
        return result
    
    # CASE 3: Only group option available (normal scenario)
    else:
        log("resource_find_alternative", "Standard rebooking - single flight available")
        result = {
            "alternatives": [{"flight": c, "score": s} for c, s in viable_alternatives],
            "best_alternative": group_option if group_option else best,
            "disruption_type": disruption_type,
            "passenger_count": passenger_count,
            "policy_compliance": policy_compliance_report
        }
        return result



def _apply_split_booking(pnr: str, split_assignments: dict) -> dict:
    """
    Apply split booking where passengers are distributed across multiple flights.
    
    Args:
        pnr: PNR string
        split_assignments: Dict mapping flight_number to list of passenger_ids
        
    Returns:
        Dict with booking results for each flight
    """
    conn = _conn()
    cur = conn.cursor()
    
    try:
        # Get PNR details
        pnr_details = get_pnr_details(pnr)
        if not pnr_details:
            conn.close()
            return {"error": f"PNR {pnr} not found"}
        
        passengers = pnr_details["passengers"]
        old_flight = pnr_details["flight_number"]
        
        # Create passenger lookup by ID
        passenger_map = {p["passenger_id"]: p for p in passengers}
        
        # Track results for each flight
        flight_bookings = {}
        all_seat_assignments = []
        
        # Process each flight assignment
        for flight_number, passenger_ids in split_assignments.items():
            log("_apply_split_booking", f"Processing {len(passenger_ids)} passengers for {flight_number}")
            
            # Get flight info (need to fetch from alternatives)
            cur.execute("""
                SELECT flight_number, origin, destination, departure_time, arrival_time,
                       aircraft_type, cost, distance
                FROM flights
                WHERE flight_number = ?
            """, (flight_number,))
            
            flight_row = cur.fetchone()
            if not flight_row:
                # Try OAG flights
                cur.execute("""
                    SELECT flight_number, origin, destination, departure_time, arrival_time,
                           aircraft_type, cost, distance
                    FROM oag_flights
                    WHERE flight_number = ?
                """, (flight_number,))
                flight_row = cur.fetchone()
                
            if not flight_row:
                conn.rollback()
                conn.close()
                return {"error": f"Flight {flight_number} not found"}
            
            flight_info = {
                "flight_number": flight_row[0],
                "origin": flight_row[1],
                "destination": flight_row[2],
                "departure_time": flight_row[3],
                "arrival_time": flight_row[4],
                "aircraft_type": flight_row[5],
                "cost": float(flight_row[6] or 0),
                "distance": float(flight_row[7] or 0)
            }
            
            # Ensure flight record exists (for OAG flights)
            _ensure_flight_record(cur, flight_info)
            conn.commit()  #  Commit so capacity check can see the flight
            
            # Verify capacity for this flight segment
            required_seats = len(passenger_ids)
            
            # Get current capacity info for debugging (excluding original PNR)
            cur.execute("""
                SELECT a.capacity
                FROM aircraft a
                JOIN flights f ON f.aircraft_id = a.aircraft_id
                WHERE f.flight_number = ?
            """, (flight_number,))
            capacity_row = cur.fetchone()
            total_capacity = int(capacity_row[0]) if capacity_row else 0
            
            # Count bookings EXCLUDING the original PNR being rebooked
            cur.execute("""
                SELECT COALESCE(SUM(pr.passenger_count), 0)
                FROM pnrs pr
                WHERE pr.flight_number = ? AND pr.pnr != ?
            """, (flight_number, pnr))
            currently_booked = cur.fetchone()[0]
            available_now = total_capacity - currently_booked
            
            log("_apply_split_booking", f"Flight {flight_number}: Capacity={total_capacity}, Booked={currently_booked} (excl. PNR {pnr}), Available={available_now}, Required={required_seats}")
            
            if available_now < required_seats:
                conn.rollback()
                conn.close()
                log("_apply_split_booking", f"ERROR: Insufficient capacity on {flight_number} for {required_seats} passengers (available: {available_now})")
                return {"error": f"Insufficient capacity for {required_seats} passengers on {flight_number} (available: {available_now}/{total_capacity})"}
            
            log("_apply_split_booking", f" Verified capacity for {required_seats} passengers on {flight_number}")
            
            # Assign seats for passengers on this flight
            flight_seat_assignments = []
            for passenger_id in passenger_ids:
                passenger = passenger_map.get(passenger_id)
                if not passenger:
                    log("_apply_split_booking", f"Warning: passenger_id {passenger_id} not found")
                    continue
                
                seat = _assign_seat(
                    flight_info.get("aircraft_type", "Unknown"),
                    passenger["class_of_service"],
                    cur,
                    flight_number
                )
                
                flight_seat_assignments.append({
                    "passenger_id": passenger_id,
                    "name": passenger["name"],
                    "seat": seat,
                    "class_of_service": passenger["class_of_service"],
                    "flight_number": flight_number
                })
                
                all_seat_assignments.append(flight_seat_assignments[-1])
            
            flight_bookings[flight_number] = {
                "passenger_count": len(passenger_ids),
                "seat_assignments": flight_seat_assignments
            }
        
        # Update database: Create new PNRs for split groups
        # For split bookings, we need to create separate PNRs for each flight
        new_pnrs = {}
        for idx, (flight_number, passenger_ids) in enumerate(split_assignments.items()):
            # Generate new PNR (original PNR + suffix)
            new_pnr = f"{pnr}-{idx+1}"
            
            # Get lead passenger for this group
            lead_passenger = passenger_map[passenger_ids[0]]
            
            # Create new PNR record
            cur.execute("""
                INSERT INTO pnrs (pnr, flight_number, passenger_count, lead_passenger_name, booking_status)
                VALUES (?, ?, ?, ?, 'Confirmed')
            """, (new_pnr, flight_number, len(passenger_ids), lead_passenger["name"]))
            
            # Update passengers to new PNR and seats
            for passenger_id in passenger_ids:
                seat_info = next(s for s in all_seat_assignments if s["passenger_id"] == passenger_id)
                
                # Update passengers table
                cur.execute("""
                    UPDATE passengers 
                    SET pnr = ?, seat = ?
                    WHERE passenger_id = ?
                """, (new_pnr, seat_info["seat"], passenger_id))
                
                # Update seat_assignments table
                cur.execute("""
                    UPDATE seat_assignments 
                    SET seat_number = ?
                    WHERE passenger_id = ?
                """, (seat_info["seat"], passenger_id))
            
            new_pnrs[flight_number] = new_pnr
            log("_apply_split_booking", f"Created PNR {new_pnr} for {len(passenger_ids)} passengers on {flight_number}")
        
        # Mark original PNR as split
        cur.execute("""
            UPDATE pnrs 
            SET booking_status = 'Split'
            WHERE pnr = ?
        """, (pnr,))
        
        conn.commit()
        log("_apply_split_booking", f"Successfully split booking {pnr} across {len(split_assignments)} flights")
        
    except Exception as e:
        conn.rollback()
        conn.close()
        log("_apply_split_booking", f"Error: {e}")
        return {"error": f"Failed to apply split booking: {e}"}
    
    conn.close()
    
    return {
        "pnr": pnr,
        "original_pnr": pnr,
        "split_booking": True,
        "new_pnrs": new_pnrs,
        "old_flight": old_flight,
        "flight_bookings": flight_bookings,
        "total_passengers": sum(b["passenger_count"] for b in flight_bookings.values()),
        "all_seat_assignments": all_seat_assignments,
        "status": f"Split Booking Applied across {len(split_assignments)} flights"
    }


@tool
def booking_apply(pnr: str, new_flight: dict = None, split_assignments: dict = None) -> dict:
    """
    Apply booking for ALL passengers in a PNR (multi-passenger support).
    Assigns seats for entire group and updates flight for all passengers.
    
    Supports split bookings where passengers are distributed across multiple flights.
    
    Parameters:
    - pnr: PNR string OR JSON string containing parameters
    - new_flight: Flight dictionary (optional if pnr contains JSON or using split_assignments)
    - split_assignments: Dict mapping flight_number to list of passenger_ids for split bookings
    """
    # Debug logging
    log("booking_apply", f"Called with pnr type={type(pnr)}, value={pnr[:100] if isinstance(pnr, str) and len(pnr) > 100 else pnr}")
    log("booking_apply", f"new_flight type={type(new_flight)}, split_assignments type={type(split_assignments)}")
    
    # Strip markdown code fences if present
    if isinstance(pnr, str):
        pnr = pnr.strip()
        if pnr.startswith("```json"):
            pnr = pnr[7:]  # Remove ```json
        if pnr.startswith("```"):
            pnr = pnr[3:]  # Remove ```
        if pnr.endswith("```"):
            pnr = pnr[:-3]  # Remove trailing ```
        pnr = pnr.strip()
    
    # Handle case where entire dict is passed as JSON string (LangChain tool invocation issue)
    if isinstance(pnr, str) and pnr.startswith("{"):
        log("booking_apply", "Detected JSON string as pnr - parsing")
        try:
            parsed = json.loads(pnr)
            if "pnr" in parsed:
                pnr = parsed["pnr"]
                new_flight = parsed.get("new_flight", new_flight)
                split_assignments = parsed.get("split_assignments", split_assignments)
                log("booking_apply", f"Extracted pnr={pnr}, new_flight={new_flight.get('flight_number') if new_flight else None}, split={bool(split_assignments)}")
        except json.JSONDecodeError as e:
            log("booking_apply", f"Failed to parse JSON: {e}")
            return {"error": f"Invalid JSON parameters - {e}"}
    # Also handle case where dict is passed directly
    elif isinstance(pnr, dict):
        log("booking_apply", "Detected dict as pnr - extracting fields")
        if "pnr" in pnr:
            split_assignments = pnr.get("split_assignments", split_assignments)
            new_flight = pnr.get("new_flight", new_flight)
            pnr = pnr["pnr"]
        else:
            return {"error": "Invalid parameters - expected pnr (string) and new_flight (dict) or split_assignments (dict)"}
    
    # Validate we have either new_flight or split_assignments
    if not new_flight and not split_assignments:
        error_msg = f"Missing required parameter: either new_flight or split_assignments must be provided. Received: pnr={pnr}, new_flight={new_flight}, split_assignments={split_assignments}"
        log("booking_apply", f"ERROR: {error_msg}")
        return {"error": error_msg}
    
    # Validate new_flight structure if provided
    if new_flight and not isinstance(new_flight, dict):
        error_msg = f"Invalid new_flight parameter: must be a dict, got {type(new_flight)}. Value: {new_flight}"
        log("booking_apply", f"ERROR: {error_msg}")
        return {"error": error_msg}
    
    if new_flight and "flight_number" not in new_flight:
        error_msg = f"Invalid new_flight parameter: missing 'flight_number' key. Keys present: {list(new_flight.keys())}"
        log("booking_apply", f"ERROR: {error_msg}")
        return {"error": error_msg}
    
    # Handle split bookings
    if split_assignments:
        return _apply_split_booking(pnr, split_assignments)
    
    # Original single-flight booking logic continues below
    conn = _conn()
    cur = conn.cursor()

    # 1. Get PNR details with all passengers
    pnr_details = get_pnr_details(pnr)
    if not pnr_details:
        conn.close()
        return {"error": f"PNR {pnr} not found"}

    passenger_count = pnr_details["passenger_count"]
    passengers = pnr_details["passengers"]
    old_flight = pnr_details["flight_number"]

    # 2. Ensure flight record exists (for OAG flights) - MUST BE DONE BEFORE CAPACITY CHECK
    try:
        _ensure_flight_record(cur, new_flight)
        conn.commit()  # Commit the flight record so capacity check can see it
    except Exception as e:
        conn.close()
        return {"error": f"Failed to ensure flight record: {e}"}

    # 3. Check flight capacity for entire group (AFTER ensuring flight exists, EXCLUDE current PNR)
    log("booking_apply", f"Checking capacity for {passenger_count} passengers on {new_flight['flight_number']} (excluding PNR {pnr})")
    if not check_flight_capacity(new_flight["flight_number"], passenger_count, exclude_pnr=pnr):
        conn.close()
        log("booking_apply", f"Insufficient capacity: Cannot fit {passenger_count} passengers on {new_flight['flight_number']}")
        return {"error": f"Insufficient capacity for {passenger_count} passengers on {new_flight['flight_number']}"}
    
    log("booking_apply", f" Verified capacity for {passenger_count} passengers on {new_flight['flight_number']}")

    # 4. Assign seats for ALL passengers
    log("booking_apply", f"Assigning seats for {passenger_count} passengers...")
    seat_assignments = []
    for passenger in passengers:
        seat = _assign_seat(
            new_flight.get("aircraft_type", "Unknown"),
            passenger["class_of_service"], 
            cur,
            new_flight["flight_number"]
        )
        seat_assignments.append({
            "passenger_id": passenger["passenger_id"],
            "name": passenger["name"],
            "seat": seat,
            "class_of_service": passenger["class_of_service"]
        })
    
    log("booking_apply", f"Seats assigned successfully")

    # 5. Update PNR and all passengers
    try:
        log("booking_apply", f"Updating PNR flight to {new_flight['flight_number']}...")
        # Update PNR flight
        success = update_pnr_flight(pnr, new_flight["flight_number"])
        
        if not success:
            conn.rollback()
            conn.close()
            return {"error": "Failed to update PNR flight"}
        
        log("booking_apply", "Updating passenger seats...")
        
        # Update seats for all passengers (both passengers table and seat_assignments table)
        for assignment in seat_assignments:
            # Update passengers table
            cur.execute(
                "UPDATE passengers SET seat=? WHERE passenger_id=?",
                (assignment["seat"], assignment["passenger_id"])
            )
            
            # Update seat_assignments table with new seat number
            cur.execute(
                "UPDATE seat_assignments SET seat_number=? WHERE passenger_id=?",
                (assignment["seat"], assignment["passenger_id"])
            )
        
        log("booking_apply", "Committing transaction...")
        conn.commit()
        
        log("booking_apply", f"Booking completed for PNR {pnr}")
        
    except Exception as e:
        conn.rollback()
        conn.close()
        # Sanitize exception message to avoid encoding errors
        error_msg = str(e).encode('ascii', errors='replace').decode('ascii')
        return {"error": f"Failed to update bookings: {error_msg}"}

    conn.close()
    
    return {
        "pnr": pnr,
        "lead_passenger": pnr_details["lead_passenger_name"],
        "passenger_count": passenger_count,
        "old_flight": old_flight,
        "new_flight": new_flight["flight_number"],
        "seat_assignments": seat_assignments,
        "status": f"Booking Applied for {passenger_count} Passenger(s)",
    }


@tool
def cost_calculation(original_flight, alternative_flight = None) -> dict:
    """
    Calculate disruption cost between original and alternative flights.
    
    Parameters:
    - original_flight: Original flight dictionary OR JSON string containing both flights
    - alternative_flight: Alternative flight dictionary (optional if original_flight contains JSON)
    """
    # Debug logging
    log("cost_calculation", f"Called with original_flight type={type(original_flight)}, alternative_flight type={type(alternative_flight)}")
    
    # Handle case where entire dict is passed as JSON string (LangChain tool invocation issue)
    if isinstance(original_flight, str) and original_flight.strip().startswith("{"):
        log("cost_calculation", "Detected JSON string as original_flight - parsing")
        try:
            parsed = json.loads(original_flight)
            if "original_flight" in parsed and "alternative_flight" in parsed:
                alternative_flight = parsed["alternative_flight"]
                original_flight = parsed["original_flight"]
                log("cost_calculation", f"Extracted original_flight={original_flight.get('flight_number')}, alternative_flight={alternative_flight.get('flight_number')}")
        except json.JSONDecodeError as e:
            log("cost_calculation", f"Failed to parse JSON: {e}")
            return {"error": f"Invalid JSON parameters - {e}"}
    # Also handle case where dict is passed directly  
    elif isinstance(original_flight, dict) and "original_flight" in original_flight and "alternative_flight" in original_flight:
        log("cost_calculation", "Detected dict with nested flights - extracting fields")
        alternative_flight = original_flight["alternative_flight"]
        original_flight = original_flight["original_flight"]
    
    # Validate we have both parameters
    if not alternative_flight:
        return {"error": "Missing required parameter: alternative_flight"}
    
    try:
        # Get or calculate original flight cost
        if "cost" in original_flight and original_flight["cost"]:
            orig_cost = float(original_flight["cost"])
        else:
            # Ensure required fields exist for calculation
            if "distance" not in original_flight or not original_flight.get("distance"):
                log("cost_calculation", f"Warning: Missing distance for original flight, using default 1000 km")
                original_flight["distance"] = 1000
            if "aircraft_type" not in original_flight or not original_flight.get("aircraft_type"):
                log("cost_calculation", f"Warning: Missing aircraft_type for original flight, using default A320")
                original_flight["aircraft_type"] = "A320"
            orig_cost = calculate_flight_cost(original_flight)
        
        # Get or calculate alternative flight cost
        if "cost" in alternative_flight and alternative_flight["cost"]:
            alt_cost = float(alternative_flight["cost"])
        else:
            # Ensure required fields exist for calculation
            if "distance" not in alternative_flight or not alternative_flight.get("distance"):
                log("cost_calculation", f"Warning: Missing distance for alternative flight, using default 1000 km")
                alternative_flight["distance"] = 1000
            if "aircraft_type" not in alternative_flight or not alternative_flight.get("aircraft_type"):
                log("cost_calculation", f"Warning: Missing aircraft_type for alternative flight, using default A320")
                alternative_flight["aircraft_type"] = "A320"
            alt_cost = calculate_flight_cost(alternative_flight)
        
        diff = alt_cost - orig_cost
        disruption_penalty = round(abs(diff) * 0.1, 2)
        
        log("cost_calculation", f"Original cost: ${orig_cost:.2f}, Alternative cost: ${alt_cost:.2f}, Difference: ${diff:.2f}, Penalty: ${disruption_penalty:.2f}")
        
    except Exception as e:
        log("cost_calculation", f"Error: {e}")
        import traceback
        log("cost_calculation", f"Traceback: {traceback.format_exc()}")
        return {"error": f"Cost calculation failed: {e}"}

    return {
        "original_cost": round(orig_cost, 2),
        "alternative_cost": round(alt_cost, 2),
        "difference": round(diff, 2),
        "disruption_penalty": disruption_penalty,
        "total_disruption_cost": round(abs(diff) + disruption_penalty, 2),
    }


@tool
def calculate_cancellation_cost(pnr: Optional[str] = None, original_flight: Optional[dict] = None, disruption_type: str = "cancelled") -> dict:
    """
    Calculate refund eligibility and amount for cancelled bookings based on policy.
    
    Parameters:
    - pnr: PNR code (can be JSON string from LangChain)
    - original_flight: Original flight dictionary
    - disruption_type: Type of disruption ("cancelled", "delayed", etc.)
    
    Returns:
    - Dictionary with refund details, deductions, and policy information
    """
    # Handle markdown fence stripping and JSON string parsing (same as calculate_rebook_cost)
    if isinstance(pnr, str):
        pnr = pnr.strip()
        # Strip markdown code fences
        if pnr.startswith("```json"):
            pnr = pnr[7:]
        if pnr.startswith("```"):
            pnr = pnr[3:]
        if pnr.endswith("```"):
            pnr = pnr[:-3]
        pnr = pnr.strip()
        
        # Parse JSON string if present
        if pnr.startswith("{"):
            log("cancellation_cost", "Detected JSON string input - parsing")
            try:
                payload = json.loads(pnr)
                pnr = payload.get("pnr")
                original_flight = payload.get("original_flight", original_flight)
                disruption_type = payload.get("disruption_type", disruption_type)
                log("cancellation_cost", "Successfully extracted parameters from JSON")
            except json.JSONDecodeError as e:
                log("cancellation_cost", f"Failed to parse JSON: {e}")
                return {"error": f"Invalid JSON input: {e}"}
    
    if not pnr:
        return {"error": "PNR is required"}
    if not original_flight:
        return {"error": "Original flight information is required"}
    
    log("cancellation_cost", f"Calculating cancellation cost for PNR {pnr}")
    log("cancellation_cost", f"Received - original_flight: {type(original_flight)}")
    
    try:
        # Get PNR details
        pnr_details = get_pnr_details(pnr)
        if not pnr_details:
            return {"error": f"PNR {pnr} not found"}
        
        passenger_count = pnr_details["passenger_count"]
        
        # Calculate original flight cost
        if "cost" in original_flight and original_flight["cost"]:
            orig_cost = float(original_flight["cost"])
        else:
            orig_cost = calculate_flight_cost(original_flight)
        
        # Total booking cost for all passengers
        total_booking_cost = orig_cost * passenger_count
        
        # Query policy for cancellation rules
        policy_query = f"What is the refund policy for {disruption_type} flights? Include service fees, deductions, and refund timelines."
        policy_result = query_policy_knowledge_base(policy_query)
        policy_info = policy_result.get("policy_info", "")
        
        # Determine refund eligibility based on disruption type
        if disruption_type == "cancelled":
            # Airline-initiated cancellation - full refund typically
            refund_percentage = 100
            service_fee = 0
            refund_timeline = "7-10 business days"
            eligibility_reason = "Airline-initiated cancellation qualifies for full refund"
        elif disruption_type == "delayed":
            # Delayed flight - check delay duration
            refund_percentage = 100
            service_fee = 0
            refund_timeline = "7-10 business days"
            eligibility_reason = "Significant delay qualifies for full refund or rebooking"
        else:
            # Passenger-initiated - may have fees
            refund_percentage = 85
            service_fee = round(total_booking_cost * 0.15, 2)
            refund_timeline = "14-21 business days"
            eligibility_reason = "Passenger-initiated cancellation subject to service fees"
        
        # Calculate refund amount
        refund_amount = round((total_booking_cost * refund_percentage / 100) - service_fee, 2)
        
        # Query policy for compensation (EU261 or similar)
        compensation_query = f"What compensation is due for {disruption_type} flights? Include EU261 rules if applicable."
        compensation_result = query_policy_knowledge_base(compensation_query)
        compensation_info = compensation_result.get("policy_info", "")
        
        # Query for care obligations and benefits during cancellation
        care_query = f"What care obligations and benefits are provided for cancellation situations? Include meal vouchers, hotel, vouchers, and other benefits."
        care_result = query_policy_knowledge_base(care_query)
        care_info = care_result.get("policy_info", "")
        
        # Determine compensation based on distance and disruption
        distance = original_flight.get("distance", 0)
        if disruption_type in ["cancelled", "delayed"]:
            # EU261 cash compensation
            if distance < 1500:
                compensation_amount = 250 * passenger_count
            elif distance < 3500:
                compensation_amount = 400 * passenger_count
            else:
                compensation_amount = 600 * passenger_count
            
            # Care obligations during cancellation process (Section 1.4 of policy)
            meal_vouchers = 25 * passenger_count  # Initial meal voucher
            refreshments = 15 * passenger_count
            lounge_access = 50 * passenger_count
            
            # Hotel if needed (assume same-day resolution for most cancellations)
            hotel_cost = 0
            transport_cost = 0
            
            # Vouchers and benefits (Section 5 of policy)
            retail_vouchers = 20 * passenger_count
            travel_voucher = int(refund_amount * 0.25)  # 125% of refund if passenger accepts voucher instead
            mileage_bonus = 50 * passenger_count  # Bonus miles value
            goodwill_voucher = 200 * passenger_count  # Goodwill compensation for cancellation inconvenience
            
            care_obligations_total = meal_vouchers + refreshments + lounge_access + hotel_cost + transport_cost
            vouchers_benefits_total = retail_vouchers + travel_voucher + mileage_bonus + goodwill_voucher
            total_benefits_value = care_obligations_total + vouchers_benefits_total
        else:
            # Passenger-initiated - no additional benefits
            compensation_amount = 0
            meal_vouchers = 0
            refreshments = 0
            lounge_access = 0
            hotel_cost = 0
            transport_cost = 0
            retail_vouchers = 0
            travel_voucher = 0
            mileage_bonus = 0
            goodwill_voucher = 0
            care_obligations_total = 0
            vouchers_benefits_total = 0
            total_benefits_value = 0
        
        log("cancellation_cost", f"Refund: ${refund_amount}, EU261 Compensation: ${compensation_amount}")
        log("cancellation_cost", f"Care Obligations: ${care_obligations_total}, Vouchers/Benefits: ${vouchers_benefits_total}")
        
        return {
            "action": "cancel",
            "pnr": pnr,
            "passenger_count": passenger_count,
            "original_cost_per_passenger": round(orig_cost, 2),
            "total_booking_cost": round(total_booking_cost, 2),
            "refund_details": {
                "refund_percentage": refund_percentage,
                "service_fee": round(service_fee, 2),
                "refund_amount": refund_amount,
                "refund_timeline": refund_timeline,
                "eligibility_reason": eligibility_reason
            },
            "eu261_compensation": {
                "eligible": compensation_amount > 0,
                "amount_per_passenger": round(compensation_amount / passenger_count, 2) if passenger_count > 0 and compensation_amount > 0 else 0,
                "total_compensation": round(compensation_amount, 2),
                "distance_km": distance,
                "description": "EU261 or similar regulation cash compensation"
            },
            "care_obligations": {
                "meal_vouchers": {
                    "provided": meal_vouchers > 0,
                    "value_per_passenger": round(meal_vouchers / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(meal_vouchers, 2),
                    "description": "Meal vouchers during cancellation processing"
                },
                "refreshments": {
                    "provided": refreshments > 0,
                    "value_per_passenger": round(refreshments / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(refreshments, 2),
                    "description": "Complimentary refreshments and snacks"
                },
                "lounge_access": {
                    "provided": lounge_access > 0,
                    "value_per_passenger": round(lounge_access / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(lounge_access, 2),
                    "description": "Airport lounge access during cancellation wait"
                },
                "total_care_value": round(care_obligations_total, 2)
            },
            "vouchers_and_benefits": {
                "retail_vouchers": {
                    "provided": retail_vouchers > 0,
                    "value_per_passenger": round(retail_vouchers / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(retail_vouchers, 2),
                    "description": "Shopping vouchers for airport stores"
                },
                "travel_voucher_option": {
                    "provided": travel_voucher > 0,
                    "value_per_passenger": round(travel_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(travel_voucher, 2),
                    "description": "Optional: Accept 125% travel voucher instead of cash refund"
                },
                "mileage_bonus": {
                    "provided": mileage_bonus > 0,
                    "value_per_passenger": round(mileage_bonus / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(mileage_bonus, 2),
                    "description": "Frequent flyer bonus miles (approx. 5,000 per passenger)"
                },
                "goodwill_voucher": {
                    "provided": goodwill_voucher > 0,
                    "value_per_passenger": round(goodwill_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(goodwill_voucher, 2),
                    "description": "Goodwill compensation for cancellation inconvenience"
                },
                "total_vouchers_value": round(vouchers_benefits_total, 2)
            },
            "total_package": {
                "refund_amount": round(refund_amount, 2),
                "eu261_compensation": round(compensation_amount, 2),
                "care_obligations": round(care_obligations_total, 2),
                "vouchers_and_benefits": round(vouchers_benefits_total, 2),
                "total_passenger_receives": round(refund_amount + compensation_amount + total_benefits_value, 2),
                "description": "Total value of refund, compensation, care obligations, and benefits"
            },
            "policy_reference": policy_info[:200] + "..." if len(policy_info) > 200 else policy_info,
            "compensation_reference": compensation_info[:200] + "..." if len(compensation_info) > 200 else compensation_info,
            "care_obligations_reference": care_info[:300] + "..." if len(care_info) > 300 else care_info
        }
        
    except Exception as e:
        log("cancellation_cost", f"Error: {e}")
        import traceback
        log("cancellation_cost", f"Traceback: {traceback.format_exc()}")
        return {"error": f"Cancellation cost calculation failed: {e}"}


@tool
def calculate_wait_cost(pnr: Optional[str] = None, original_flight: Optional[dict] = None, disruption_type: str = "delayed") -> dict:
    """
    Calculate entitlements and costs for passengers choosing to wait.
    
    Parameters:
    - pnr: PNR code (can be JSON string from LangChain)
    - original_flight: Original flight dictionary
    - disruption_type: Type of disruption ("cancelled", "delayed", etc.)
    
    Returns:
    - Dictionary with wait entitlements, accommodations, and policy information
    """
    # Handle markdown fence stripping and JSON string parsing (same as calculate_rebook_cost)
    if isinstance(pnr, str):
        pnr = pnr.strip()
        # Strip markdown code fences
        if pnr.startswith("```json"):
            pnr = pnr[7:]
        if pnr.startswith("```"):
            pnr = pnr[3:]
        if pnr.endswith("```"):
            pnr = pnr[:-3]
        pnr = pnr.strip()
        
        # Parse JSON string if present
        if pnr.startswith("{"):
            log("wait_cost", "Detected JSON string input - parsing")
            try:
                payload = json.loads(pnr)
                pnr = payload.get("pnr")
                original_flight = payload.get("original_flight", original_flight)
                disruption_type = payload.get("disruption_type", disruption_type)
                log("wait_cost", "Successfully extracted parameters from JSON")
            except json.JSONDecodeError as e:
                log("wait_cost", f"Failed to parse JSON: {e}")
                return {"error": f"Invalid JSON input: {e}"}
    
    if not pnr:
        return {"error": "PNR is required"}
    if not original_flight:
        return {"error": "Original flight information is required"}
    
    log("wait_cost", f"Calculating wait entitlements for PNR {pnr}")
    log("wait_cost", f"Received - original_flight: {type(original_flight)}")
    
    try:
        # Get PNR details
        pnr_details = get_pnr_details(pnr)
        if not pnr_details:
            return {"error": f"PNR {pnr} not found"}
        
        passenger_count = pnr_details["passenger_count"]
        
        # Query policy for wait/delay entitlements (including care obligations)
        policy_query = f"""What care obligations, entitlements, and benefits are provided for passengers affected by {disruption_type} flights? 
        Include: meal vouchers, refreshments, snacks, hotel accommodation, ground transportation, communication services, 
        lounge access, retail vouchers, goodwill compensation, and any other benefits."""
        policy_result = query_policy_knowledge_base(policy_query)
        policy_info = policy_result.get("policy_info", "")
        
        # Additional query for specific benefit amounts
        benefits_query = f"What are the specific monetary values and amounts for care obligations during {disruption_type} situations? Include meal voucher amounts, hotel costs, transportation allowances."
        benefits_result = query_policy_knowledge_base(benefits_query)
        benefits_info = benefits_result.get("policy_info", "")
        
        # Determine entitlements based on disruption type and duration
        # These values align with Enhanced_Care_Obligations_Policy.txt
        if disruption_type == "cancelled":
            # Cancelled flight - generous entitlements (Section 1.4 and 2.1 of policy)
            meal_voucher_value = 25 * passenger_count  # Initial meal voucher
            additional_meal_vouchers = 25 * passenger_count  # Every 4 hours
            refreshments_value = 15 * passenger_count  # Snacks, drinks, coffee
            
            hotel_accommodation = True
            hotel_value = 150 * passenger_count  # $150 per passenger for hotel
            
            transportation_provided = True
            transportation_value = 50 * passenger_count  # Airport to hotel transport
            
            communication_services = 10 * passenger_count  # Phone, wifi
            lounge_access_value = 50 * passenger_count  # Airport lounge
            retail_vouchers = 20 * passenger_count  # Shopping vouchers
            
            wait_message = "No additional cost for waiting. Airline provides full care obligations per policy."
            
        elif disruption_type == "delayed":
            # Delayed flight - depends on delay duration (Sections 1.1, 1.2, 1.3)
            # Assume medium to extended delay (3-5+ hours)
            meal_voucher_value = 40 * passenger_count  # Extended delay meal voucher
            additional_meal_vouchers = 25 * passenger_count  # Additional meals if needed
            refreshments_value = 10 * passenger_count  # Snacks and drinks
            
            hotel_accommodation = True  # Assume delay requires overnight
            hotel_value = 150 * passenger_count
            
            transportation_provided = True
            transportation_value = 50 * passenger_count
            
            communication_services = 10 * passenger_count
            lounge_access_value = 50 * passenger_count
            retail_vouchers = 50 * passenger_count  # Medium delay retail vouchers
            
            wait_message = "No additional cost for waiting. Airline provides care obligations during delay per policy."
            
        else:
            # Unknown disruption - minimal entitlements (Section 1.1)
            meal_voucher_value = 15 * passenger_count  # Short delay voucher
            additional_meal_vouchers = 0
            refreshments_value = 5 * passenger_count
            
            hotel_accommodation = False
            hotel_value = 0
            
            transportation_provided = False
            transportation_value = 0
            
            communication_services = 5 * passenger_count
            lounge_access_value = 0
            retail_vouchers = 0
            
            wait_message = "No additional cost for waiting. Limited care obligations may apply per policy."
        
        # Calculate vouchers and compensatory benefits (Section 5 of policy)
        upgrade_voucher_value = 100 * passenger_count  # Future upgrade voucher
        mileage_bonus_value = 50 * passenger_count  # Equivalent value of bonus miles (5,000 miles @ $0.01/mile)
        goodwill_voucher = 50 * passenger_count  # Goodwill compensation voucher
        
        # Total entitlement value
        total_care_obligations = (
            meal_voucher_value + 
            additional_meal_vouchers + 
            refreshments_value + 
            hotel_value + 
            transportation_value + 
            communication_services + 
            lounge_access_value
        )
        
        total_vouchers_and_benefits = (
            retail_vouchers +
            upgrade_voucher_value +
            mileage_bonus_value +
            goodwill_voucher
        )
        
        total_entitlement_value = total_care_obligations + total_vouchers_and_benefits
        
        # Query policy for compensation during wait
        compensation_query = f"What compensation is due while passengers wait for {disruption_type} flight resolution?"
        compensation_result = query_policy_knowledge_base(compensation_query)
        compensation_info = compensation_result.get("policy_info", "")
        
        log("wait_cost", f"Total Care Obligations: ${total_care_obligations:.2f}")
        log("wait_cost", f"Total Vouchers & Benefits: ${total_vouchers_and_benefits:.2f}")
        log("wait_cost", f"Grand Total Entitlements: ${total_entitlement_value:.2f}")
        
        return {
            "action": "wait",
            "pnr": pnr,
            "passenger_count": passenger_count,
            "additional_cost_to_passenger": 0,
            "cost_message": wait_message,
            "care_obligations": {
                "meal_vouchers": {
                    "provided": meal_voucher_value > 0,
                    "initial_value_per_passenger": round(meal_voucher_value / passenger_count, 2) if passenger_count > 0 else 0,
                    "initial_total_value": round(meal_voucher_value, 2),
                    "additional_per_4hours": round(additional_meal_vouchers / passenger_count, 2) if passenger_count > 0 else 0,
                    "description": "Meal vouchers for airport restaurants and cafes"
                },
                "refreshments_and_snacks": {
                    "provided": refreshments_value > 0,
                    "value_per_passenger": round(refreshments_value / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(refreshments_value, 2),
                    "description": "Coffee, tea, soft drinks, water, sandwiches, pastries, snacks"
                },
                "hotel_accommodation": {
                    "provided": hotel_accommodation,
                    "value_per_passenger": round(hotel_value / passenger_count, 2) if passenger_count > 0 and hotel_accommodation else 0,
                    "total_value": round(hotel_value, 2),
                    "description": "Overnight hotel accommodation with breakfast, minibar allowance"
                },
                "transportation": {
                    "provided": transportation_provided,
                    "value_per_passenger": round(transportation_value / passenger_count, 2) if passenger_count > 0 and transportation_provided else 0,
                    "total_value": round(transportation_value, 2),
                    "description": "Ground transportation between airport and hotel"
                },
                "communication_services": {
                    "provided": communication_services > 0,
                    "value_per_passenger": round(communication_services / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(communication_services, 2),
                    "description": "Phone calls, Wi-Fi access, mobile data allowance"
                },
                "lounge_access": {
                    "provided": lounge_access_value > 0,
                    "value_per_passenger": round(lounge_access_value / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(lounge_access_value, 2),
                    "description": "Airport lounge access with food, beverages, comfortable seating"
                }
            },
            "vouchers_and_benefits": {
                "retail_vouchers": {
                    "provided": retail_vouchers > 0,
                    "value_per_passenger": round(retail_vouchers / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(retail_vouchers, 2),
                    "description": "Vouchers for airport shops, duty-free, bookstores"
                },
                "upgrade_vouchers": {
                    "provided": upgrade_voucher_value > 0,
                    "value_per_passenger": round(upgrade_voucher_value / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(upgrade_voucher_value, 2),
                    "description": "Future flight upgrade vouchers (valid 12 months)"
                },
                "mileage_bonus": {
                    "provided": mileage_bonus_value > 0,
                    "value_per_passenger": round(mileage_bonus_value / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(mileage_bonus_value, 2),
                    "description": "Frequent flyer bonus miles (approximately 5,000 miles per passenger)"
                },
                "goodwill_compensation": {
                    "provided": goodwill_voucher > 0,
                    "value_per_passenger": round(goodwill_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(goodwill_voucher, 2),
                    "description": "Goodwill gesture travel voucher for future bookings"
                }
            },
            "cost_summary": {
                "total_care_obligations": round(total_care_obligations, 2),
                "total_vouchers_and_benefits": round(total_vouchers_and_benefits, 2),
                "total_entitlement_value": round(total_entitlement_value, 2),
                "passenger_pays": 0,
                "airline_cost": round(total_entitlement_value, 2)
            },
            "next_steps": "Passenger will be notified when new flight options become available. All entitlements and vouchers will be provided during wait period.",
            "policy_reference": policy_info[:300] + "..." if len(policy_info) > 300 else policy_info,
            "benefits_reference": benefits_info[:300] + "..." if len(benefits_info) > 300 else benefits_info,
            "compensation_reference": compensation_info[:200] + "..." if len(compensation_info) > 200 else compensation_info
        }
        
    except Exception as e:
        log("wait_cost", f"Error: {e}")
        import traceback
        log("wait_cost", f"Traceback: {traceback.format_exc()}")
        return {"error": f"Wait cost calculation failed: {e}"}


@tool
def calculate_rebook_cost(pnr: str, original_flight: Optional[dict] = None, alternative_flight: Optional[dict] = None, disruption_type: str = "cancelled") -> dict:
    """
    Calculate comprehensive rebooking costs including fare differences, upgrades, and policy compliance.
    
    Parameters:
    - pnr: PNR code
    - original_flight: Optional - Original flight dictionary (auto-filled from context if not provided)
    - alternative_flight: Optional - Alternative flight dictionary (auto-filled from context if not provided)
    - disruption_type: Type of disruption ("cancelled", "delayed", etc.)
    
    Returns:
    - Dictionary with detailed cost breakdown, policy compliance, and fare adjustments
    
    Note: You can call this with just the pnr parameter. The system will automatically inject 
    original_flight and alternative_flight from the current context.
    """
    # Handle case where LangChain passes entire payload as first parameter
    log("rebook_cost", f"Input type: pnr={type(pnr)}, value preview: {str(pnr)[:100]}")
    
    # Strip markdown code fences if present
    if isinstance(pnr, str):
        pnr = pnr.strip()
        if pnr.startswith("```json"):
            pnr = pnr[7:]  # Remove ```json
        if pnr.startswith("```"):
            pnr = pnr[3:]  # Remove ```
        if pnr.endswith("```"):
            pnr = pnr[:-3]  # Remove trailing ```
        pnr = pnr.strip()
    
    # If pnr is a JSON string, parse it
    if isinstance(pnr, str) and pnr.startswith("{"):
        try:
            log("rebook_cost", "Detected JSON string input - parsing")
            payload = json.loads(pnr)
            if "pnr" in payload:
                pnr = payload.get("pnr")
                original_flight = payload.get("original_flight", original_flight)
                alternative_flight = payload.get("alternative_flight", alternative_flight)
                disruption_type = payload.get("disruption_type", disruption_type)
                log("rebook_cost", "Successfully extracted parameters from JSON")
        except json.JSONDecodeError as e:
            log("rebook_cost", f"Failed to parse JSON: {e}")
    # If pnr is already a dict
    elif isinstance(pnr, dict) and "pnr" in pnr:
        log("rebook_cost", "Detected dict input - extracting parameters")
        payload = pnr
        pnr = payload.get("pnr")
        original_flight = payload.get("original_flight", original_flight)
        alternative_flight = payload.get("alternative_flight", alternative_flight)
        disruption_type = payload.get("disruption_type", disruption_type)
    
    log("rebook_cost", f"Calculating rebook cost for PNR {pnr}")
    log("rebook_cost", f"Received - original_flight: {type(original_flight)}, alternative_flight: {type(alternative_flight)}")
    
    # Validation - these should have been augmented by AugmentedTool wrapper
    if not original_flight:
        return {"error": "original_flight parameter is required but was not provided. This should have been auto-injected."}
    if not alternative_flight:
        return {"error": "alternative_flight parameter is required but was not provided. This should have been auto-injected."}
    
    try:
        # Get PNR details
        pnr_details = get_pnr_details(pnr)
        if not pnr_details:
            return {"error": f"PNR {pnr} not found"}
        
        passenger_count = pnr_details["passenger_count"]
        
        # Calculate flight costs
        if "cost" in original_flight and original_flight["cost"]:
            orig_cost = float(original_flight["cost"])
        else:
            orig_cost = calculate_flight_cost(original_flight)
        
        if "cost" in alternative_flight and alternative_flight["cost"]:
            alt_cost = float(alternative_flight["cost"])
        else:
            alt_cost = calculate_flight_cost(alternative_flight)
        
        # Calculate per-passenger and total costs
        orig_cost_per_pax = orig_cost
        alt_cost_per_pax = alt_cost
        total_orig_cost = orig_cost * passenger_count
        total_alt_cost = alt_cost * passenger_count
        
        # Calculate fare difference
        fare_diff_per_pax = alt_cost - orig_cost
        total_fare_diff = fare_diff_per_pax * passenger_count
        
        # Query policy for rebooking rules
        policy_query = f"What is the rebooking policy for {disruption_type} flights? Include information about fare differences, free rebooking, and upgrade/downgrade rules."
        policy_result = query_policy_knowledge_base(policy_query)
        policy_info = policy_result.get("policy_info", "")
        
        # Query for care obligations during rebooking wait
        care_query = f"""What care obligations and benefits are provided to passengers during rebooking for {disruption_type} flights?
        Include meal vouchers, refreshments, lounge access, hotel if applicable, and any compensatory vouchers."""
        care_result = query_policy_knowledge_base(care_query)
        care_info = care_result.get("policy_info", "")
        
        # Determine if rebooking is free based on disruption type
        if disruption_type in ["cancelled", "delayed"]:
            is_free_rebook = True
            passenger_pays_diff = fare_diff_per_pax > 0  # Only if upgrade
            rebooking_fee = 0
            policy_compliance = "Airline-initiated disruption: Free rebooking per policy"
        else:
            is_free_rebook = False
            passenger_pays_diff = True
            rebooking_fee = 50 * passenger_count
            policy_compliance = "Passenger-initiated change: Rebooking fee applies"
        
        # Determine upgrade/downgrade scenario
        if fare_diff_per_pax > 50:
            fare_class_change = "upgrade"
            fare_class_message = f"Alternative flight is an upgrade (+${abs(fare_diff_per_pax):.2f} per passenger)"
        elif fare_diff_per_pax < -50:
            fare_class_change = "downgrade"
            fare_class_message = f"Alternative flight is a downgrade (${abs(fare_diff_per_pax):.2f} refund per passenger)"
        else:
            fare_class_change = "similar"
            fare_class_message = "Alternative flight has similar fare class"
        
        # Calculate what passenger pays
        if is_free_rebook:
            if passenger_pays_diff and fare_diff_per_pax > 0:
                # Airline-initiated but upgrade - passenger may need to pay difference
                passenger_charge = total_fare_diff
                charge_reason = "Upgrade fare difference (optional - passenger choice)"
            else:
                # Free rebooking, no charge
                passenger_charge = 0
                charge_reason = "Free rebooking per airline policy"
        else:
            # Passenger-initiated - pay fee and any fare difference
            passenger_charge = rebooking_fee + (total_fare_diff if total_fare_diff > 0 else 0)
            charge_reason = "Rebooking fee + fare difference (passenger-initiated change)"
        
        # Calculate disruption penalty (airline operational cost)
        disruption_penalty = round(abs(total_fare_diff) * 0.1, 2)
        
        # Total disruption cost (to airline)
        total_disruption_cost = disruption_penalty + abs(total_fare_diff)
        
        # Calculate care obligations and benefits during rebooking wait
        # Values based on Enhanced_Care_Obligations_Policy.txt
        if disruption_type in ["cancelled", "delayed"]:
            # Airline-initiated disruption - provide care obligations
            meal_voucher = 25 * passenger_count  # Initial meal voucher during rebooking wait
            refreshments = 15 * passenger_count  # Snacks, coffee, soft drinks
            lounge_access = 50 * passenger_count  # Lounge access during wait
            
            # Benefits and compensatory items
            retail_voucher = 20 * passenger_count  # Shopping vouchers
            upgrade_voucher = 100 * passenger_count  # Complimentary upgrade on rebooked flight or future voucher
            mileage_bonus = 50 * passenger_count  # Bonus miles value (5,000 miles per passenger)
            goodwill_voucher = 100 * passenger_count  # Goodwill compensation for disruption
            
            # Hotel only if rebook is next day
            # Assume same-day rebook for now (hotel handled separately in wait scenarios)
            hotel_cost = 0
            transport_cost = 0
            
            care_obligations_total = meal_voucher + refreshments + lounge_access + hotel_cost + transport_cost
            vouchers_benefits_total = retail_voucher + upgrade_voucher + mileage_bonus + goodwill_voucher
            total_benefits_value = care_obligations_total + vouchers_benefits_total
            
        else:
            # Passenger-initiated - minimal or no care obligations
            meal_voucher = 0
            refreshments = 0
            lounge_access = 0
            retail_voucher = 0
            upgrade_voucher = 0
            mileage_bonus = 0
            goodwill_voucher = 0
            hotel_cost = 0
            transport_cost = 0
            
            care_obligations_total = 0
            vouchers_benefits_total = 0
            total_benefits_value = 0
        
        log("rebook_cost", f"Original: ${orig_cost_per_pax:.2f}/pax, Alternative: ${alt_cost_per_pax:.2f}/pax, Passenger charge: ${passenger_charge:.2f}")
        log("rebook_cost", f"Care Obligations: ${care_obligations_total:.2f}, Vouchers/Benefits: ${vouchers_benefits_total:.2f}")
        
        return {
            "action": "rebook",
            "pnr": pnr,
            "passenger_count": passenger_count,
            "original_flight": original_flight.get("flight_number", "N/A"),
            "alternative_flight": alternative_flight.get("flight_number", "N/A"),
            "cost_breakdown": {
                "original_cost_per_passenger": round(orig_cost_per_pax, 2),
                "alternative_cost_per_passenger": round(alt_cost_per_pax, 2),
                "total_original_cost": round(total_orig_cost, 2),
                "total_alternative_cost": round(total_alt_cost, 2),
                "fare_difference_per_passenger": round(fare_diff_per_pax, 2),
                "total_fare_difference": round(total_fare_diff, 2)
            },
            "fare_class_change": fare_class_change,
            "fare_class_message": fare_class_message,
            "rebooking_terms": {
                "is_free_rebook": is_free_rebook,
                "rebooking_fee": round(rebooking_fee, 2),
                "passenger_pays_difference": passenger_pays_diff,
                "passenger_total_charge": round(passenger_charge, 2),
                "charge_reason": charge_reason
            },
            "care_obligations": {
                "meal_vouchers": {
                    "provided": meal_voucher > 0,
                    "value_per_passenger": round(meal_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(meal_voucher, 2),
                    "description": "Meal vouchers during rebooking wait period"
                },
                "refreshments": {
                    "provided": refreshments > 0,
                    "value_per_passenger": round(refreshments / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(refreshments, 2),
                    "description": "Complimentary refreshments, snacks, beverages"
                },
                "lounge_access": {
                    "provided": lounge_access > 0,
                    "value_per_passenger": round(lounge_access / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(lounge_access, 2),
                    "description": "Airport lounge access during rebooking wait"
                },
                "total_care_value": round(care_obligations_total, 2)
            },
            "vouchers_and_benefits": {
                "retail_vouchers": {
                    "provided": retail_voucher > 0,
                    "value_per_passenger": round(retail_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(retail_voucher, 2),
                    "description": "Shopping vouchers for airport stores"
                },
                "upgrade_voucher": {
                    "provided": upgrade_voucher > 0,
                    "value_per_passenger": round(upgrade_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(upgrade_voucher, 2),
                    "description": "Complimentary upgrade on rebooked flight or future flight voucher"
                },
                "mileage_bonus": {
                    "provided": mileage_bonus > 0,
                    "value_per_passenger": round(mileage_bonus / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(mileage_bonus, 2),
                    "description": "Frequent flyer bonus miles (approx. 5,000 per passenger)"
                },
                "goodwill_voucher": {
                    "provided": goodwill_voucher > 0,
                    "value_per_passenger": round(goodwill_voucher / passenger_count, 2) if passenger_count > 0 else 0,
                    "total_value": round(goodwill_voucher, 2),
                    "description": "Goodwill compensation voucher for future travel"
                },
                "total_vouchers_value": round(vouchers_benefits_total, 2)
            },
            "total_benefits_provided": {
                "care_obligations": round(care_obligations_total, 2),
                "vouchers_and_benefits": round(vouchers_benefits_total, 2),
                "total_passenger_benefits": round(total_benefits_value, 2),
                "description": "Total value of care obligations and compensatory benefits provided to passengers"
            },
            "policy_compliance": policy_compliance,
            "disruption_penalty": disruption_penalty,
            "total_disruption_cost": round(total_disruption_cost, 2),
            "policy_reference": policy_info[:200] + "..." if len(policy_info) > 200 else policy_info,
            "care_obligations_reference": care_info[:300] + "..." if len(care_info) > 300 else care_info
        }
        
    except Exception as e:
        log("rebook_cost", f"Error: {e}")
        import traceback
        log("rebook_cost", f"Traceback: {traceback.format_exc()}")
        return {"error": f"Rebook cost calculation failed: {e}"}


def notify_airline(
    pnr: str,
    action: str,
    passenger_count: int,
    lead_name: str,
    new_flight: Optional[dict] = None,
    split_booking_result: Optional[dict] = None,
    cost_summary: Optional[dict] = None
) -> str:
    """
    Send notification to airline operations about passenger decision.
    This simulates an internal airline notification system.
    ENHANCED: Now includes detailed cost breakdown and total airline liability.
    
    Parameters:
    - pnr: PNR string
    - action: Passenger action (selected, wait, cancel)
    - passenger_count: Number of passengers
    - lead_name: Lead passenger name
    - new_flight: New flight details (if applicable)
    - split_booking_result: Split booking details (if applicable)
    - cost_summary: Cost breakdown from Cost Agent (includes all costs/penalties)
    
    Returns:
    - Confirmation message
    """
    # Helper function to safely extract numeric values
    def safe_numeric(value, default=0):
        """Safely convert value to numeric, handling dicts and other types"""
        if isinstance(value, (int, float)):
            return value
        elif isinstance(value, dict):
            return 0  # Return 0 for dict values that shouldn't be compared
        else:
            try:
                return float(value)
            except (ValueError, TypeError):
                return default
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Build airline notification message
    notification = f"""
================================================================================
                    AIRLINE OPERATIONS NOTIFICATION
================================================================================
Timestamp: {timestamp}
PNR: {pnr}
Lead Passenger: {lead_name}
Passenger Count: {passenger_count}
Action Taken: {action.upper()}
"""
    
    # ========================================================================
    # ENHANCED: Add comprehensive cost breakdown for airline liability
    # ========================================================================
    total_airline_cost = 0.0
    cost_breakdown = []
    
    if cost_summary:
        notification += "\n" + "="*80 + "\n"
        notification += "                    FINANCIAL IMPACT ANALYSIS\n"
        notification += "="*80 + "\n"
    
    if action == "selected":
        if split_booking_result:
            flight_bookings = split_booking_result.get("flight_bookings", {})
            new_pnrs = split_booking_result.get("new_pnrs", {})
            notification += f"\nBooking Type: SPLIT BOOKING\n"
            notification += f"Flights Involved: {', '.join(flight_bookings.keys())}\n"
            notification += f"New PNRs: {', '.join(new_pnrs.values())}\n"
        elif new_flight:
            notification += f"\nBooking Type: STANDARD REBOOKING\n"
            notification += f"New Flight: {new_flight.get('flight_number', 'Unknown')}\n"
            notification += f"Route: {new_flight.get('origin', 'Unknown')} -> {new_flight.get('destination', 'Unknown')}\n"
            notification += f"Departure: {new_flight.get('departure_time', 'Unknown')}\n"
        
        # Extract rebooking costs
        if cost_summary:
            notification += "\n--- REBOOKING COSTS ---\n"
            
            # Fare difference
            if "fare_difference" in cost_summary:
                fare_diff = safe_numeric(cost_summary["fare_difference"].get("total_fare_difference", 0))
                if fare_diff != 0:
                    if fare_diff > 0:
                        cost_breakdown.append(f"  Fare Upgrade (Customer Pays): ${fare_diff:.2f}")
                        notification += f"  Fare Difference: +${fare_diff:.2f} (Revenue from customer)\n"
                    else:
                        airline_cost = abs(fare_diff)
                        total_airline_cost += airline_cost
                        cost_breakdown.append(f"  Fare Downgrade Refund: ${airline_cost:.2f}")
                        notification += f"  Fare Difference: -${airline_cost:.2f} (Refund to customer)\n"
            
            # Care obligations during wait
            if "care_obligations" in cost_summary:
                care_total = 0
                notification += "\n--- CARE OBLIGATIONS PROVIDED ---\n"
                for key, val in cost_summary["care_obligations"].items():
                    if isinstance(val, dict) and val.get("provided"):
                        desc = val.get("description", key)
                        total_val = safe_numeric(val.get("total_value", 0))
                        if total_val > 0:
                            care_total += total_val
                            notification += f"  {desc}: ${total_val:.2f}\n"
                
                if care_total > 0:
                    total_airline_cost += care_total
                    cost_breakdown.append(f"  Care Obligations: ${care_total:.2f}")
            
            # Vouchers and benefits
            if "vouchers_and_benefits" in cost_summary:
                voucher_total = 0
                notification += "\n--- VOUCHERS & BENEFITS PROVIDED ---\n"
                for key, val in cost_summary["vouchers_and_benefits"].items():
                    if isinstance(val, dict) and val.get("provided"):
                        desc = val.get("description", key)
                        total_val = safe_numeric(val.get("total_value", 0))
                        if total_val > 0:
                            voucher_total += total_val
                            notification += f"  {desc}: ${total_val:.2f}\n"
                
                if voucher_total > 0:
                    total_airline_cost += voucher_total
                    cost_breakdown.append(f"  Vouchers & Benefits: ${voucher_total:.2f}")
            
            # Total benefits
            if "total_benefits_provided" in cost_summary:
                benefits = safe_numeric(cost_summary["total_benefits_provided"])
                if benefits > 0 and not cost_breakdown:
                    total_airline_cost = benefits
                    cost_breakdown.append(f"  Total Benefits: ${benefits:.2f}")
    
    elif action == "wait":
        notification += "\nStatus: PASSENGER WAITING FOR UPDATE\n"
        notification += "Action Required: Monitor flight status and provide updates\n"
        
        # Extract wait costs
        if cost_summary:
            notification += "\n--- ENTITLEMENTS PROVIDED ---\n"
            
            # Care obligations
            if "care_obligations" in cost_summary:
                care_total = 0
                for key, val in cost_summary["care_obligations"].items():
                    if isinstance(val, dict) and val.get("provided"):
                        desc = val.get("description", key)
                        total_val = safe_numeric(val.get("total_value", val.get("initial_total_value", 0)))
                        if total_val > 0:
                            care_total += total_val
                            notification += f"  {desc}: ${total_val:.2f}\n"
                
                if care_total > 0:
                    total_airline_cost += care_total
                    cost_breakdown.append(f"  Care Obligations: ${care_total:.2f}")
            
            # Vouchers and benefits
            if "vouchers_and_benefits" in cost_summary:
                voucher_total = 0
                for key, val in cost_summary["vouchers_and_benefits"].items():
                    if isinstance(val, dict) and val.get("provided"):
                        desc = val.get("description", key)
                        total_val = safe_numeric(val.get("total_value", 0))
                        if total_val > 0:
                            voucher_total += total_val
                            notification += f"  {desc}: ${total_val:.2f}\n"
                
                if voucher_total > 0:
                    total_airline_cost += voucher_total
                    cost_breakdown.append(f"  Vouchers & Benefits: ${voucher_total:.2f}")
            
            # Total entitlement
            if "cost_summary" in cost_summary and "total_entitlement_value" in cost_summary["cost_summary"]:
                entitlement = safe_numeric(cost_summary["cost_summary"]["total_entitlement_value"])
                if entitlement > 0 and not cost_breakdown:
                    total_airline_cost = entitlement
                    cost_breakdown.append(f"  Total Entitlements: ${entitlement:.2f}")
    
    elif action == "cancel":
        notification += "\nStatus: BOOKING CANCELLED\n"
        notification += "Action Required: Process refund within policy timeline\n"
        
        # Extract cancellation costs
        if cost_summary:
            notification += "\n--- REFUND & COMPENSATION BREAKDOWN ---\n"
            
            # Refund amount
            if "refund_details" in cost_summary:
                refund = safe_numeric(cost_summary["refund_details"].get("refund_amount", 0))
                timeline = cost_summary["refund_details"].get("refund_timeline", "7-10 business days")
                if refund > 0:
                    total_airline_cost += refund
                    cost_breakdown.append(f"  Cash Refund: ${refund:.2f}")
                    notification += f"  Cash Refund: ${refund:.2f} (Timeline: {timeline})\n"
            elif "refund_amount" in cost_summary:
                refund = safe_numeric(cost_summary.get("refund_amount", 0))
                if refund > 0:
                    total_airline_cost += refund
                    cost_breakdown.append(f"  Cash Refund: ${refund:.2f}")
                    notification += f"  Cash Refund: ${refund:.2f}\n"
            
            # EU261 compensation
            if "eu261_compensation" in cost_summary:
                if cost_summary["eu261_compensation"].get("eligible"):
                    eu261 = safe_numeric(cost_summary["eu261_compensation"].get("total_compensation", 0))
                    per_pax = safe_numeric(cost_summary["eu261_compensation"].get("compensation_per_passenger", 0))
                    if eu261 > 0:
                        total_airline_cost += eu261
                        cost_breakdown.append(f"  EU261 Compensation: ${eu261:.2f}")
                        notification += f"  EU261 Compensation: ${eu261:.2f} (${per_pax:.2f} per passenger)\n"
            elif "compensation_amount" in cost_summary:
                comp = safe_numeric(cost_summary.get("compensation_amount", 0))
                if comp > 0:
                    total_airline_cost += comp
                    cost_breakdown.append(f"  Compensation: ${comp:.2f}")
                    notification += f"  Regulatory Compensation: ${comp:.2f}\n"
            
            # Care obligations
            if "care_obligations" in cost_summary:
                care_total = 0
                notification += "\n--- CARE OBLIGATIONS PROVIDED ---\n"
                for key, val in cost_summary["care_obligations"].items():
                    if isinstance(val, dict) and val.get("provided"):
                        desc = val.get("description", key)
                        total_val = safe_numeric(val.get("total_value", 0))
                        if total_val > 0:
                            care_total += total_val
                            notification += f"  {desc}: ${total_val:.2f}\n"
                
                if care_total > 0:
                    total_airline_cost += care_total
                    cost_breakdown.append(f"  Care Obligations: ${care_total:.2f}")
            
            # Vouchers and benefits
            if "vouchers_and_benefits" in cost_summary:
                voucher_total = 0
                notification += "\n--- VOUCHERS & BENEFITS PROVIDED ---\n"
                for key, val in cost_summary["vouchers_and_benefits"].items():
                    if isinstance(val, dict) and val.get("provided"):
                        desc = val.get("description", key)
                        total_val = safe_numeric(val.get("total_value", 0))
                        if total_val > 0:
                            voucher_total += total_val
                            notification += f"  {desc}: ${total_val:.2f}\n"
                
                if voucher_total > 0:
                    total_airline_cost += voucher_total
                    cost_breakdown.append(f"  Vouchers & Benefits: ${voucher_total:.2f}")
            
            # Total package
            if "total_package" in cost_summary:
                total_pkg_data = cost_summary["total_package"]
                if isinstance(total_pkg_data, dict):
                    total_pkg = safe_numeric(total_pkg_data.get("total_passenger_receives", 0))
                else:
                    total_pkg = safe_numeric(total_pkg_data)
                
                if total_pkg > 0 and not cost_breakdown:
                    total_airline_cost = total_pkg
                    cost_breakdown.append(f"  Total Package: ${total_pkg:.2f}")
    
    # Display total airline cost/liability
    if total_airline_cost > 0:
        notification += "\n" + "="*80 + "\n"
        notification += f"TOTAL AIRLINE COST/LIABILITY: ${total_airline_cost:.2f}\n"
        notification += f"Per Passenger: ${total_airline_cost / passenger_count:.2f}\n"
        notification += "="*80 + "\n"
        notification += "\nCost Components:\n"
        for item in cost_breakdown:
            notification += f"{item}\n"
    
    notification += "\n" + "="*80 + "\n"
    
    # Action items for different departments
    notification += "\nACTION ITEMS:\n"
    if action == "cancel":
        notification += "  Finance: Process refund to original payment method\n"
        if cost_summary and cost_summary.get("eu261_compensation", {}).get("eligible"):
            notification += "  Finance: Process EU261 compensation payment\n"
        notification += "  Operations: Cancel booking in system\n"
        notification += "  Customer Service: Send confirmation to customer\n"
    elif action == "selected":
        notification += "  Operations: Confirm new flight seats\n"
        notification += "  Finance: Process any fare adjustments\n"
        if cost_summary and cost_summary.get("care_obligations"):
            notification += "  Airport Services: Provide care obligation vouchers\n"
        notification += "  Customer Service: Send booking confirmation\n"
    elif action == "wait":
        notification += "  Operations: Monitor flight status continuously\n"
        notification += "  Airport Services: Provide refreshments/vouchers as entitled\n"
        notification += "  Customer Service: Update customer on any changes\n"
    
    notification += "\n" + "="*80 + "\n"
    notification += "[END AIRLINE NOTIFICATION]\n"
    notification += "="*80 + "\n"
    
    # Display to console for visibility (with explicit flush and visual markers)
    print("\n" + "="*40 + " AIRLINE NOTIFICATION " + "="*40, flush=True)
    print(notification, flush=True)
    print("="*100 + "\n", flush=True)
    
    # Log to file (in production, this would send to airline system)
    log("airline_notification", notification)
    
    # In a real system, this would:
    # 1. Send to airline operations database
    # 2. Trigger workflow in airline CRM
    # 3. Update passenger service records
    # 4. Alert relevant departments (finance for refunds, ops for rebooking)
    # 5. Update financial reporting system with cost impact
    
    if total_airline_cost > 0:
        return f"Airline notified successfully - Action: {action}, PNR: {pnr}, Total Cost: ${total_airline_cost:.2f}"
    else:
        return f"Airline notified successfully - Action: {action}, PNR: {pnr}"


@tool
def notify_passenger(
    pnr: str, 
    customer_notification: str = "",
    airline_notification: Optional[str] = None,
    new_flight: Optional[dict] = None, 
    split_booking_result: Optional[dict] = None,
    action: str = "selected",
    disruption_type: str = "unknown",
    policy_context: Optional[str] = None,
    cost_summary: Optional[dict] = None
) -> str:
    """
    Send pre-generated notification messages to both airline and customer.
    
    The LLM should generate the notification text and pass it to this tool.
    
    Parameters:
    - pnr: PNR string (e.g., "YJKB2S")
    - customer_notification: The complete customer notification text (REQUIRED - generated by LLM). If not provided, a basic message will be generated.
    - airline_notification: The complete airline notification text (optional - generated by LLM, auto-generated if not provided)
    - new_flight: Single flight dict (for non-split bookings) - used for auto-generating airline notification
    - split_booking_result: Split booking result from booking_apply - used for auto-generating airline notification
    - action: Passenger action - "selected", "wait", "cancel"
    - disruption_type: Type of disruption - "cancelled", "delayed", "unknown"
    - policy_context: Relevant policy information from Policy Agent (for context)
    - cost_summary: Cost breakdown from Cost Agent (for context)
    
    Returns:
    - Confirmation message
    """
    # Check if customer_notification was provided
    if not customer_notification or customer_notification.strip() == "":
        print("\n[WARN] customer_notification parameter not provided - generating basic notification...")
        # Generate a basic notification
        customer_notification = f"Dear Customer,\n\nRegarding your booking {pnr}: Your request has been processed.\n\nAction: {action}\n\nBest regards,\nSun Airlines"
    
    # Helper function to safely extract numeric values
    def safe_numeric(value, default=0):
        """Safely convert value to numeric, handling dicts and other types"""
        if isinstance(value, (int, float)):
            return value
        elif isinstance(value, dict):
            return 0  # Return 0 for dict values that shouldn't be compared
        else:
            try:
                return float(value)
            except (ValueError, TypeError):
                return default
    
    # Debug logging
    log("notify_passenger", f"Called with pnr={pnr}, action={action}, disruption_type={disruption_type}, has_customer_notification={bool(customer_notification)}")
    
    # Handle case where entire dict is passed as JSON string (LangChain tool invocation issue)
    if isinstance(pnr, str) and pnr.strip().startswith("{"):
        log("notify_passenger", "Detected JSON string as pnr - parsing")
        try:
            parsed = json.loads(pnr)
            if "pnr" in parsed:
                customer_notification = parsed.get("customer_notification", customer_notification)
                airline_notification = parsed.get("airline_notification", airline_notification)
                new_flight = parsed.get("new_flight")
                split_booking_result = parsed.get("split_booking_result")
                action = parsed.get("action", "selected")
                disruption_type = parsed.get("disruption_type", "unknown")
                policy_context = parsed.get("policy_context")
                cost_summary = parsed.get("cost_summary")
                pnr = parsed["pnr"]
                log("notify_passenger", f"Extracted pnr={pnr}, action={action}")
        except json.JSONDecodeError as e:
            log("notify_passenger", f"Failed to parse JSON: {e}")
            return f"Error: Invalid JSON parameters - {e}"
    # Also handle case where dict is passed directly
    elif isinstance(pnr, dict):
        log("notify_passenger", "Detected dict as pnr - extracting fields")
        if "pnr" in pnr:
            customer_notification = pnr.get("customer_notification", customer_notification)
            airline_notification = pnr.get("airline_notification", airline_notification)
            new_flight = pnr.get("new_flight")
            split_booking_result = pnr.get("split_booking_result")
            action = pnr.get("action", "selected")
            disruption_type = pnr.get("disruption_type", "unknown")
            policy_context = pnr.get("policy_context")
            cost_summary = pnr.get("cost_summary")
            pnr = pnr["pnr"]
        else:
            return "Error: Invalid parameters - pnr must be a string"
    
    # Validate that we have the customer notification
    if not customer_notification:
        return "Error: customer_notification is required. The LLM must generate the notification text and pass it to this tool."
    
    # Normalize action parameter - map any rebook-related actions to "selected"
    if action in ["rebook", "rebooked", "rebook_group", "rebook_split"]:
        log("notify_passenger", f"Normalizing action from '{action}' to 'selected'")
        action = "selected"
    
    pnr_details = get_pnr_details(pnr)
    if not pnr_details:
        return f"PNR {pnr} not found."

    lead_name = pnr_details["lead_passenger_name"]
    passenger_count = pnr_details["passenger_count"]
    passengers = pnr_details["passengers"]
    
    # Auto-generate airline notification if not provided
    if not airline_notification or airline_notification == "":
        log("notify_passenger", "Auto-generating airline notification")
        airline_notification = notify_airline(
            pnr=pnr,
            action=action,
            passenger_count=passenger_count,
            lead_name=lead_name,
            new_flight=new_flight,
            split_booking_result=split_booking_result,
            cost_summary=cost_summary
        )
    else:
        # If LLM provided airline notification, just display it
        log("notify_passenger", "Using LLM-provided airline notification")
        print("\n" + "="*40 + " AIRLINE NOTIFICATION " + "="*40, flush=True)
        print(airline_notification, flush=True)
        print("="*100 + "\n", flush=True)
        log("airline_notification", airline_notification)
    
    # Display the LLM-generated customer notification
    print("\n" + "="*40 + " CUSTOMER NOTIFICATION " + "="*40, flush=True)
    print(customer_notification, flush=True)
    print("="*100 + "\n", flush=True)
    
    # Log to file
    log("customer_notification", f"\n{'='*70}\nCUSTOMER NOTIFICATION\n{'='*70}\n{customer_notification}\n{'='*70}")
    
    return customer_notification


@tool
def query_policy_knowledge_base(query: str) -> dict:
    """
    Query the flight policy knowledge base for relevant policy information.
    
    Use this tool to retrieve information about:
    - Rebooking policies and rules
    - Cancellation policies
    - Compensation rules
    - Passenger rights and accommodations
    - Multi-passenger group policies
    - International flight regulations
    - Special circumstances handling
    
    Args:
        query: Natural language query about flight policies (e.g., "What is the rebooking policy for cancelled flights?")
    
    Returns:
        Dictionary with policy information and relevant excerpts
    """
    global _policy_context
    
    if not RAG_AVAILABLE:
        return {
            "success": False,
            "error": "RAG knowledge base not available. Please ensure dependencies are installed.",
            "policy_info": "Unable to access policy knowledge base."
        }
    
    # Wrap RAG query with retry logic
    @retry_api_call(max_retries=3, initial_delay=1.0, max_delay=10.0)
    def _query_with_retry():
        return _query_kb(query)
    
    try:
        log("policy_kb", f"Querying knowledge base: {query}")
        
        # Query the knowledge base with retry logic
        policy_context = _query_with_retry()
        
        # Sanitize policy context to remove non-ASCII characters (Windows cp1252 compatibility)
        policy_context_clean = ''.join(c if ord(c) < 128 else '?' for c in str(policy_context))
        
        # Store in global context for subsequent tool calls
        _policy_context['latest'] = policy_context_clean
        log("policy_kb", f"Stored policy in context ({len(policy_context_clean)} chars)")
        
        return {
            "success": True,
            "query": query,
            "policy_info": policy_context_clean,
            "message": "Retrieved relevant policy information from knowledge base"
        }
        
    except Exception as e:
        log("policy_kb", f"Error querying knowledge base after retries: {e}")
        return {
            "success": False,
            "error": str(e),
            "policy_info": "Error retrieving policy information. Using default airline policies."
        }
