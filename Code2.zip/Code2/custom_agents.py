# custom_agents.py - MULTI-PASSENGER PNR SUPPORT
# RecoverAI  ReAct Agent Implementation

from __future__ import annotations
from typing import Dict, Any, List
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import PromptTemplate
import json
import re

# OpenAI / Azure OpenAI
try:
    from langchain_openai import AzureChatOpenAI, ChatOpenAI
except Exception:
    AzureChatOpenAI = None
    ChatOpenAI = None

from config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_DEPLOYMENT,
    OPENAI_API_KEY,
)

# Import tool functions
from tools import (
    get_passenger_by_pnr,
    get_original_flight,
    resource_find_alternative,
    booking_apply,
    cost_calculation,
    notify_passenger,
    query_policy_knowledge_base,
)


# -------------------------------------------------------------------------
# ReAct Prompt Template
# -------------------------------------------------------------------------
def get_react_prompt_template(system_instructions: str) -> PromptTemplate:
    """Create a ReAct prompt template with required variables."""
    template = """Answer the following questions as best you can. You have access to the following tools:

{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

SYSTEM INSTRUCTIONS:
""" + system_instructions + """

Begin!

Question: {input}
Thought:{agent_scratchpad}"""
    
    return PromptTemplate.from_template(template)
def get_llm_model() -> Any:
    """Return LLM model instance (Azure OpenAI preferred) - ALL AGENTS USE GPT-4o."""
    if AzureChatOpenAI and AZURE_OPENAI_API_KEY:
        return AzureChatOpenAI(
            azure_deployment=AZURE_OPENAI_DEPLOYMENT,
            api_version=AZURE_OPENAI_API_VERSION or "2024-05-01-preview",
            api_key=AZURE_OPENAI_API_KEY,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            temperature=0,
        )
    if ChatOpenAI:
        return ChatOpenAI(model="gpt-4o", temperature=0)  # Updated to GPT-4o for all agents
    raise RuntimeError("No LLM configured. Set Azure or OpenAI environment vars.")


# -------------------------------------------------------------------------
# ReAct Agent Wrapper with Parameter Augmentation
# -------------------------------------------------------------------------
class ReactAgentWrapper:
    """Wrapper around AgentExecutor that provides parameter augmentation."""
    
    def __init__(self, name: str, agent_executor: AgentExecutor, augment_params: bool = False):
        self.name = name
        self.agent_executor = agent_executor
        self.augment_params = augment_params
        self.input_data = {}
        
        # If augmentation is enabled, wrap the tools
        if self.augment_params and hasattr(agent_executor, 'tools'):
            self.original_tools = agent_executor.tools
            
    def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run the ReAct agent with the given input data."""
        print(f"\n {self.name} - Starting with input: {input_data}")
        
        # Store input data for potential tool augmentation
        self.input_data = input_data
        
        # If augmentation is enabled, wrap tools dynamically
        if self.augment_params:
            # Store original tools
            original_tools = self.agent_executor.tools
            
            # Wrap each tool with augmentation
            wrapped_tools = []
            for tool in original_tools:
                wrapped_tool = AugmentedTool(tool, self.name, input_data)
                wrapped_tools.append(wrapped_tool)
            
            # Replace tools temporarily
            self.agent_executor.tools = wrapped_tools
            
            # Also update the agent's tools if it has a tools attribute
            if hasattr(self.agent_executor.agent, 'tools'):
                self.agent_executor.agent.tools = wrapped_tools
        
        # Format input for ReAct agent
        input_str = self._format_input(input_data)
        
        try:
            # Run the agent executor
            result = self.agent_executor.invoke({"input": input_str})
            
            # Parse and return the output
            output = result.get("output", "")
            print(f" {self.name} - Agent completed successfully")
            return self._parse_output(output)
            
        except Exception as e:
            print(f" {self.name} - Error: {str(e)}")
            return {"error": str(e)}
        finally:
            # Restore original tools if we wrapped them
            if self.augment_params:
                self.agent_executor.tools = original_tools
                if hasattr(self.agent_executor.agent, 'tools'):
                    self.agent_executor.agent.tools = original_tools
    
    def _format_input(self, input_data: Dict[str, Any]) -> str:
        """Format input data as a string for the ReAct agent."""
        lines = ["Please process the following request:"]
        lines.append("\nINPUT DATA:")
        
        for key, value in input_data.items():
            if value is not None:
                if isinstance(value, (dict, list)):
                    # For supervisor agent, format as readable text instead of JSON to avoid prompt conflicts
                    if self.name == "supervisor_agent":
                        if isinstance(value, dict):
                            # Format dict as key: value pairs
                            lines.append(f"\n{key}:")
                            for k, v in value.items():
                                lines.append(f"  - {k}: {v}")
                        else:
                            # For lists, keep simple JSON
                            value_str = json.dumps(value, indent=2)
                            lines.append(f"\n{key}:")
                            lines.append(value_str)
                    else:
                        # For other agents, escape curly braces for PromptTemplate
                        value_str = json.dumps(value, indent=2).replace("{", "{{").replace("}", "}}")
                        lines.append(f"\n{key}:")
                        lines.append(value_str)
                else:
                    value_str = str(value)
                    lines.append(f"\n{key}:")
                    lines.append(value_str)
        
        # Add specific instructions based on agent type
        if self.name == "cost_agent":
            lines.append("\n\nREMEMBER:")
            lines.append("1. Call booking_apply first with:")
            lines.append(f'   - pnr should be the STRING value "{input_data.get("pnr", "")}"')
            lines.append("   - new_flight should be the DICT object shown in INPUT DATA above")
            lines.append("2. Then call cost_calculation with:")
            lines.append("   - original_flight should be the DICT object shown in INPUT DATA above")
            lines.append("   - alternative_flight should be the new_flight DICT from INPUT DATA above")
            lines.append("3. NEVER pass the entire input as a single parameter")
            lines.append("4. Extract individual fields from INPUT DATA and pass them separately")
        
        elif self.name == "notify_agent":
            lines.append("\n\nREMEMBER:")
            lines.append(f'1. The pnr parameter MUST be the string "{input_data.get("pnr", "")}"')
            lines.append("2. The new_flight parameter should be the DICT object from INPUT DATA above")
            lines.append("3. CRITICAL: Do NOT pass the entire input as pnr - extract just the pnr string")
        
        return "\n".join(lines)
    
    def _parse_output(self, output: str) -> Dict[str, Any]:
        """Parse the agent output into a structured format."""
        try:
            # Try to extract JSON from the output
            cleaned = output.strip()
            
            # Look for JSON in markdown code blocks first
            json_match = re.search(r'```json\n(.*?)\n```', cleaned, re.DOTALL)
            if json_match:
                cleaned = json_match.group(1).strip()
            elif re.search(r'```\n(.*?)\n```', cleaned, re.DOTALL):
                # Try without json specifier
                json_match = re.search(r'```\n(.*?)\n```', cleaned, re.DOTALL)
                cleaned = json_match.group(1).strip()
            
            # Look for JSON object - use greedy match to capture entire object
            json_match = re.search(r'\{.*\}', cleaned, re.DOTALL)
            if json_match:
                cleaned = json_match.group(0)
            
            # Try to parse as JSON
            result = json.loads(cleaned)
            print(f" {self.name} - Successfully parsed JSON response")
            return result
            
        except json.JSONDecodeError as e:
            print(f"  {self.name} - JSON parsing failed: {e}")
            print(f"  {self.name} - Attempted to parse: {cleaned[:200]}...")
            # Try to find if output contains a valid dictionary structure
            try:
                # Last resort: try to eval if it looks like a Python dict (not recommended but can work)
                if cleaned.startswith('{') and cleaned.endswith('}'):
                    result = eval(cleaned)
                    if isinstance(result, dict):
                        print(f" {self.name} - Successfully parsed using eval (dict structure)")
                        return result
            except:
                pass
            print(f"  {self.name} - Could not parse as JSON, returning raw output")
            return {"message": output}
        except Exception as e:
            print(f"  {self.name} - Unexpected error during parsing: {e}")
            return {"message": output}


# -------------------------------------------------------------------------
# Custom Tool Wrapper for Parameter Augmentation
# -------------------------------------------------------------------------
class AugmentedTool:
    """Wraps a tool to augment its arguments before invocation."""
    
    def __init__(self, tool, agent_name: str, input_data: Dict[str, Any]):
        self.tool = tool
        self.agent_name = agent_name
        self.input_data = input_data
        self.name = tool.name
        self.description = tool.description
        self.args_schema = tool.args_schema
        # Delegate additional attributes that AgentExecutor might need
        self.return_direct = getattr(tool, 'return_direct', False)
        self.verbose = getattr(tool, 'verbose', False)
        self.callbacks = getattr(tool, 'callbacks', None)
        self.tags = getattr(tool, 'tags', None)
        self.metadata = getattr(tool, 'metadata', None)
        
    def __getattr__(self, name):
        """Delegate any other attribute access to the wrapped tool."""
        return getattr(self.tool, name)
    
    def __call__(self, *args, **kwargs):
        """Support direct call interface."""
        # Filter out internal LangChain attributes
        filtered_kwargs = {k: v for k, v in kwargs.items() if k not in ['verbose', 'color', 'callbacks', 'tags', 'metadata']}
        
        # Parse input - could be positional or keyword args
        if len(args) == 1 and isinstance(args[0], (dict, str)):
            input_arg = args[0]
        elif filtered_kwargs:
            input_arg = filtered_kwargs
        else:
            # Pass through if we can't parse
            return self.tool(*args, **kwargs)
        
        # Handle string input (JSON)
        if isinstance(input_arg, str):
            try:
                input_arg = json.loads(input_arg)
            except:
                pass  # Not JSON, pass through
        
        # Augment if dict
        if isinstance(input_arg, dict):
            augmented = self._augment_args(input_arg)
            return self.tool(augmented, **{k: v for k, v in kwargs.items() if k in ['verbose', 'color', 'callbacks', 'tags', 'metadata']})
        
        return self.tool(*args, **kwargs)
    
    def invoke(self, args: Dict[str, Any]) -> Any:
        """Invoke the tool with augmented arguments."""
        augmented_args = self._augment_args(args)
        return self.tool.invoke(augmented_args)
    
    def run(self, *args, **kwargs):
        """Support the run interface for compatibility."""
        # If called with dict input, augment it
        if len(args) == 1 and isinstance(args[0], dict):
            augmented_args = self._augment_args(args[0])
            return self.tool.run(**augmented_args)
        elif len(args) == 1 and isinstance(args[0], str):
            # String input - pass through
            return self.tool.run(args[0])
        elif kwargs:
            augmented_args = self._augment_args(kwargs)
            return self.tool.run(**augmented_args)
        # Otherwise pass through
        return self.tool.run(*args, **kwargs)
    
    def _run(self, *args, **kwargs):
        """Support the _run interface (used by LangChain internally)."""
        # Same logic as run
        if len(args) == 1 and isinstance(args[0], dict):
            augmented_args = self._augment_args(args[0])
            return self.tool._run(**augmented_args)
        elif len(args) == 1 and isinstance(args[0], str):
            # String input - pass through
            return self.tool._run(args[0])
        elif kwargs:
            augmented_args = self._augment_args(kwargs)
            return self.tool._run(**augmented_args)
        return self.tool._run(*args, **kwargs)
    
    def _augment_args(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Augment tool arguments with missing parameters."""
        augmented = args.copy()
        tool_name = self.tool.name
        
        print(f"[AUGMENT] Checking {tool_name} parameters")
        print(f"[AUGMENT] Current args: {list(augmented.keys())}")
        print(f"[AUGMENT] Available input: {list(self.input_data.keys())}")
        
        if tool_name == "booking_apply":
            if "new_flight" not in augmented or not augmented["new_flight"]:
                if "new_flight" in self.input_data:
                    augmented["new_flight"] = self.input_data["new_flight"]
                    print(f" Auto-fixed: Added new_flight to booking_apply")
            
            if "pnr" not in augmented or not augmented["pnr"]:
                if "pnr" in self.input_data:
                    augmented["pnr"] = self.input_data["pnr"]
                    print(f" Auto-fixed: Added pnr to booking_apply")
        
        elif tool_name == "cost_calculation":
            if "original_flight" not in augmented or not augmented["original_flight"]:
                if "original_flight" in self.input_data:
                    augmented["original_flight"] = self.input_data["original_flight"]
                    print(f" Auto-fixed: Added original_flight to cost_calculation")
            
            if "alternative_flight" not in augmented or not augmented["alternative_flight"]:
                if "new_flight" in self.input_data:
                    augmented["alternative_flight"] = self.input_data["new_flight"]
                    print(f" Auto-fixed: Added alternative_flight (from new_flight)")
        
        elif tool_name == "calculate_rebook_cost":
            # Enhanced validation and auto-fix for rebook cost calculation
            print(f"[REBOOK_COST] Validating calculate_rebook_cost parameters")
            
            if "pnr" not in augmented or not augmented["pnr"]:
                if "pnr" in self.input_data:
                    augmented["pnr"] = self.input_data["pnr"]
                    print(f" Auto-fixed: Added pnr to calculate_rebook_cost")
            
            if "original_flight" not in augmented or not augmented["original_flight"]:
                if "original_flight" in self.input_data:
                    augmented["original_flight"] = self.input_data["original_flight"]
                    print(f" Auto-fixed: Added original_flight to calculate_rebook_cost")
                    if isinstance(augmented.get('original_flight'), dict):
                        print(f"[REBOOK_COST] Original flight: {augmented['original_flight'].get('flight_number')}")
            
            if "alternative_flight" not in augmented or not augmented["alternative_flight"]:
                if "new_flight" in self.input_data:
                    augmented["alternative_flight"] = self.input_data["new_flight"]
                    print(f" Auto-fixed: Added alternative_flight (from new_flight) to calculate_rebook_cost")
                    if isinstance(augmented.get('alternative_flight'), dict):
                        print(f"[REBOOK_COST] Alternative flight: {augmented['alternative_flight'].get('flight_number')}")
            
            if "disruption_type" not in augmented or not augmented["disruption_type"]:
                if "disruption_type" in self.input_data:
                    augmented["disruption_type"] = self.input_data["disruption_type"]
                    print(f" Auto-fixed: Added disruption_type to calculate_rebook_cost: {augmented['disruption_type']}")
                else:
                    # Default to 'cancelled' if not provided
                    augmented["disruption_type"] = "cancelled"
                    print(f" Auto-fixed: Set default disruption_type='cancelled' for calculate_rebook_cost")
            
            # Validate that we have valid dictionaries
            if not isinstance(augmented.get("original_flight"), dict):
                print(f"[ERROR] original_flight is not a dict: {type(augmented.get('original_flight'))}")
            if not isinstance(augmented.get("alternative_flight"), dict):
                print(f"[ERROR] alternative_flight is not a dict: {type(augmented.get('alternative_flight'))}")
        
        elif tool_name == "calculate_cancellation_cost":
            print(f"[CANCEL_COST] Validating calculate_cancellation_cost parameters")
            
            if "pnr" not in augmented or not augmented["pnr"]:
                if "pnr" in self.input_data:
                    augmented["pnr"] = self.input_data["pnr"]
                    print(f" Auto-fixed: Added pnr to calculate_cancellation_cost")
            
            if "original_flight" not in augmented or not augmented["original_flight"]:
                if "original_flight" in self.input_data:
                    augmented["original_flight"] = self.input_data["original_flight"]
                    print(f" Auto-fixed: Added original_flight to calculate_cancellation_cost")
            
            if "disruption_type" not in augmented or not augmented["disruption_type"]:
                if "disruption_type" in self.input_data:
                    augmented["disruption_type"] = self.input_data["disruption_type"]
                    print(f" Auto-fixed: Added disruption_type to calculate_cancellation_cost")
                else:
                    augmented["disruption_type"] = "cancelled"
                    print(f" Auto-fixed: Set default disruption_type='cancelled'")
        
        elif tool_name == "calculate_wait_cost":
            print(f"[WAIT_COST] Validating calculate_wait_cost parameters")
            
            if "pnr" not in augmented or not augmented["pnr"]:
                if "pnr" in self.input_data:
                    augmented["pnr"] = self.input_data["pnr"]
                    print(f" Auto-fixed: Added pnr to calculate_wait_cost")
            
            if "original_flight" not in augmented or not augmented["original_flight"]:
                if "original_flight" in self.input_data:
                    augmented["original_flight"] = self.input_data["original_flight"]
                    print(f" Auto-fixed: Added original_flight to calculate_wait_cost")
            
            if "disruption_type" not in augmented or not augmented["disruption_type"]:
                if "disruption_type" in self.input_data:
                    augmented["disruption_type"] = self.input_data["disruption_type"]
                    print(f" Auto-fixed: Added disruption_type to calculate_wait_cost")
                else:
                    augmented["disruption_type"] = "delayed"
                    print(f" Auto-fixed: Set default disruption_type='delayed'")
        
        elif tool_name == "notify_passenger":
            if "pnr" not in augmented or not augmented["pnr"]:
                if "pnr" in self.input_data:
                    augmented["pnr"] = self.input_data["pnr"]
                    print(f" Auto-fixed: Added pnr to notify_passenger")
            
            if "new_flight" not in augmented or not augmented["new_flight"]:
                if "new_flight" in self.input_data:
                    augmented["new_flight"] = self.input_data["new_flight"]
                    print(f" Auto-fixed: Added new_flight to notify_passenger")
        
        return augmented
    
    def __call__(self, *args, **kwargs):
        """Make the tool callable."""
        return self.invoke(kwargs if kwargs else (args[0] if args else {}))


# -------------------------------------------------------------------------
# Agent Builders - REACT AGENTS WITH MULTI-PASSENGER SUPPORT
# -------------------------------------------------------------------------
def build_support_agent():
    """Build ReAct agent for support tasks."""
    system_instructions = """You are the Support Agent for RecoverAI.
Task: Fetch PNR booking details including ALL passengers (multi-passenger support) AND original flight information.

WORKFLOW:
1. Call get_passenger_by_pnr(pnr) to get passenger details
2. Call get_original_flight(pnr) to get flight details
3. Combine both results into a single JSON response

REQUIRED OUTPUT FORMAT:
Your Final Answer MUST be valid JSON with passenger info AND a nested original_flight object.

CRITICAL RULES:
- ALWAYS call BOTH tools: get_passenger_by_pnr AND get_original_flight
- The response must include an "original_flight" key with a nested dict containing flight details
- The "flight_status" at the top level should match the status from original_flight
- If either tool returns an error, include the error in your response
- DO NOT return partial data - ensure both passenger and flight info are present

STRUCTURE REQUIREMENTS:
- Include all fields from get_passenger_by_pnr result
- Add an "original_flight" key containing the complete result from get_original_flight
- Ensure "flight_status" field matches the status from the flight data

After calling both tools, merge the results so that:
- Top level has: pnr, lead_passenger_name, passenger_count, passengers, booking_status, flight_status
- Nested "original_flight" has: flight_number, origin, destination, departure_time, arrival_time, aircraft_type, status, cost, distance"""

    tools = [get_passenger_by_pnr, get_original_flight]
    llm = get_llm_model()
    
    # Create ReAct prompt with proper template
    react_prompt = get_react_prompt_template(system_instructions)
    
    # Create ReAct agent
    react_agent = create_react_agent(llm, tools, react_prompt)
    
    # Wrap with AgentExecutor
    executor = AgentExecutor(
        agent=react_agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=10,
        return_intermediate_steps=False
    )
    
    return ReactAgentWrapper("support_agent", executor)


def build_resource_agent():
    """Build ReAct agent for resource finding with mandatory policy integration."""
    system_instructions = """You are the Resource Agent for RecoverAI.
Task: Find alternative flights for a disrupted PNR while ensuring compliance with airline policies.

MANDATORY WORKFLOW (FOLLOW THIS ORDER):
1. STEP 1 - QUERY POLICY (REQUIRED): Query the policy knowledge base FIRST
   - MUST call query_policy_knowledge_base before finding flights
   - Ask: "What are the policies for selecting alternative flights during disruptions? Include maximum delay limits, route restrictions, class of service requirements, and direct flight preferences."
   - This is NOT optional - you MUST do this step first
   - The policy information will be automatically saved for the next tool

2. STEP 2 - FIND ALTERNATIVES WITH POLICY: Find alternative flights using ONLY the PNR
   - Call resource_find_alternative with just the PNR string (e.g., "LXV93M")
   - DO NOT pass policy_guidance - the tool automatically retrieves it from Step 1
   - The tool will automatically filter flights based on policy constraints from Step 1
   - DO NOT analyze policy manually - the tool does this automatically

3. STEP 3 - REVIEW RESULTS: Check the policy_compliance report
   - The tool returns a policy_compliance section showing:
     * Which policy checks were applied
     * How many candidates were filtered out
     * Which flights violated policies (and why)
   - Review this to understand what policy filtering occurred

4. STEP 4 - RETURN RESULTS: Provide final recommendations
   - Include the alternatives list (already policy-filtered by tool)
   - Include the best_alternative (already policy-compliant)
   - Include the policy_compliance report from tool output
   - Add brief summary explaining policy application

CRITICAL RULES:
- MANDATORY: ALWAYS query policy knowledge base FIRST (Step 1)
- MANDATORY: Pass ONLY the PNR string to resource_find_alternative (Step 2) - NOT JSON
- The tool handles all policy filtering automatically - don't manually filter again
- If you skip Step 1, flights won't be policy-filtered

OUTPUT FORMAT:
Your Final Answer must be JSON containing:
- alternatives: list of policy-compliant flight options (from tool)
- best_alternative: top policy-compliant recommendation (from tool)
- disruption_type: type of disruption
- passenger_count: number of passengers
- policy_compliance: policy report from tool (includes checks_applied, filtered_out, violations)

EXAMPLE EXECUTION:
Action: query_policy_knowledge_base
Action Input: What are the policies for selecting alternative flights during disruptions? Include maximum delay limits, route restrictions, class of service requirements, and direct flight preferences.
Observation: {{"success": true, "policy_info": "... policy text ..."}}

Then call the tool with JUST the PNR string (policy_guidance will be auto-filled from context):
Action: resource_find_alternative
Action Input: LXV93M
Observation: {{"alternatives": [...], "policy_compliance": {{"policy_checks_applied": [...], "filtered_out": 3, "violations": [...]}}}}

Then provide final answer with all results including policy compliance report."""

    from tools import resource_find_alternative, query_policy_knowledge_base
    
    tools = [resource_find_alternative, query_policy_knowledge_base]
    llm = get_llm_model()
    
    react_prompt = get_react_prompt_template(system_instructions)
    react_agent = create_react_agent(llm, tools, react_prompt)
    executor = AgentExecutor(
        agent=react_agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=15  # Increased to allow for policy query + resource finding
    )
    
    return ReactAgentWrapper("resource_agent", executor)


def build_cost_agent():
    """Build ReAct agent for cost calculation and booking with action-aware cost handling."""
    system_instructions = """You are the Cost Agent for RecoverAI.
Task: Apply booking + calculate disruption cost based on passenger's selected action.

CRITICAL - ACTION-AWARE COST CALCULATION:
Determine the passenger's action from input data and call the appropriate cost tool:

1. **REBOOK ACTION** (passenger selected a flight):
   - Call booking_apply(pnr, new_flight) - system will auto-fill parameters
   - Call calculate_rebook_cost(pnr) - system will auto-fill original_flight, alternative_flight, disruption_type
   - This calculates: fare differences, upgrade/downgrade, free rebook status, passenger charges

2. **CANCEL ACTION** (passenger cancelled booking):
   - Call calculate_cancellation_cost(pnr) - system will auto-fill original_flight, disruption_type
   - This calculates: refund amount, service fees, compensation (EU261), refund timeline
   - Database status will be updated separately by supervisor

3. **WAIT ACTION** (passenger chose to wait):
   - Call calculate_wait_cost(pnr) - system will auto-fill original_flight, disruption_type
   - This calculates: entitlements (meals, hotel, transport), compensation, care obligations
   - No cost to passenger for waiting

IMPORTANT: 
- You can call tools with just the pnr parameter
- The system will automatically inject missing parameters from input data
- You can also provide full parameters if you prefer

POLICY INTEGRATION:
All cost tools automatically query the Policy Agent (RAG knowledge base) to ensure:
- Refund calculations comply with cancellation policies
- Wait entitlements match care obligation rules
- Rebook terms follow free rebooking and fare difference policies
- Compensation amounts align with EU261 or similar regulations

WORKFLOW:
1. Examine input["passenger_decision"] or detect action from available fields
2. Choose appropriate cost calculation tool (rebook/cancel/wait)
3. For rebook: also call booking_apply to update database
4. After receiving tool results, return them EXACTLY as your Final Answer

CRITICAL OUTPUT FORMAT:
- Your Final Answer MUST be ONLY the raw JSON object from the cost calculation tool
- Do NOT add ANY text before or after the JSON
- Do NOT add explanatory sentences like "Here is the result:" or "The calculation shows:"
- Do NOT wrap in markdown code blocks (no ```)
- Do NOT add line breaks or formatting around the JSON
- Return EXACTLY what the tool returned, nothing more, nothing less

CORRECT FORMAT:
Final Answer: {{"action": "rebook", "pnr": "ABC123", "passenger_count": 2, "cost_breakdown": {{...}}, "rebooking_terms": {{...}}}}

INCORRECT FORMATS:
❌ Final Answer: Here is the cost breakdown: {{"action": "rebook"...}}
❌ Final Answer: ```json\n{{"action": "rebook"...}}\n```
❌ Final Answer: The rebook cost has been calculated successfully. {{"action": "rebook"...}}"""

    from tools import booking_apply, calculate_rebook_cost, calculate_cancellation_cost, calculate_wait_cost
    
    tools = [booking_apply, calculate_rebook_cost, calculate_cancellation_cost, calculate_wait_cost]
    llm = get_llm_model()
    
    react_prompt = get_react_prompt_template(system_instructions)
    react_agent = create_react_agent(llm, tools, react_prompt)
    executor = AgentExecutor(
        agent=react_agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=15  # Increased for policy queries
    )
    
    # Create wrapper with parameter augmentation enabled
    wrapper = ReactAgentWrapper("cost_agent", executor, augment_params=True)
    
    return wrapper


def build_notify_agent():
    """Build ReAct agent for passenger notification - LLM generates notification content."""
    system_instructions = """You are the Notification Agent. Generate professional notifications for customers and airlines.

=================================================================
YOUR JOB: Write TWO notification messages
=================================================================

1. CUSTOMER NOTIFICATION (REQUIRED) - What passengers see
2. AIRLINE NOTIFICATION (optional - system auto-generates if not provided)

=================================================================
WORKFLOW:
=================================================================

STEP 1: Extract info from input
   - PNR, action (cancel/wait/selected=rebook), passenger name
   - cost_summary (all financial details)
   - new_flight details (if rebooking)

STEP 2: Generate CUSTOMER notification text
   For CANCELLATION:
   - Greeting with passenger name
   - Statement that booking is cancelled
   - FINANCIAL BREAKDOWN from cost_summary:
     * Cash refund amount and timeline
     * EU261 compensation (if eligible)
     * Care obligations provided (meals, lounge, hotel)
     * Vouchers (retail, travel, mileage, goodwill)
     * TOTAL VALUE
   - Next steps
   - Contact info and apology

   For WAIT:
   - Greeting with passenger name
   - Confirmation they chose to wait
   - Flight status
   - ENTITLEMENTS from cost_summary:
     * Care obligations (meals, refreshments, hotel, lounge)
     * Vouchers provided
     * TOTAL VALUE
   - How to collect vouchers
   - Update process

   For REBOOK (action="selected"):
   - Greeting with passenger name
   - Booking confirmation
   - NEW FLIGHT DETAILS from new_flight:
     * Flight number, route, times, aircraft
     * Seat assignments
   - COST BREAKDOWN from cost_summary:
     * Original vs new fare
     * Fare difference (if any)
     * Rebooking fees (if any)
     * Total amount due OR confirmation it's free
   - BENEFITS from cost_summary:
     * Care obligations provided
     * Vouchers given
     * Total benefits value
   - Passenger rights
   - Next steps

STEP 3: Call notify_passenger tool
   notify_passenger(
       pnr="ABC123",
       customer_notification="Dear [Name],\n\nYour complete notification text here...",
       action="cancel",
       disruption_type="cancelled",
       cost_summary=dict_object
   )

=================================================================
FORMATTING RULES:
=================================================================
- NO EMOJIS
- Use === or ━━━ for section separators
- Include ALL dollar amounts from cost_summary
- Professional, empathetic tone
- Clear section headers
- Complete sentences

EXAMPLE customer_notification:
"Dear John Smith,

Your booking (PNR: ABC123) for 2 passengers has been cancelled.

=============================================
REFUND & COMPENSATION PACKAGE
=============================================

Cash Refund: $1,200.00 (7-10 business days)
EU261 Compensation: $800.00
Care Services: $150.00 (meals, lounge)
Vouchers: $340.00

TOTAL VALUE: $2,490.00

All refunds processed automatically. Vouchers emailed within 24 hours.

Contact: 1-800-FLY-SUN

We apologize for the inconvenience.

Best regards,
Sun Airlines"

NOW GENERATE YOUR NOTIFICATION AND CALL THE TOOL!"""

    tools = [notify_passenger, query_policy_knowledge_base]
    llm = get_llm_model()
    
    react_prompt = get_react_prompt_template(system_instructions)
    react_agent = create_react_agent(llm, tools, react_prompt)
    executor = AgentExecutor(
        agent=react_agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=5
    )
    
    return ReactAgentWrapper("notify_agent", executor, augment_params=True)


def build_decision_agent():
    """Build AI-powered intelligent decision recommendation agent.
    
    This agent analyzes all flight alternatives and provides intelligent recommendations
    with reasoning to help passengers make the best decision."""
    
    from langchain_core.pydantic_v1 import BaseModel, Field
    
    # Define structured output for flight recommendations
    class FlightRecommendation(BaseModel):
        """AI recommendation for flight alternatives"""
        recommended_option: int = Field(
            description="The recommended flight option number (1, 2, or 3)"
        )
        recommendation_reasoning: str = Field(
            description="Clear explanation of why this option is recommended (2-4 sentences)"
        )
        option_1_pros: str = Field(
            description="Key advantages of Option 1"
        )
        option_1_cons: str = Field(
            description="Key disadvantages of Option 1"
        )
        option_2_pros: str = Field(
            default="",
            description="Key advantages of Option 2 (if available)"
        )
        option_2_cons: str = Field(
            default="",
            description="Key disadvantages of Option 2 (if available)"
        )
        option_3_pros: str = Field(
            default="",
            description="Key advantages of Option 3 (if available)"
        )
        option_3_cons: str = Field(
            default="",
            description="Key disadvantages of Option 3 (if available)"
        )
        key_considerations: str = Field(
            description="Important factors passengers should consider when choosing"
        )
        confidence: str = Field(
            description="Confidence level in recommendation: high, medium, or low"
        )
    
    system_prompt = """You are an AI Flight Recommendation Expert for RecoverAI.

YOUR ROLE: Analyze flight alternatives and provide intelligent recommendations to help passengers make the best decision for their disrupted flight.

ANALYSIS CRITERIA:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 EVALUATE EACH OPTION BASED ON:

1. COST EFFICIENCY
   - Total cost difference from original flight
   - Value for money (cost vs benefits)
   - Hidden costs (meals, accommodation if delayed)

2. TIME OPTIMIZATION
   - Departure time convenience
   - Total travel duration
   - Arrival time suitability
   - Connection times (if applicable)

3. CONVENIENCE FACTORS
   - Direct vs connecting flights
   - Number of stops
   - Airport quality
   - Aircraft type and comfort

4. RELIABILITY INDICATORS
   - On-time performance history
   - Weather conditions on route
   - Airline reliability
   - Connection buffer times

5. PASSENGER-SPECIFIC FACTORS
   - Class of service (Business/Economy)
   - Passenger count (solo vs group)
   - Original flight preferences
   - Special requirements

6. RISK ASSESSMENT
   - Tight connections (< 60 min)
   - Weather delays probability
   - Overbooking risk
   - Alternative options if this fails

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 RECOMMENDATION STRATEGY:

• DEFAULT PRIORITY: Recommend the option with best balance of cost, time, and convenience
• BUSINESS CLASS: Prioritize direct flights and minimal delays over cost
• ECONOMY CLASS: Balance cost savings with reasonable convenience
• GROUPS: Prioritize flights with confirmed seats for all passengers
• TIGHT SCHEDULES: Recommend earliest available direct flight
• BUDGET-CONSCIOUS: Highlight cost-effective options even with minor inconvenience

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ RED FLAGS TO HIGHLIGHT:

• Connection time < 60 minutes (risky)
• Significant cost increase (> 50% more expensive)
• Very late/early departure times (inconvenient)
• Multiple connections (exhausting)
• Long total travel time (> 2x original)
• Low on-time performance airline/route

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 COMMUNICATION STYLE:

• Be clear and concise
• Use specific numbers ($50 cheaper, 2 hours faster)
• Highlight trade-offs honestly
• Provide actionable reasoning
• Consider passenger urgency and preferences

EXAMPLE RECOMMENDATION:
"I recommend Option 2 (Flight SA402) because it offers the best overall value:
• Only $20 more than your original flight
• Direct flight saves 2 hours vs Option 1
• Departs at 2pm giving you comfortable time to reach airport
• Excellent on-time record (95%)

Option 1 is $30 cheaper but has a 2-hour layover in ATL which adds risk. Option 3 is fastest but costs $80 more with minimal time benefit."

YOUR TASK: Analyze the provided flight alternatives and generate an intelligent recommendation with clear reasoning."""

    # Create LLM with structured output
    if AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT:
        llm = AzureChatOpenAI(
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            azure_deployment=AZURE_OPENAI_DEPLOYMENT,
            api_version=AZURE_OPENAI_API_VERSION,
            api_key=AZURE_OPENAI_API_KEY,
            temperature=0.3,  # Slightly creative for recommendations
        )
    else:
        llm = ChatOpenAI(
            model="gpt-4o",
            temperature=0.3,
            api_key=OPENAI_API_KEY
        )
    
    # Bind structured output
    structured_llm = llm.with_structured_output(FlightRecommendation)
    
    from langchain_core.prompts import ChatPromptTemplate
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("human", """Analyze these flight alternatives and provide your recommendation:

ORIGINAL FLIGHT:
{original_flight}

PASSENGER INFORMATION:
- Count: {passenger_count} passenger(s)
- Class: {class_of_service}

ALTERNATIVE FLIGHTS:
{alternatives_summary}

POLICY CONTEXT:
{policy_context}

Provide your intelligent recommendation with detailed reasoning.""")
    ])
    
    recommendation_chain = prompt | structured_llm
    
    class IntelligentDecisionAgent:
        """Wrapper for AI-powered decision recommendation agent"""
        def __init__(self, chain):
            self.chain = chain
            
        def invoke(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
            """Generate intelligent flight recommendation"""
            try:
                # Format alternatives for LLM
                alternatives = inputs.get("alternatives", [])
                original_flight = inputs.get("original_flight", {})
                
                alternatives_summary = ""
                for i, alt in enumerate(alternatives[:3], 1):  # Top 3
                    flight = alt.get("flight", alt) if isinstance(alt, dict) else alt
                    alternatives_summary += f"\nOPTION {i}: {flight.get('flight_number', 'N/A')}\n"
                    alternatives_summary += f"  Route: {flight.get('origin', 'N/A')} → {flight.get('destination', 'N/A')}\n"
                    alternatives_summary += f"  Departure: {flight.get('departure_time', 'N/A')}\n"
                    alternatives_summary += f"  Arrival: {flight.get('arrival_time', 'N/A')}\n"
                    alternatives_summary += f"  Cost: ${flight.get('cost', 0):.2f}\n"
                    alternatives_summary += f"  Aircraft: {flight.get('aircraft_type', 'N/A')}\n"
                    
                    # Add quality metrics if available
                    if 'quality_score' in alt:
                        alternatives_summary += f"  Quality Score: {alt.get('quality_score', 0):.1f}/10\n"
                
                # Format policy context
                policy_context = inputs.get("policy_guidance", {})
                if isinstance(policy_context, dict):
                    policy_text = policy_context.get("policy_guidance", "Standard airline policies apply")
                else:
                    policy_text = "Standard airline policies apply"
                
                # Get passenger class
                passenger_info = inputs.get("passenger", {})
                passengers_list = passenger_info.get("passengers", [{}])
                class_of_service = passengers_list[0].get("class_of_service", "Economy") if passengers_list else "Economy"
                
                # Invoke AI recommendation
                result = self.chain.invoke({
                    "original_flight": f"{original_flight.get('flight_number', 'N/A')} ({original_flight.get('origin', 'N/A')} → {original_flight.get('destination', 'N/A')}), Cost: ${original_flight.get('cost', 0):.2f}",
                    "passenger_count": inputs.get("passenger_count", 1),
                    "class_of_service": class_of_service,
                    "alternatives_summary": alternatives_summary,
                    "policy_context": policy_text
                })
                
                # Convert Pydantic model to dict
                return {
                    "recommended_option": result.recommended_option,
                    "recommendation_reasoning": result.recommendation_reasoning,
                    "option_1_pros": result.option_1_pros,
                    "option_1_cons": result.option_1_cons,
                    "option_2_pros": result.option_2_pros,
                    "option_2_cons": result.option_2_cons,
                    "option_3_pros": result.option_3_pros,
                    "option_3_cons": result.option_3_cons,
                    "key_considerations": result.key_considerations,
                    "confidence": result.confidence
                }
            except Exception as e:
                print(f"[WARNING] AI recommendation failed: {e}")
                # Fallback to simple recommendation
                return {
                    "recommended_option": 1,
                    "recommendation_reasoning": "Recommending first available option due to AI analysis error.",
                    "option_1_pros": "Available alternative",
                    "option_1_cons": "Unable to analyze",
                    "confidence": "low"
                }
    
    return IntelligentDecisionAgent(recommendation_chain)


def build_policy_agent():
    """Build ReAct agent for policy queries."""
    system_instructions = """You are the Policy Expert Agent for RecoverAI.
Task: Retrieve and interpret flight policy information from the knowledge base.

RULES:
- Query the policy knowledge base using query_policy_knowledge_base tool
- Provide final answer as JSON with policy guidance"""

    tools = [query_policy_knowledge_base]
    llm = get_llm_model()
    
    react_prompt = get_react_prompt_template(system_instructions)
    react_agent = create_react_agent(llm, tools, react_prompt)
    executor = AgentExecutor(
        agent=react_agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=10
    )
    
    return ReactAgentWrapper("policy_agent", executor)


# -------------------------------------------------------------------------
# Supervisor Agent with AI-Powered Routing (Using Structured Output)
# -------------------------------------------------------------------------
def build_supervisor_agent():
    """Build AI supervisor that uses LLM with structured output for intelligent routing.
    
    This uses LangChain's with_structured_output() instead of ReAct tools to avoid JSON parsing issues.
    The LLM directly returns a structured routing decision."""
    
    from langchain_core.pydantic_v1 import BaseModel, Field, validator
    
    # Define the structured output schema
    class RoutingDecision(BaseModel):
        """Intelligent routing decision from AI Supervisor"""
        next_agent: str = Field(
            description="The agent to route to next. Must be one of: support, policy, resource, decision, cost, notify, summary_node"
        )
        reasoning: str = Field(
            description="Clear explanation of why routing to this agent (2-3 sentences)"
        )
        confidence: str = Field(
            description="Confidence level in this routing decision: high, medium, or low"
        )
        alternative_path: str = Field(
            default="",
            description="Optional: Alternative agent if this route fails"
        )
        
        @validator('next_agent')
        def validate_agent(cls, v):
            valid_agents = ["support", "policy", "resource", "decision", "cost", "notify", "summary_node"]
            if v not in valid_agents:
                return "support"  # Default fallback
            return v
        
        @validator('confidence')
        def validate_confidence(cls, v):
            valid_confidence = ["high", "medium", "low"]
            if v.lower() not in valid_confidence:
                return "medium"  # Default fallback
            return v.lower()
    
    system_prompt = """You are the AI Supervisor for RecoverAI - an intelligent orchestration system for flight disruption management.

YOUR ROLE: Analyze the workflow state and make intelligent routing decisions to specialized agents.

AVAILABLE AGENTS & THEIR CAPABILITIES:
1. support - Fetches passenger PNR and flight details from database
2. policy - Queries RAG knowledge base for airline policies and guidelines  
3. resource - Searches alternative flights with available capacity
4. decision - Manages passenger choices (human-in-the-loop for selections)
5. cost - Calculates costs and applies bookings to systems
6. notify - Sends notifications via email/SMS to passengers
7. summary_node - Generates final summary and completes workflow

INTELLIGENT ROUTING PRINCIPLES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 SEQUENTIAL FLOW (Standard Path):
   support → policy → resource → decision → cost → notify → summary_node

🎯 SMART DECISION POINTS:

1. DATA GATHERING PHASE:
   - Missing passenger/flight info? → Route to 'support'
   - Data present but no policy guidance? → Route to 'policy'
   
2. SOLUTION FINDING PHASE:
   - Policy known but no alternatives? → Route to 'resource'
   - Alternatives found? → Route to 'decision' for passenger choice
   
3. HUMAN INTERACTION PHASE:
   - No passenger decision yet? → Route to 'decision' (Human-in-the-loop via interrupt)
   - Decision collected? → Proceed to execution phase
   
4. EXECUTION PHASE:
   - Decision made but cost not calculated? → Route to 'cost'
   - Cost calculated but not notified? → Route to 'notify'
   - Everything complete? → Route to 'summary_node'

🚨 SPECIAL SCENARIOS & EDGE CASES:

A) CANCELLATION PATH (CRITICAL - NO BOOKING NEEDED):
   If passenger_decision = 'cancel':
   ⚠️ SKIP BOOKING ENTIRELY! Cancellations never have bookings.
   Flow: decision → cost (calculate refund) → notify → summary_node
   ❌ DO NOT route to cost more than ONCE for cancellations!
   ✅ After cost completes for cancel, ALWAYS route to notify (never back to cost)
   
B) WAIT PATH (NO BOOKING NEEDED):
   If passenger_decision = 'wait':
   Flow: decision → cost (if needed) → notify → summary_node
   
C) REBOOKING PATH (BOOKING REQUIRED):
   If passenger_decision = 'rebook' (or numeric choice 1-3):
   Flow: decision → cost → notify → summary_node
   ⚠️ For rebookings, has_booking should be True after cost completes
   
D) ERROR HANDLING:
   - passenger_has_error or flight_has_error? → summary_node (terminate gracefully)
   - cost_error_count >= 2? → Skip to notify or summary_node
   - notify_error_count >= 2? → Skip to summary_node
   
E) SKIP UNNECESSARY STEPS:
   - If VIP passenger with urgent disruption → Can skip policy, go direct to resource
   - If simple rebooking with clear policy → Can expedite through steps
   - If group booking → May need special handling in decision phase

🧠 INTELLIGENCE FACTORS TO CONSIDER:
- Passenger tier (Economy/Business/First) affects priority
- Group size (1 vs 5 passengers) affects complexity
- Time sensitivity (flight departure proximity)
- Previous error counts indicate problematic paths
- Cost implications of different routing choices

YOUR TASK:
Analyze the state_summary carefully and make an INTELLIGENT routing decision that:
✓ Follows logical workflow progression
✓ Handles edge cases appropriately  
✓ Optimizes for efficiency (skip unnecessary steps)
✓ Considers passenger context and urgency
✓ Provides clear reasoning for your decision

Return a structured routing decision with next_agent, reasoning, and confidence level."""

    # Create LLM with structured output
    # Use Azure OpenAI if available, fallback to OpenAI
    if AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT:
        llm = AzureChatOpenAI(
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            azure_deployment=AZURE_OPENAI_DEPLOYMENT,
            api_version=AZURE_OPENAI_API_VERSION,
            api_key=AZURE_OPENAI_API_KEY,
            temperature=0.3,  # Low temperature for consistent routing
        )
    else:
        llm = ChatOpenAI(
            model="gpt-4",
            temperature=0.3,
            api_key=OPENAI_API_KEY
        )
    
    # Bind the structured output schema to LLM
    structured_llm = llm.with_structured_output(RoutingDecision)
    
    # Create the routing chain
    from langchain_core.prompts import ChatPromptTemplate
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("human", """Analyze the current workflow state and determine the next agent to route to.

CURRENT STATE ANALYSIS:
{state_summary}

WORKFLOW CONTEXT:
- PNR: {pnr}
- Total Steps Completed: {steps_completed}
- Current Phase: {phase}

Make an intelligent routing decision based on the above information.""")
    ])
    
    # Create the routing chain with structured output
    routing_chain = prompt | structured_llm
    
    # Wrapper class to make it compatible with existing code
    class SupervisorAI:
        """Wrapper for AI Supervisor with structured output"""
        def __init__(self, chain):
            self.chain = chain
            
        def invoke(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
            """Invoke the AI supervisor and return routing decision"""
            state_summary = inputs.get("state_summary", {})
            
            # Determine current phase
            phase = "DATA_GATHERING"
            steps_completed = 0
            
            if state_summary.get("has_passenger_info") and state_summary.get("has_flight_info"):
                steps_completed += 1
                phase = "POLICY_RETRIEVAL"
            if state_summary.get("has_policy_guidance"):
                steps_completed += 1
                phase = "SOLUTION_FINDING"
            if state_summary.get("has_alternatives"):
                steps_completed += 1
                phase = "DECISION_MAKING"
            if state_summary.get("passenger_decision"):
                steps_completed += 1
                phase = "EXECUTION"
            if state_summary.get("has_booking"):
                steps_completed += 1
                phase = "NOTIFICATION"
            if state_summary.get("has_notification"):
                steps_completed += 1
                phase = "COMPLETION"
            
            # Format state summary for LLM
            formatted_summary = "\n".join([f"  - {k}: {v}" for k, v in state_summary.items()])
            
            # Invoke the chain
            try:
                result = self.chain.invoke({
                    "state_summary": formatted_summary,
                    "pnr": inputs.get("pnr", "UNKNOWN"),
                    "steps_completed": steps_completed,
                    "phase": phase
                })
                
                # Convert Pydantic model to dict
                return {
                    "next_agent": result.next_agent,
                    "reasoning": result.reasoning,
                    "confidence": result.confidence,
                    "alternative_path": result.alternative_path
                }
            except Exception as e:
                # Fallback to rule-based on error
                print(f"[WARNING] AI Supervisor error: {str(e)}")
                return {
                    "next_agent": "support",
                    "reasoning": f"AI error, using fallback: {str(e)}",
                    "confidence": "low"
                }
    
    return SupervisorAI(routing_chain)


# -------------------------------------------------------------------------
# Factory (all agents)
# -------------------------------------------------------------------------
def build_all_specialized_agents() -> Dict[str, Any]:
    return {
        "support": build_support_agent(),
        "resource": build_resource_agent(),
        "decision": build_decision_agent(),
        "cost": build_cost_agent(),
        "notify": build_notify_agent(),
        "policy": build_policy_agent(),
        "supervisor": build_supervisor_agent(),
    }