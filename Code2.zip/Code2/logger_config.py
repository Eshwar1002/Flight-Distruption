"""
Logging configuration for RecoverAI Flight Disruption Management System.

Provides structured logging with different levels, file rotation, and formatted output.
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
import json

# Create logs directory
BASE_DIR = Path(__file__).resolve().parent
LOGS_DIR = BASE_DIR / "logs"
LOGS_DIR.mkdir(exist_ok=True)

# Define log file paths
APP_LOG_FILE = LOGS_DIR / "recoverai_app.log"
ERROR_LOG_FILE = LOGS_DIR / "recoverai_errors.log"
AGENT_LOG_FILE = LOGS_DIR / "recoverai_agents.log"


class JsonFormatter(logging.Formatter):
    """
    Custom JSON formatter for structured logging.
    Outputs logs in JSON format for easy parsing and analysis.
    """
    
    def format(self, record):
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields if present
        if hasattr(record, "pnr"):
            log_data["pnr"] = record.pnr
        if hasattr(record, "agent"):
            log_data["agent"] = record.agent
        if hasattr(record, "passenger_count"):
            log_data["passenger_count"] = record.passenger_count
        if hasattr(record, "flight_number"):
            log_data["flight_number"] = record.flight_number
        if hasattr(record, "duration_ms"):
            log_data["duration_ms"] = record.duration_ms
        if hasattr(record, "error_code"):
            log_data["error_code"] = record.error_code
            
        return json.dumps(log_data)


class ColoredConsoleFormatter(logging.Formatter):
    """
    Custom formatter for console output with colors and structured format.
    """
    
    # ANSI color codes
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[35m',   # Magenta
    }
    RESET = '\033[0m'
    
    # Simple text indicators for Windows compatibility (no emojis)
    INDICATORS = {
        'DEBUG': '[DEBUG]',
        'INFO': '[INFO]',
        'WARNING': '[WARN]',
        'ERROR': '[ERROR]',
        'CRITICAL': '[CRITICAL]',
    }
    
    def format(self, record):
        # Add color to level name
        levelname = record.levelname
        color = self.COLORS.get(levelname, self.RESET)
        indicator = self.INDICATORS.get(levelname, '')
        
        # Format the message
        log_format = f"{color}{indicator}{self.RESET} {record.name} - {record.getMessage()}"
        
        # Add extra context if available
        extras = []
        if hasattr(record, "pnr"):
            extras.append(f"PNR:{record.pnr}")
        if hasattr(record, "agent"):
            extras.append(f"Agent:{record.agent}")
        if hasattr(record, "flight_number"):
            extras.append(f"Flight:{record.flight_number}")
        if hasattr(record, "duration_ms"):
            extras.append(f"Duration:{record.duration_ms}ms")
            
        if extras:
            log_format += f" | {' | '.join(extras)}"
        
        # Add exception if present
        if record.exc_info:
            log_format += f"\n{self.formatException(record.exc_info)}"
            
        return log_format


def setup_logging(log_level=logging.INFO, enable_json_logs=False):
    """
    Set up logging configuration for the entire application.
    
    Args:
        log_level: Logging level (default: INFO)
        enable_json_logs: If True, use JSON format for file logs (default: False)
    
    Returns:
        dict: Dictionary of configured loggers
    """
    
    # Create root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # Capture all levels
    
    # Clear any existing handlers
    root_logger.handlers.clear()
    
    # Console Handler - Human-readable format with colors
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(ColoredConsoleFormatter())
    root_logger.addHandler(console_handler)
    
    # File Handler - All logs with rotation
    if enable_json_logs:
        file_formatter = JsonFormatter()
    else:
        file_formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)-20s | %(funcName)-20s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
    
    app_file_handler = RotatingFileHandler(
        APP_LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    app_file_handler.setLevel(logging.DEBUG)
    app_file_handler.setFormatter(file_formatter)
    root_logger.addHandler(app_file_handler)
    
    # Error File Handler - Only errors and above
    error_file_handler = RotatingFileHandler(
        ERROR_LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    error_file_handler.setLevel(logging.ERROR)
    error_file_handler.setFormatter(file_formatter)
    root_logger.addHandler(error_file_handler)
    
    # Agent Activity File Handler - Track agent operations
    agent_file_handler = RotatingFileHandler(
        AGENT_LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    agent_file_handler.setLevel(logging.INFO)
    agent_file_handler.setFormatter(file_formatter)
    
    # Create specific loggers for different components
    loggers = {
        'main': logging.getLogger('recoverai.main'),
        'supervisor': logging.getLogger('recoverai.supervisor'),
        'agents': logging.getLogger('recoverai.agents'),
        'tools': logging.getLogger('recoverai.tools'),
        'support': logging.getLogger('recoverai.support'),
        'db': logging.getLogger('recoverai.database'),
        'rag': logging.getLogger('recoverai.rag'),
    }
    
    # Agent logger gets special handler
    loggers['agents'].addHandler(agent_file_handler)
    
    # Suppress noisy third-party loggers
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('openai').setLevel(logging.WARNING)
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    
    # Log startup message
    root_logger.info("=" * 70)
    root_logger.info("RecoverAI Flight Disruption Management System - Logging Initialized")
    root_logger.info(f"Log Level: {logging.getLevelName(log_level)}")
    root_logger.info(f"App Log: {APP_LOG_FILE}")
    root_logger.info(f"Error Log: {ERROR_LOG_FILE}")
    root_logger.info(f"Agent Log: {AGENT_LOG_FILE}")
    root_logger.info("=" * 70)
    
    return loggers


def get_logger(name):
    """
    Get a logger instance with the specified name.
    
    Args:
        name: Logger name (e.g., 'recoverai.tools')
    
    Returns:
        logging.Logger: Configured logger instance
    """
    return logging.getLogger(f"recoverai.{name}")


# Convenience functions for common logging patterns
def log_agent_start(logger, agent_name, pnr=None, **kwargs):
    """Log the start of an agent operation."""
    logger.info(
        f"Starting {agent_name} agent",
        extra={"agent": agent_name, "pnr": pnr, **kwargs}
    )


def log_agent_complete(logger, agent_name, pnr=None, duration_ms=None, **kwargs):
    """Log the completion of an agent operation."""
    logger.info(
        f"Completed {agent_name} agent",
        extra={"agent": agent_name, "pnr": pnr, "duration_ms": duration_ms, **kwargs}
    )


def log_agent_error(logger, agent_name, error, pnr=None, **kwargs):
    """Log an error in an agent operation."""
    logger.error(
        f"Error in {agent_name} agent: {error}",
        extra={"agent": agent_name, "pnr": pnr, "error_code": type(error).__name__, **kwargs},
        exc_info=True
    )


def log_database_operation(logger, operation, table=None, pnr=None, **kwargs):
    """Log a database operation."""
    logger.debug(
        f"Database {operation}",
        extra={"operation": operation, "table": table, "pnr": pnr, **kwargs}
    )


def log_user_interaction(logger, action, pnr=None, user_input=None, **kwargs):
    """Log user interactions."""
    logger.info(
        f"User {action}",
        extra={"action": action, "pnr": pnr, "user_input": user_input, **kwargs}
    )


# Initialize logging on module import (can be reconfigured later)
if __name__ != "__main__":
    setup_logging()
